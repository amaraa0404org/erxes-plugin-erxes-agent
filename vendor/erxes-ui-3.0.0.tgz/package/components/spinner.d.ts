import { VariantProps } from 'class-variance-authority';
declare const spinnerVariants: (props?: ({
    show?: boolean | null | undefined;
} & import("class-variance-authority/types").ClassProp) | undefined) => string;
declare const loaderVariants: (props?: ({
    size?: "default" | "sm" | "lg" | "md" | null | undefined;
} & import("class-variance-authority/types").ClassProp) | undefined) => string;
interface SpinnerContentProps extends VariantProps<typeof spinnerVariants>, VariantProps<typeof loaderVariants> {
    className?: string;
    containerClassName?: string;
}
export declare function Spinner({ size, show, className, containerClassName, }: SpinnerContentProps): import("react/jsx-runtime").JSX.Element;
export {};
