import { type InputHTMLAttributes } from 'react';
interface TextOverflowTooltipProps {
    value?: string;
    className?: string;
    delayDuration?: number;
}
interface TextOverflowTooltipInputProps extends Omit<InputHTMLAttributes<HTMLInputElement>, 'value' | 'onChange'> {
    value?: string;
    onChange?: (value: string) => void;
    delayDuration?: number;
}
export declare const TextOverflowTooltip: import("react").ForwardRefExoticComponent<TextOverflowTooltipProps & import("react").RefAttributes<HTMLSpanElement>> & {
    Input: import("react").ForwardRefExoticComponent<TextOverflowTooltipInputProps & import("react").RefAttributes<HTMLInputElement>>;
};
export {};
