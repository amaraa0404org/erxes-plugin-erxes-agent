import React from 'react';
export declare const ColorPickerProvider: ({ children, value, onValueChange, colors, open, onOpenChange, scope, }: {
    children: React.ReactNode;
    value?: string;
    onValueChange?: (value: string) => void;
    colors?: Record<string, string>;
    open?: boolean;
    onOpenChange?: (open: boolean) => void;
    scope?: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const ColorPicker: React.ForwardRefExoticComponent<Omit<Omit<Omit<import("erxes-ui/components").ButtonProps & React.RefAttributes<HTMLButtonElement>, "ref"> & {
    hideChevron?: boolean;
} & React.RefAttributes<HTMLButtonElement>, "ref">, "value"> & {
    value?: string;
    onValueChange?: (value: string) => void;
    colors?: Record<string, string>;
    scope?: string;
} & React.RefAttributes<HTMLButtonElement>> & {
    Provider: ({ children, value, onValueChange, colors, open, onOpenChange, scope, }: {
        children: React.ReactNode;
        value?: string;
        onValueChange?: (value: string) => void;
        colors?: Record<string, string>;
        open?: boolean;
        onOpenChange?: (open: boolean) => void;
        scope?: string;
    }) => import("react/jsx-runtime").JSX.Element;
    Trigger: React.ForwardRefExoticComponent<Omit<Omit<import("erxes-ui/components").ButtonProps & React.RefAttributes<HTMLButtonElement>, "ref"> & {
        hideChevron?: boolean;
    } & React.RefAttributes<HTMLButtonElement>, "ref"> & React.RefAttributes<HTMLButtonElement>>;
    Content: ({ setOpen, }: {
        setOpen?: (open: boolean) => void;
    }) => import("react/jsx-runtime").JSX.Element;
};
