import React from 'react';
export declare const InfoCard: (({ title, description, children, className, }: {
    title: string;
    description?: string;
    children?: React.ReactNode;
    className?: string;
}) => import("react/jsx-runtime").JSX.Element) & {
    Content: React.ForwardRefExoticComponent<Omit<React.DetailedHTMLProps<React.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "ref"> & React.RefAttributes<HTMLDivElement>>;
};
