export declare const Skeleton: ({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) => import("react/jsx-runtime").JSX.Element;
export declare const SkeletonArray: ({ className, count, ...props }: React.HTMLAttributes<HTMLDivElement> & {
    count: number;
}) => import("react/jsx-runtime").JSX.Element[];
