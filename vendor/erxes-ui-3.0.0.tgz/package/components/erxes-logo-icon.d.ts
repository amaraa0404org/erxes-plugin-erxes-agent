export declare const ErxesLogoIcon: ({ ...props }: React.SVGProps<SVGSVGElement>) => import("react/jsx-runtime").JSX.Element;
