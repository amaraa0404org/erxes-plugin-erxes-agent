import * as React from 'react';
import { Tooltip as TooltipPrimitive } from 'radix-ui';
export declare const Tooltip: React.FC<TooltipPrimitive.TooltipProps> & {
    Provider: React.FC<TooltipPrimitive.TooltipProviderProps>;
    Trigger: React.ForwardRefExoticComponent<TooltipPrimitive.TooltipTriggerProps & React.RefAttributes<HTMLButtonElement>>;
    Content: React.ForwardRefExoticComponent<Omit<TooltipPrimitive.TooltipContentProps & React.RefAttributes<HTMLDivElement>, "ref"> & React.RefAttributes<HTMLDivElement>>;
};
