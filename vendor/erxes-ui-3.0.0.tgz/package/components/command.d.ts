import * as React from 'react';
import { DialogProps } from './dialog';
type CommandDialogProps = DialogProps & {
    dialogContentClassName?: string;
};
export declare const Command: React.ForwardRefExoticComponent<Omit<{
    children?: React.ReactNode;
} & Pick<Pick<React.DetailedHTMLProps<React.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "key" | keyof React.HTMLAttributes<HTMLDivElement>> & {
    ref?: React.Ref<HTMLDivElement>;
} & {
    asChild?: boolean;
}, "key" | keyof React.HTMLAttributes<HTMLDivElement> | "asChild"> & {
    label?: string;
    shouldFilter?: boolean;
    filter?: (value: string, search: string, keywords?: string[]) => number;
    defaultValue?: string;
    value?: string;
    onValueChange?: (value: string) => void;
    loop?: boolean;
    disablePointerSelection?: boolean;
    vimBindings?: boolean;
} & React.RefAttributes<HTMLDivElement>, "ref"> & React.RefAttributes<HTMLDivElement>> & {
    Dialog: ({ children, dialogContentClassName, ...props }: CommandDialogProps) => import("react/jsx-runtime").JSX.Element;
    Input: React.ForwardRefExoticComponent<Omit<Omit<Pick<Pick<React.DetailedHTMLProps<React.InputHTMLAttributes<HTMLInputElement>, HTMLInputElement>, "key" | keyof React.InputHTMLAttributes<HTMLInputElement>> & {
        ref?: React.Ref<HTMLInputElement>;
    } & {
        asChild?: boolean;
    }, "key" | "asChild" | keyof React.InputHTMLAttributes<HTMLInputElement>>, "onChange" | "value" | "type"> & {
        value?: string;
        onValueChange?: (search: string) => void;
    } & React.RefAttributes<HTMLInputElement>, "ref"> & {
        variant?: "primary" | "secondary";
        wrapperClassName?: string;
        focusOnMount?: boolean;
    } & React.RefAttributes<HTMLInputElement>>;
    List: React.ForwardRefExoticComponent<Omit<{
        children?: React.ReactNode;
    } & Pick<Pick<React.DetailedHTMLProps<React.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "key" | keyof React.HTMLAttributes<HTMLDivElement>> & {
        ref?: React.Ref<HTMLDivElement>;
    } & {
        asChild?: boolean;
    }, "key" | keyof React.HTMLAttributes<HTMLDivElement> | "asChild"> & {
        label?: string;
    } & React.RefAttributes<HTMLDivElement>, "ref"> & React.RefAttributes<HTMLDivElement>>;
    Empty: React.ForwardRefExoticComponent<Omit<{
        children?: React.ReactNode;
    } & Pick<Pick<React.DetailedHTMLProps<React.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "key" | keyof React.HTMLAttributes<HTMLDivElement>> & {
        ref?: React.Ref<HTMLDivElement>;
    } & {
        asChild?: boolean;
    }, "key" | keyof React.HTMLAttributes<HTMLDivElement> | "asChild"> & React.RefAttributes<HTMLDivElement>, "ref"> & React.RefAttributes<HTMLDivElement>>;
    Group: React.ForwardRefExoticComponent<Omit<{
        children?: React.ReactNode;
    } & Omit<Pick<Pick<React.DetailedHTMLProps<React.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "key" | keyof React.HTMLAttributes<HTMLDivElement>> & {
        ref?: React.Ref<HTMLDivElement>;
    } & {
        asChild?: boolean;
    }, "key" | keyof React.HTMLAttributes<HTMLDivElement> | "asChild">, "value" | "heading"> & {
        heading?: React.ReactNode;
        value?: string;
        forceMount?: boolean;
    } & React.RefAttributes<HTMLDivElement>, "ref"> & React.RefAttributes<HTMLDivElement>>;
    Item: React.ForwardRefExoticComponent<Omit<{
        children?: React.ReactNode;
    } & Omit<Pick<Pick<React.DetailedHTMLProps<React.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "key" | keyof React.HTMLAttributes<HTMLDivElement>> & {
        ref?: React.Ref<HTMLDivElement>;
    } & {
        asChild?: boolean;
    }, "key" | keyof React.HTMLAttributes<HTMLDivElement> | "asChild">, "onSelect" | "disabled" | "value"> & {
        disabled?: boolean;
        onSelect?: (value: string) => void;
        value?: string;
        keywords?: string[];
        forceMount?: boolean;
    } & React.RefAttributes<HTMLDivElement>, "ref"> & React.RefAttributes<HTMLDivElement>>;
    ActionItem: {
        ({ icon: Icon, label, onSelect, disabled, trailing, className, }: {
            icon: React.ComponentType<{
                className?: string;
            }>;
            label: React.ReactNode;
            onSelect: () => void;
            disabled?: boolean;
            trailing?: React.ReactNode;
            className?: string;
        }): import("react/jsx-runtime").JSX.Element;
        displayName: string;
    };
    Shortcut: {
        ({ className, ...props }: React.HTMLAttributes<HTMLSpanElement>): import("react/jsx-runtime").JSX.Element;
        displayName: string;
    };
    Separator: React.ForwardRefExoticComponent<Omit<Pick<Pick<React.DetailedHTMLProps<React.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "key" | keyof React.HTMLAttributes<HTMLDivElement>> & {
        ref?: React.Ref<HTMLDivElement>;
    } & {
        asChild?: boolean;
    }, "key" | keyof React.HTMLAttributes<HTMLDivElement> | "asChild"> & {
        alwaysRender?: boolean;
    } & React.RefAttributes<HTMLDivElement>, "ref"> & React.RefAttributes<HTMLDivElement>>;
    Primitive: React.ForwardRefExoticComponent<{
        children?: React.ReactNode;
    } & Pick<Pick<React.DetailedHTMLProps<React.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "key" | keyof React.HTMLAttributes<HTMLDivElement>> & {
        ref?: React.Ref<HTMLDivElement>;
    } & {
        asChild?: boolean;
    }, "key" | keyof React.HTMLAttributes<HTMLDivElement> | "asChild"> & {
        label?: string;
        shouldFilter?: boolean;
        filter?: (value: string, search: string, keywords?: string[]) => number;
        defaultValue?: string;
        value?: string;
        onValueChange?: (value: string) => void;
        loop?: boolean;
        disablePointerSelection?: boolean;
        vimBindings?: boolean;
    } & React.RefAttributes<HTMLDivElement>> & {
        List: React.ForwardRefExoticComponent<{
            children?: React.ReactNode;
        } & Pick<Pick<React.DetailedHTMLProps<React.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "key" | keyof React.HTMLAttributes<HTMLDivElement>> & {
            ref?: React.Ref<HTMLDivElement>;
        } & {
            asChild?: boolean;
        }, "key" | keyof React.HTMLAttributes<HTMLDivElement> | "asChild"> & {
            label?: string;
        } & React.RefAttributes<HTMLDivElement>>;
        Item: React.ForwardRefExoticComponent<{
            children?: React.ReactNode;
        } & Omit<Pick<Pick<React.DetailedHTMLProps<React.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "key" | keyof React.HTMLAttributes<HTMLDivElement>> & {
            ref?: React.Ref<HTMLDivElement>;
        } & {
            asChild?: boolean;
        }, "key" | keyof React.HTMLAttributes<HTMLDivElement> | "asChild">, "onSelect" | "disabled" | "value"> & {
            disabled?: boolean;
            onSelect?: (value: string) => void;
            value?: string;
            keywords?: string[];
            forceMount?: boolean;
        } & React.RefAttributes<HTMLDivElement>>;
        Input: React.ForwardRefExoticComponent<Omit<Pick<Pick<React.DetailedHTMLProps<React.InputHTMLAttributes<HTMLInputElement>, HTMLInputElement>, "key" | keyof React.InputHTMLAttributes<HTMLInputElement>> & {
            ref?: React.Ref<HTMLInputElement>;
        } & {
            asChild?: boolean;
        }, "key" | "asChild" | keyof React.InputHTMLAttributes<HTMLInputElement>>, "onChange" | "value" | "type"> & {
            value?: string;
            onValueChange?: (search: string) => void;
        } & React.RefAttributes<HTMLInputElement>>;
        Group: React.ForwardRefExoticComponent<{
            children?: React.ReactNode;
        } & Omit<Pick<Pick<React.DetailedHTMLProps<React.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "key" | keyof React.HTMLAttributes<HTMLDivElement>> & {
            ref?: React.Ref<HTMLDivElement>;
        } & {
            asChild?: boolean;
        }, "key" | keyof React.HTMLAttributes<HTMLDivElement> | "asChild">, "heading" | "value"> & {
            heading?: React.ReactNode;
            value?: string;
            forceMount?: boolean;
        } & React.RefAttributes<HTMLDivElement>>;
        Separator: React.ForwardRefExoticComponent<Pick<Pick<React.DetailedHTMLProps<React.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "key" | keyof React.HTMLAttributes<HTMLDivElement>> & {
            ref?: React.Ref<HTMLDivElement>;
        } & {
            asChild?: boolean;
        }, "key" | keyof React.HTMLAttributes<HTMLDivElement> | "asChild"> & {
            alwaysRender?: boolean;
        } & React.RefAttributes<HTMLDivElement>>;
        Dialog: React.ForwardRefExoticComponent<import("@radix-ui/react-dialog").DialogProps & {
            children?: React.ReactNode;
        } & Pick<Pick<React.DetailedHTMLProps<React.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "key" | keyof React.HTMLAttributes<HTMLDivElement>> & {
            ref?: React.Ref<HTMLDivElement>;
        } & {
            asChild?: boolean;
        }, "key" | keyof React.HTMLAttributes<HTMLDivElement> | "asChild"> & {
            label?: string;
            shouldFilter?: boolean;
            filter?: (value: string, search: string, keywords?: string[]) => number;
            defaultValue?: string;
            value?: string;
            onValueChange?: (value: string) => void;
            loop?: boolean;
            disablePointerSelection?: boolean;
            vimBindings?: boolean;
        } & {
            overlayClassName?: string;
            contentClassName?: string;
            container?: HTMLElement;
        } & React.RefAttributes<HTMLDivElement>>;
        Empty: React.ForwardRefExoticComponent<{
            children?: React.ReactNode;
        } & Pick<Pick<React.DetailedHTMLProps<React.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "key" | keyof React.HTMLAttributes<HTMLDivElement>> & {
            ref?: React.Ref<HTMLDivElement>;
        } & {
            asChild?: boolean;
        }, "key" | keyof React.HTMLAttributes<HTMLDivElement> | "asChild"> & React.RefAttributes<HTMLDivElement>>;
        Loading: React.ForwardRefExoticComponent<{
            children?: React.ReactNode;
        } & Pick<Pick<React.DetailedHTMLProps<React.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "key" | keyof React.HTMLAttributes<HTMLDivElement>> & {
            ref?: React.Ref<HTMLDivElement>;
        } & {
            asChild?: boolean;
        }, "key" | keyof React.HTMLAttributes<HTMLDivElement> | "asChild"> & {
            progress?: number;
            label?: string;
        } & React.RefAttributes<HTMLDivElement>>;
    };
};
export {};
