import * as React from 'react';
import { ScrollArea as ScrollAreaPrimitive } from 'radix-ui';
export declare const ScrollArea: React.ForwardRefExoticComponent<Omit<ScrollAreaPrimitive.ScrollAreaProps & React.RefAttributes<HTMLDivElement>, "ref"> & {
    scrollBarClassName?: string;
    viewportClassName?: string;
} & React.RefAttributes<HTMLDivElement>> & {
    Root: React.ForwardRefExoticComponent<Omit<Omit<ScrollAreaPrimitive.ScrollAreaProps & React.RefAttributes<HTMLDivElement>, "ref"> & {
        scrollBarClassName?: string;
        viewportClassName?: string;
    } & React.RefAttributes<HTMLDivElement>, "ref"> & React.RefAttributes<HTMLDivElement>>;
    Viewport: React.ForwardRefExoticComponent<Omit<ScrollAreaPrimitive.ScrollAreaViewportProps & React.RefAttributes<HTMLDivElement>, "ref"> & React.RefAttributes<HTMLDivElement>>;
    Bar: React.ForwardRefExoticComponent<Omit<ScrollAreaPrimitive.ScrollAreaScrollbarProps & React.RefAttributes<HTMLDivElement>, "ref"> & React.RefAttributes<HTMLDivElement>>;
};
