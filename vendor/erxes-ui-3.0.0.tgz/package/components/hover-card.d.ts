import * as React from 'react';
import { HoverCard as HoverCardPrimitive } from 'radix-ui';
export declare const HoverCard: React.FC<HoverCardPrimitive.HoverCardProps> & {
    Trigger: React.ForwardRefExoticComponent<HoverCardPrimitive.HoverCardTriggerProps & React.RefAttributes<HTMLAnchorElement>>;
    Content: React.ForwardRefExoticComponent<Omit<HoverCardPrimitive.HoverCardContentProps & React.RefAttributes<HTMLDivElement>, "ref"> & React.RefAttributes<HTMLDivElement>>;
};
