import { DateFieldProps, DateInputProps as DateInputPropsRac, DateSegmentProps, DateValue as DateValueRac, TimeFieldProps, TimeValue as TimeValueRac } from 'react-aria-components';
declare function DateField<T extends DateValueRac>({ className, children, ...props }: DateFieldProps<T>): import("react/jsx-runtime").JSX.Element;
declare function TimeField<T extends TimeValueRac>({ className, children, ...props }: TimeFieldProps<T>): import("react/jsx-runtime").JSX.Element;
declare function DateSegment({ className, ...props }: DateSegmentProps): import("react/jsx-runtime").JSX.Element;
interface DateInputProps extends DateInputPropsRac {
    className?: string;
    unstyled?: boolean;
}
declare function DateInput({ className, unstyled, ...props }: Omit<DateInputProps, 'children'>): import("react/jsx-runtime").JSX.Element;
export { DateField, DateInput, DateSegment, TimeField };
export type { DateInputProps };
