interface CopyTextProps {
    value: string;
    children: React.ReactNode;
    className?: string;
}
export declare const CopyText: ({ value, children, className }: CopyTextProps) => import("react/jsx-runtime").JSX.Element;
export {};
