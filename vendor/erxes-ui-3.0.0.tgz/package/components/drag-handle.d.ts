import { ButtonProps } from './button';
export type DragHandleProps = Omit<ButtonProps, 'asChild' | 'children' | 'size'>;
export declare const DragHandle: import("react").ForwardRefExoticComponent<DragHandleProps & import("react").RefAttributes<HTMLButtonElement>>;
