import React from 'react';
import type { ApolloError } from '@apollo/client';
export declare const ComboboxTriggerBase: React.ForwardRefExoticComponent<Omit<import("./button").ButtonProps & React.RefAttributes<HTMLButtonElement>, "ref"> & {
    hideChevron?: boolean;
} & React.RefAttributes<HTMLButtonElement>>;
export declare const ComboboxTrigger: React.ForwardRefExoticComponent<Omit<import("./button").ButtonProps & React.RefAttributes<HTMLButtonElement>, "ref"> & {
    hideChevron?: boolean;
} & React.RefAttributes<HTMLButtonElement>>;
export declare const ComboboxTriggerIcon: React.ForwardRefExoticComponent<Omit<import("@tabler/icons-react").IconProps & React.RefAttributes<import("@tabler/icons-react").Icon>, "ref"> & React.RefAttributes<import("@tabler/icons-react").Icon>>;
export declare const ComboboxValue: React.ForwardRefExoticComponent<React.HTMLAttributes<HTMLSpanElement> & {
    placeholder?: string;
    loading?: boolean;
    value?: string | JSX.Element;
} & React.RefAttributes<HTMLSpanElement>>;
export declare const ComboboxContent: React.ForwardRefExoticComponent<Omit<Omit<import("@radix-ui/react-popover").PopoverContentProps & React.RefAttributes<HTMLDivElement>, "ref"> & {
    disableTransition?: boolean;
} & React.RefAttributes<HTMLDivElement>, "ref"> & React.RefAttributes<HTMLDivElement>>;
export declare const ComboboxCheck: React.ForwardRefExoticComponent<Omit<import("@tabler/icons-react").IconProps & React.RefAttributes<import("@tabler/icons-react").Icon>, "ref"> & {
    checked?: boolean;
} & React.RefAttributes<import("@tabler/icons-react").Icon>>;
export declare const ComboboxFetchMore: React.ForwardRefExoticComponent<Omit<Omit<{
    children?: React.ReactNode;
} & Omit<Pick<Pick<React.DetailedHTMLProps<React.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "key" | keyof React.HTMLAttributes<HTMLDivElement>> & {
    ref?: React.Ref<HTMLDivElement>;
} & {
    asChild?: boolean;
}, "key" | keyof React.HTMLAttributes<HTMLDivElement> | "asChild">, "onSelect" | "disabled" | "value"> & {
    disabled?: boolean;
    onSelect?: (value: string) => void;
    value?: string;
    keywords?: string[];
    forceMount?: boolean;
} & React.RefAttributes<HTMLDivElement>, "ref"> & React.RefAttributes<HTMLDivElement>, "ref"> & {
    totalCount: number;
    currentLength: number;
    fetchMore: () => void;
} & React.RefAttributes<HTMLDivElement>>;
export declare const Combobox: {
    TriggerBase: React.ForwardRefExoticComponent<Omit<import("./button").ButtonProps & React.RefAttributes<HTMLButtonElement>, "ref"> & {
        hideChevron?: boolean;
    } & React.RefAttributes<HTMLButtonElement>>;
    Trigger: React.ForwardRefExoticComponent<Omit<import("./button").ButtonProps & React.RefAttributes<HTMLButtonElement>, "ref"> & {
        hideChevron?: boolean;
    } & React.RefAttributes<HTMLButtonElement>>;
    Value: React.ForwardRefExoticComponent<React.HTMLAttributes<HTMLSpanElement> & {
        placeholder?: string;
        loading?: boolean;
        value?: string | JSX.Element;
    } & React.RefAttributes<HTMLSpanElement>>;
    Content: React.ForwardRefExoticComponent<Omit<Omit<import("@radix-ui/react-popover").PopoverContentProps & React.RefAttributes<HTMLDivElement>, "ref"> & {
        disableTransition?: boolean;
    } & React.RefAttributes<HTMLDivElement>, "ref"> & React.RefAttributes<HTMLDivElement>>;
    Check: React.ForwardRefExoticComponent<Omit<import("@tabler/icons-react").IconProps & React.RefAttributes<import("@tabler/icons-react").Icon>, "ref"> & {
        checked?: boolean;
    } & React.RefAttributes<import("@tabler/icons-react").Icon>>;
    FetchMore: React.ForwardRefExoticComponent<Omit<Omit<{
        children?: React.ReactNode;
    } & Omit<Pick<Pick<React.DetailedHTMLProps<React.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "key" | keyof React.HTMLAttributes<HTMLDivElement>> & {
        ref?: React.Ref<HTMLDivElement>;
    } & {
        asChild?: boolean;
    }, "key" | keyof React.HTMLAttributes<HTMLDivElement> | "asChild">, "onSelect" | "disabled" | "value"> & {
        disabled?: boolean;
        onSelect?: (value: string) => void;
        value?: string;
        keywords?: string[];
        forceMount?: boolean;
    } & React.RefAttributes<HTMLDivElement>, "ref"> & React.RefAttributes<HTMLDivElement>, "ref"> & {
        totalCount: number;
        currentLength: number;
        fetchMore: () => void;
    } & React.RefAttributes<HTMLDivElement>>;
    Empty: React.ForwardRefExoticComponent<Omit<Omit<{
        children?: React.ReactNode;
    } & Pick<Pick<React.DetailedHTMLProps<React.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "key" | keyof React.HTMLAttributes<HTMLDivElement>> & {
        ref?: React.Ref<HTMLDivElement>;
    } & {
        asChild?: boolean;
    }, "key" | keyof React.HTMLAttributes<HTMLDivElement> | "asChild"> & React.RefAttributes<HTMLDivElement>, "ref"> & React.RefAttributes<HTMLDivElement>, "ref"> & {
        loading?: boolean;
        error?: ApolloError;
    } & React.RefAttributes<HTMLDivElement>>;
};
