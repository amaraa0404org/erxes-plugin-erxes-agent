import * as React from 'react';
import { DayPicker } from 'react-day-picker';
export type CalendarProps = React.ComponentProps<typeof DayPicker>;
export declare const Calendar: React.ForwardRefExoticComponent<import("react-day-picker").DayPickerProps & React.RefAttributes<React.JSX.Element>>;
export declare const CalendarTwoMonths: React.ForwardRefExoticComponent<import("react-day-picker").DayPickerProps & React.RefAttributes<React.JSX.Element>>;
