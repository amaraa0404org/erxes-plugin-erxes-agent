import React from 'react';
import { ButtonProps } from './button';
export declare const Upload: {
    Root: React.ForwardRefExoticComponent<{
        value: string;
        onChange: (value: {
            url: string;
            fileInfo: any;
        }) => void;
        multiple?: boolean;
    } & Omit<React.DetailedHTMLProps<React.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "ref"> & React.RefAttributes<HTMLDivElement>>;
    Preview: React.ForwardRefExoticComponent<Omit<React.DetailedHTMLProps<React.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "ref"> & {
        onUploadStart?: (fileCount?: number) => void;
        onUploadProgress?: () => void;
        onAllUploadsComplete?: () => void;
    } & React.RefAttributes<HTMLDivElement>>;
    Button: React.ForwardRefExoticComponent<ButtonProps & {
        children?: React.ReactNode;
    } & React.RefAttributes<HTMLButtonElement>>;
    RemoveButton: React.ForwardRefExoticComponent<ButtonProps & {
        children?: React.ReactNode;
    } & React.RefAttributes<HTMLButtonElement>>;
};
