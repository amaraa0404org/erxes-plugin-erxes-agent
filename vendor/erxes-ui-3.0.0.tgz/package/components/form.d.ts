import * as React from 'react';
import { ControllerProps, FieldPath, FieldValues } from 'react-hook-form';
import { Slot, Label as LabelPrimitive } from 'radix-ui';
export declare const Form: (<TFieldValues extends FieldValues, TContext = any, TTransformedValues = TFieldValues>(props: import("react-hook-form").FormProviderProps<TFieldValues, TContext, TTransformedValues>) => React.JSX.Element) & {
    Control: React.ForwardRefExoticComponent<Omit<Slot.SlotProps & React.RefAttributes<HTMLElement>, "ref"> & React.RefAttributes<HTMLElement>>;
    Description: React.ForwardRefExoticComponent<React.HTMLAttributes<HTMLParagraphElement> & React.RefAttributes<HTMLParagraphElement>>;
    Field: <TFieldValues extends FieldValues = FieldValues, TName extends FieldPath<TFieldValues> = FieldPath<TFieldValues>>({ ...props }: ControllerProps<TFieldValues, TName>) => import("react/jsx-runtime").JSX.Element;
    Item: React.ForwardRefExoticComponent<React.HTMLAttributes<HTMLDivElement> & React.RefAttributes<HTMLDivElement>>;
    Label: React.ForwardRefExoticComponent<Omit<Omit<LabelPrimitive.LabelProps & React.RefAttributes<HTMLLabelElement>, "ref"> & import("class-variance-authority").VariantProps<(props?: ({
        variant?: "default" | "peer" | null | undefined;
    } & import("class-variance-authority/types").ClassProp) | undefined) => string> & React.RefAttributes<HTMLLabelElement>, "ref"> & React.RefAttributes<HTMLLabelElement>>;
    Message: React.ForwardRefExoticComponent<React.HTMLAttributes<HTMLParagraphElement> & React.RefAttributes<HTMLParagraphElement>>;
    useField: () => {
        invalid: boolean;
        isDirty: boolean;
        isTouched: boolean;
        isValidating: boolean;
        error?: import("react-hook-form").FieldError;
        id: string;
        name: string;
        formItemId: string;
        formDescriptionId: string;
        formMessageId: string;
    };
};
