import * as React from 'react';
import { Label as LabelPrimitive } from 'radix-ui';
import { type VariantProps } from 'class-variance-authority';
export declare const Label: React.ForwardRefExoticComponent<Omit<LabelPrimitive.LabelProps & React.RefAttributes<HTMLLabelElement>, "ref"> & VariantProps<(props?: ({
    variant?: "default" | "peer" | null | undefined;
} & import("class-variance-authority/types").ClassProp) | undefined) => string> & React.RefAttributes<HTMLLabelElement>>;
