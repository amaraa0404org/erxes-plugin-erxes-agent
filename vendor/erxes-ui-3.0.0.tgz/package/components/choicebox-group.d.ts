import { ComponentPropsWithoutRef, ReactNode } from 'react';
import { type RadioGroupProps } from './radio-group';
export interface ChoiceboxGroupProps extends Omit<RadioGroupProps, 'className'> {
    className?: string;
    direction?: 'column' | 'row';
    spacing?: 'default' | 'tight' | 'loose';
}
export interface ChoiceboxItemProps extends Omit<ComponentPropsWithoutRef<'div'>, 'title'> {
    value: string;
    title?: React.ReactNode;
    disabled?: boolean;
    children: ReactNode;
}
export declare const ChoiceboxGroup: import("react").ForwardRefExoticComponent<ChoiceboxGroupProps & import("react").RefAttributes<HTMLDivElement>> & {
    Item: import("react").ForwardRefExoticComponent<ChoiceboxItemProps & import("react").RefAttributes<HTMLLabelElement>>;
};
