import * as React from 'react';
import { type VariantProps } from 'class-variance-authority';
export declare const badgeVariants: (props?: ({
    variant?: "default" | "destructive" | "secondary" | "ghost" | "warning" | "success" | "info" | null | undefined;
} & import("class-variance-authority/types").ClassProp) | undefined) => string;
export interface BadgeProps extends React.HTMLAttributes<HTMLDivElement>, VariantProps<typeof badgeVariants> {
    onClose?: () => void;
}
export declare const Badge: React.ForwardRefExoticComponent<BadgeProps & React.RefAttributes<HTMLDivElement>>;
