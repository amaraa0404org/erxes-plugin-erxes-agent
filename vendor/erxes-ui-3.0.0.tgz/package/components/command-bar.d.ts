import * as React from 'react';
type CommandBarProps = React.PropsWithChildren<{
    open?: boolean;
    onOpenChange?: (open: boolean) => void;
    defaultOpen?: boolean;
    disableAutoFocus?: boolean;
}>;
export declare const CommandBar: {
    ({ open, onOpenChange, defaultOpen, disableAutoFocus, children, }: CommandBarProps): import("react/jsx-runtime").JSX.Element;
    displayName: string;
} & {
    Value: React.ForwardRefExoticComponent<Omit<React.DetailedHTMLProps<React.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "ref"> & {
        onClose?: () => void;
    } & React.RefAttributes<HTMLDivElement>>;
    Bar: React.ForwardRefExoticComponent<Omit<React.DetailedHTMLProps<React.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "ref"> & React.RefAttributes<HTMLDivElement>>;
};
export {};
