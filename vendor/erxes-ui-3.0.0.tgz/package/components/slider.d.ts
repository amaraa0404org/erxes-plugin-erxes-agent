import * as React from 'react';
import { Slider as SliderPrimitive } from 'radix-ui';
declare const Slider: React.ForwardRefExoticComponent<Omit<SliderPrimitive.SliderProps & React.RefAttributes<HTMLSpanElement>, "ref"> & {
    hideThumb?: boolean;
} & React.RefAttributes<HTMLSpanElement>>;
export { Slider };
