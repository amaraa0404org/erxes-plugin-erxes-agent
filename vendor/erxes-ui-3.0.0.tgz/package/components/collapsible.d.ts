import { Collapsible as CollapsiblePrimitive } from 'radix-ui';
import React from 'react';
export declare const TriggerButton: React.ForwardRefExoticComponent<Omit<import("erxes-ui/components").ButtonProps & React.RefAttributes<HTMLButtonElement>, "ref"> & React.RefAttributes<HTMLButtonElement>>;
export declare const TriggerIcon: React.ForwardRefExoticComponent<Omit<import("@tabler/icons-react").IconProps & React.RefAttributes<import("@tabler/icons-react").Icon>, "ref"> & React.RefAttributes<import("@tabler/icons-react").Icon>>;
export declare const Collapsible: React.ForwardRefExoticComponent<CollapsiblePrimitive.CollapsibleProps & React.RefAttributes<HTMLDivElement>> & {
    Trigger: React.ForwardRefExoticComponent<CollapsiblePrimitive.CollapsibleTriggerProps & React.RefAttributes<HTMLButtonElement>>;
    TriggerIcon: React.ForwardRefExoticComponent<Omit<import("@tabler/icons-react").IconProps & React.RefAttributes<import("@tabler/icons-react").Icon>, "ref"> & React.RefAttributes<import("@tabler/icons-react").Icon>>;
    TriggerButton: React.ForwardRefExoticComponent<Omit<import("erxes-ui/components").ButtonProps & React.RefAttributes<HTMLButtonElement>, "ref"> & React.RefAttributes<HTMLButtonElement>>;
    Content: React.ForwardRefExoticComponent<CollapsiblePrimitive.CollapsibleContentProps & React.RefAttributes<HTMLDivElement>>;
};
