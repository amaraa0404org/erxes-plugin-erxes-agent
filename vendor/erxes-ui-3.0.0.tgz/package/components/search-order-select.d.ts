export type TSearchSortOrder = 'newest' | 'oldest';
export declare const SearchOrderSelect: ({ value, newestLabel, oldestLabel, triggerClassName, onValueChange, }: {
    value: TSearchSortOrder;
    newestLabel: string;
    oldestLabel: string;
    triggerClassName?: string;
    onValueChange: (value: TSearchSortOrder) => void;
}) => import("react/jsx-runtime").JSX.Element;
