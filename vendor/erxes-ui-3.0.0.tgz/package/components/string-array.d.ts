export declare function StringArrayInput({ value, onValueChange, id, placeholder, styleClasses, onBlur, splitOnPaste, }: {
    value: string[];
    onValueChange: (value: string[]) => void;
    id?: string;
    placeholder?: string;
    styleClasses?: {
        inlineTagsContainer?: string;
        input?: string;
        tag?: {
            body?: string;
            closeButton?: string;
        };
    };
    onBlur?: () => void;
    splitOnPaste?: boolean;
}): import("react/jsx-runtime").JSX.Element;
