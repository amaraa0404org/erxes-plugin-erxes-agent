import * as React from 'react';
import { Popover as PopoverPrimitive } from 'radix-ui';
export type PopoverProps = React.ComponentPropsWithoutRef<typeof PopoverPrimitive.Root>;
export declare const popoverClassName = "z-50 w-72 rounded-md bg-background p-4 shadow-lg outline-hidden data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0";
export declare const Popover: React.FC<PopoverPrimitive.PopoverProps> & {
    Trigger: React.ForwardRefExoticComponent<PopoverPrimitive.PopoverTriggerProps & React.RefAttributes<HTMLButtonElement>>;
    Content: React.ForwardRefExoticComponent<Omit<PopoverPrimitive.PopoverContentProps & React.RefAttributes<HTMLDivElement>, "ref"> & {
        disableTransition?: boolean;
    } & React.RefAttributes<HTMLDivElement>>;
    Anchor: React.ForwardRefExoticComponent<PopoverPrimitive.PopoverAnchorProps & React.RefAttributes<HTMLDivElement>>;
    Close: React.ForwardRefExoticComponent<PopoverPrimitive.PopoverCloseProps & React.RefAttributes<HTMLButtonElement>>;
};
