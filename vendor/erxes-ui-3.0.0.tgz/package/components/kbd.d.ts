import * as React from 'react';
/**
 * This component is based on the `kbd` element and supports all of its props
 */
export declare const Kbd: React.ForwardRefExoticComponent<Omit<React.DetailedHTMLProps<React.HTMLAttributes<HTMLElement>, HTMLElement>, "ref"> & {
    variant?: "background" | "foreground";
} & React.RefAttributes<HTMLElement>>;
