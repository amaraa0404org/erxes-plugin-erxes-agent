import * as React from 'react';
import { VariantProps } from 'class-variance-authority';
import { Except } from 'type-fest';
export declare const inputVariants: (props?: ({
    type?: "number" | "default" | "search" | "file" | null | undefined;
    variant?: "default" | "secondary" | null | undefined;
} & import("class-variance-authority/types").ClassProp) | undefined) => string;
export type InputProps = React.InputHTMLAttributes<HTMLInputElement> & Except<VariantProps<typeof inputVariants>, 'type'>;
export declare const InputNumber: React.ForwardRefExoticComponent<(Except<Omit<Omit<import("react-imask").ReactElementProps<HTMLInputElement> & Omit<import("react-imask").ReactMaskProps<HTMLInputElement, {
    [x: string]: unknown;
}>, "ref"> & Omit<import("imask/esm/index").MaskedDateOptions, "mask"> & {
    mask: DateConstructor;
} & {
    ref?: React.Ref<React.ComponentType<import("react-imask").IMaskInputProps<HTMLInputElement>>> | undefined;
}, "ref"> & React.RefAttributes<unknown>, "ref"> | Omit<Omit<import("react-imask").ReactElementProps<HTMLInputElement> & Omit<import("react-imask").ReactMaskProps<HTMLInputElement, {
    [x: string]: unknown;
}>, "ref"> & {
    mask: typeof import("imask/esm/index").MaskedDate;
} & Omit<Omit<import("imask/esm/index").MaskedDateOptions, "mask"> & {
    mask: DateConstructor;
}, "mask"> & {
    ref?: React.Ref<React.ComponentType<import("react-imask").IMaskInputProps<HTMLInputElement>>> | undefined;
}, "ref"> & React.RefAttributes<unknown>, "ref"> | Omit<Omit<import("react-imask").ReactElementProps<HTMLInputElement> & Omit<import("react-imask").ReactMaskProps<HTMLInputElement, {
    [x: string]: unknown;
}>, "ref"> & Partial<Pick<import("imask/esm/index").MaskedNumber, "mask" | "max" | "min" | "format" | "scale" | "eager" | "validate" | "parent" | "prepare" | "prepareChar" | "commit" | "parse" | "overwrite" | "skipInvalid" | "autofix" | "radix" | "thousandsSeparator" | "mapToRadix" | "normalizeZeros" | "padFractionalZeros">> & {
    ref?: React.Ref<React.ComponentType<import("react-imask").IMaskInputProps<HTMLInputElement>>> | undefined;
}, "ref"> & React.RefAttributes<unknown>, "ref"> | Omit<Omit<import("react-imask").ReactElementProps<HTMLInputElement> & Omit<import("react-imask").ReactMaskProps<HTMLInputElement, {
    [x: string]: unknown;
}>, "ref"> & {
    mask: typeof import("imask/esm/index").MaskedNumber;
} & Omit<Partial<Pick<import("imask/esm/index").MaskedNumber, "mask" | "max" | "min" | "format" | "scale" | "eager" | "validate" | "parent" | "prepare" | "prepareChar" | "commit" | "parse" | "overwrite" | "skipInvalid" | "autofix" | "radix" | "thousandsSeparator" | "mapToRadix" | "normalizeZeros" | "padFractionalZeros">>, "mask"> & {
    ref?: React.Ref<React.ComponentType<import("react-imask").IMaskInputProps<HTMLInputElement>>> | undefined;
}, "ref"> & React.RefAttributes<unknown>, "ref"> | Omit<Omit<import("react-imask").ReactElementProps<HTMLInputElement> & Omit<import("react-imask").ReactMaskProps<HTMLInputElement, {
    [x: string]: unknown;
}>, "ref"> & Partial<Pick<import("imask/esm/index").MaskedPattern<string>, "mask" | "format" | "eager" | "lazy" | "validate" | "parent" | "prepare" | "prepareChar" | "commit" | "parse" | "overwrite" | "skipInvalid" | "autofix" | "definitions" | "blocks" | "placeholderChar" | "displayChar">> & {
    ref?: React.Ref<React.ComponentType<import("react-imask").IMaskInputProps<HTMLInputElement>>> | undefined;
}, "ref"> & React.RefAttributes<unknown>, "ref"> | Omit<Omit<import("react-imask").ReactElementProps<HTMLInputElement> & Omit<import("react-imask").ReactMaskProps<HTMLInputElement, {
    [x: string]: unknown;
}>, "ref"> & {
    mask: typeof import("imask/esm/index").MaskedEnum;
} & Omit<import("imask/esm/index").MaskedEnumOptions, "mask"> & {
    ref?: React.Ref<React.ComponentType<import("react-imask").IMaskInputProps<HTMLInputElement>>> | undefined;
}, "ref"> & React.RefAttributes<unknown>, "ref"> | Omit<Omit<import("react-imask").ReactElementProps<HTMLInputElement> & Omit<import("react-imask").ReactMaskProps<HTMLInputElement, {
    [x: string]: unknown;
}>, "ref"> & {
    mask: typeof import("imask/esm/index").MaskedRange;
} & Omit<import("imask/esm/index").MaskedRangeOptions, "mask"> & {
    ref?: React.Ref<React.ComponentType<import("react-imask").IMaskInputProps<HTMLInputElement>>> | undefined;
}, "ref"> & React.RefAttributes<unknown>, "ref"> | Omit<Omit<import("react-imask").ReactElementProps<HTMLInputElement> & Omit<import("react-imask").ReactMaskProps<HTMLInputElement, {
    [x: string]: unknown;
}>, "ref"> & Partial<Pick<import("imask/esm/index").MaskedRegExp, "mask" | "format" | "eager" | "validate" | "parent" | "prepare" | "prepareChar" | "commit" | "parse" | "overwrite" | "skipInvalid" | "autofix">> & {
    ref?: React.Ref<React.ComponentType<import("react-imask").IMaskInputProps<HTMLInputElement>>> | undefined;
}, "ref"> & React.RefAttributes<unknown>, "ref"> | Omit<Omit<import("react-imask").ReactElementProps<HTMLInputElement> & Omit<import("react-imask").ReactMaskProps<HTMLInputElement, {
    [x: string]: unknown;
}>, "ref"> & {
    mask: typeof import("imask/esm/index").MaskedRegExp;
} & Omit<Partial<Pick<import("imask/esm/index").MaskedRegExp, "mask" | "format" | "eager" | "validate" | "parent" | "prepare" | "prepareChar" | "commit" | "parse" | "overwrite" | "skipInvalid" | "autofix">>, "mask"> & {
    ref?: React.Ref<React.ComponentType<import("react-imask").IMaskInputProps<HTMLInputElement>>> | undefined;
}, "ref"> & React.RefAttributes<unknown>, "ref"> | Omit<Omit<import("react-imask").ReactElementProps<HTMLInputElement> & Omit<import("react-imask").ReactMaskProps<HTMLInputElement, {
    [x: string]: unknown;
}>, "ref"> & Partial<Pick<import("imask/esm/index").MaskedFunction<any>, "mask" | "format" | "eager" | "validate" | "parent" | "prepare" | "prepareChar" | "commit" | "parse" | "overwrite" | "skipInvalid" | "autofix">> & {
    ref?: React.Ref<React.ComponentType<import("react-imask").IMaskInputProps<HTMLInputElement>>> | undefined;
}, "ref"> & React.RefAttributes<unknown>, "ref"> | Omit<Omit<import("react-imask").ReactElementProps<HTMLInputElement> & Omit<import("react-imask").ReactMaskProps<HTMLInputElement, {
    [x: string]: unknown;
}>, "ref"> & {
    mask: typeof import("imask/esm/index").MaskedFunction;
} & Omit<Partial<Pick<import("imask/esm/index").MaskedFunction<any>, "mask" | "format" | "eager" | "validate" | "parent" | "prepare" | "prepareChar" | "commit" | "parse" | "overwrite" | "skipInvalid" | "autofix">>, "mask"> & {
    ref?: React.Ref<React.ComponentType<import("react-imask").IMaskInputProps<HTMLInputElement>>> | undefined;
}, "ref"> & React.RefAttributes<unknown>, "ref"> | Omit<Omit<import("react-imask").ReactElementProps<HTMLInputElement> & Omit<import("react-imask").ReactMaskProps<HTMLInputElement, {
    [x: string]: unknown;
}>, "ref"> & {
    mask: typeof import("imask/esm/index").MaskedPattern;
} & Omit<Partial<Pick<import("imask/esm/index").MaskedPattern<string>, "mask" | "format" | "eager" | "lazy" | "validate" | "parent" | "prepare" | "prepareChar" | "commit" | "parse" | "overwrite" | "skipInvalid" | "autofix" | "definitions" | "blocks" | "placeholderChar" | "displayChar">>, "mask"> & {
    ref?: React.Ref<React.ComponentType<import("react-imask").IMaskInputProps<HTMLInputElement>>> | undefined;
}, "ref"> & React.RefAttributes<unknown>, "ref"> | Omit<Omit<import("react-imask").ReactElementProps<HTMLInputElement> & Omit<import("react-imask").ReactMaskProps<HTMLInputElement, {
    [x: string]: unknown;
}>, "ref"> & Partial<Pick<import("imask/esm/index").MaskedDynamic<any>, "mask" | "format" | "eager" | "validate" | "parent" | "prepare" | "prepareChar" | "commit" | "parse" | "overwrite" | "skipInvalid" | "autofix" | "dispatch">> & {
    ref?: React.Ref<React.ComponentType<import("react-imask").IMaskInputProps<HTMLInputElement>>> | undefined;
}, "ref"> & React.RefAttributes<unknown>, "ref"> | Omit<Omit<import("react-imask").ReactElementProps<HTMLInputElement> & Omit<import("react-imask").ReactMaskProps<HTMLInputElement, {
    [x: string]: unknown;
}>, "ref"> & {
    mask: typeof import("imask/esm/index").MaskedDynamic;
} & Omit<Partial<Pick<import("imask/esm/index").MaskedDynamic<any>, "mask" | "format" | "eager" | "validate" | "parent" | "prepare" | "prepareChar" | "commit" | "parse" | "overwrite" | "skipInvalid" | "autofix" | "dispatch">>, "mask"> & {
    ref?: React.Ref<React.ComponentType<import("react-imask").IMaskInputProps<HTMLInputElement>>> | undefined;
}, "ref"> & React.RefAttributes<unknown>, "ref"> | Omit<Omit<import("react-imask").ReactElementProps<HTMLInputElement> & Omit<import("react-imask").ReactMaskProps<HTMLInputElement, {
    [x: string]: unknown;
}>, "ref"> & {
    mask: typeof import("imask/esm/index").Masked;
} & Omit<Partial<Pick<import("imask/esm/index").Masked<any>, "mask" | "format" | "eager" | "validate" | "parent" | "prepare" | "prepareChar" | "commit" | "parse" | "overwrite" | "skipInvalid" | "autofix">>, "mask"> & {
    ref?: React.Ref<React.ComponentType<import("react-imask").IMaskInputProps<HTMLInputElement>>> | undefined;
}, "ref"> & React.RefAttributes<unknown>, "ref"> | Omit<Omit<import("react-imask").ReactElementProps<HTMLInputElement> & Omit<import("react-imask").ReactMaskProps<HTMLInputElement, {
    [x: string]: unknown;
}>, "ref"> & {
    mask: import("imask/esm/index").MaskedDate;
} & Omit<Omit<import("imask/esm/index").MaskedDateOptions, "mask"> & {
    mask: DateConstructor;
}, "mask"> & {
    ref?: React.Ref<React.ComponentType<import("react-imask").IMaskInputProps<HTMLInputElement>>> | undefined;
}, "ref"> & React.RefAttributes<unknown>, "ref"> | Omit<Omit<import("react-imask").ReactElementProps<HTMLInputElement> & Omit<import("react-imask").ReactMaskProps<HTMLInputElement, {
    [x: string]: unknown;
}>, "ref"> & {
    mask: import("imask/esm/index").MaskedNumber;
} & Omit<Partial<Pick<import("imask/esm/index").MaskedNumber, "mask" | "max" | "min" | "format" | "scale" | "eager" | "validate" | "parent" | "prepare" | "prepareChar" | "commit" | "parse" | "overwrite" | "skipInvalid" | "autofix" | "radix" | "thousandsSeparator" | "mapToRadix" | "normalizeZeros" | "padFractionalZeros">>, "mask"> & {
    ref?: React.Ref<React.ComponentType<import("react-imask").IMaskInputProps<HTMLInputElement>>> | undefined;
}, "ref"> & React.RefAttributes<unknown>, "ref"> | Omit<Omit<import("react-imask").ReactElementProps<HTMLInputElement> & Omit<import("react-imask").ReactMaskProps<HTMLInputElement, {
    [x: string]: unknown;
}>, "ref"> & {
    mask: import("imask/esm/index").MaskedEnum;
} & Omit<import("imask/esm/index").MaskedEnumOptions, "mask"> & {
    ref?: React.Ref<React.ComponentType<import("react-imask").IMaskInputProps<HTMLInputElement>>> | undefined;
}, "ref"> & React.RefAttributes<unknown>, "ref"> | Omit<Omit<import("react-imask").ReactElementProps<HTMLInputElement> & Omit<import("react-imask").ReactMaskProps<HTMLInputElement, {
    [x: string]: unknown;
}>, "ref"> & {
    mask: import("imask/esm/index").MaskedRange;
} & Omit<import("imask/esm/index").MaskedRangeOptions, "mask"> & {
    ref?: React.Ref<React.ComponentType<import("react-imask").IMaskInputProps<HTMLInputElement>>> | undefined;
}, "ref"> & React.RefAttributes<unknown>, "ref"> | Omit<Omit<import("react-imask").ReactElementProps<HTMLInputElement> & Omit<import("react-imask").ReactMaskProps<HTMLInputElement, {
    [x: string]: unknown;
}>, "ref"> & {
    mask: import("imask/esm/index").MaskedRegExp;
} & Omit<Partial<Pick<import("imask/esm/index").MaskedRegExp, "mask" | "format" | "eager" | "validate" | "parent" | "prepare" | "prepareChar" | "commit" | "parse" | "overwrite" | "skipInvalid" | "autofix">>, "mask"> & {
    ref?: React.Ref<React.ComponentType<import("react-imask").IMaskInputProps<HTMLInputElement>>> | undefined;
}, "ref"> & React.RefAttributes<unknown>, "ref"> | Omit<Omit<import("react-imask").ReactElementProps<HTMLInputElement> & Omit<import("react-imask").ReactMaskProps<HTMLInputElement, {
    [x: string]: unknown;
}>, "ref"> & {
    mask: import("imask/esm/index").MaskedFunction<any>;
} & Omit<Partial<Pick<import("imask/esm/index").MaskedFunction<any>, "mask" | "format" | "eager" | "validate" | "parent" | "prepare" | "prepareChar" | "commit" | "parse" | "overwrite" | "skipInvalid" | "autofix">>, "mask"> & {
    ref?: React.Ref<React.ComponentType<import("react-imask").IMaskInputProps<HTMLInputElement>>> | undefined;
}, "ref"> & React.RefAttributes<unknown>, "ref"> | Omit<Omit<import("react-imask").ReactElementProps<HTMLInputElement> & Omit<import("react-imask").ReactMaskProps<HTMLInputElement, {
    [x: string]: unknown;
}>, "ref"> & {
    mask: import("imask/esm/index").MaskedPattern<string>;
} & Omit<Partial<Pick<import("imask/esm/index").MaskedPattern<string>, "mask" | "format" | "eager" | "lazy" | "validate" | "parent" | "prepare" | "prepareChar" | "commit" | "parse" | "overwrite" | "skipInvalid" | "autofix" | "definitions" | "blocks" | "placeholderChar" | "displayChar">>, "mask"> & {
    ref?: React.Ref<React.ComponentType<import("react-imask").IMaskInputProps<HTMLInputElement>>> | undefined;
}, "ref"> & React.RefAttributes<unknown>, "ref"> | Omit<Omit<import("react-imask").ReactElementProps<HTMLInputElement> & Omit<import("react-imask").ReactMaskProps<HTMLInputElement, {
    [x: string]: unknown;
}>, "ref"> & {
    mask: import("imask/esm/index").MaskedDynamic<any>;
} & Omit<Partial<Pick<import("imask/esm/index").MaskedDynamic<any>, "mask" | "format" | "eager" | "validate" | "parent" | "prepare" | "prepareChar" | "commit" | "parse" | "overwrite" | "skipInvalid" | "autofix" | "dispatch">>, "mask"> & {
    ref?: React.Ref<React.ComponentType<import("react-imask").IMaskInputProps<HTMLInputElement>>> | undefined;
}, "ref"> & React.RefAttributes<unknown>, "ref"> | Omit<Omit<import("react-imask").ReactElementProps<HTMLInputElement> & Omit<import("react-imask").ReactMaskProps<HTMLInputElement, {
    [x: string]: unknown;
}>, "ref"> & {
    mask: import("imask/esm/index").Masked<any>;
} & Omit<Partial<Pick<import("imask/esm/index").Masked<any>, "mask" | "format" | "eager" | "validate" | "parent" | "prepare" | "prepareChar" | "commit" | "parse" | "overwrite" | "skipInvalid" | "autofix">>, "mask"> & {
    ref?: React.Ref<React.ComponentType<import("react-imask").IMaskInputProps<HTMLInputElement>>> | undefined;
}, "ref"> & React.RefAttributes<unknown>, "ref">, "onChange" | "value"> & {
    onChange?: (value?: number | "") => void;
    value?: number;
}) & React.RefAttributes<unknown>>;
export declare const Input: React.ForwardRefExoticComponent<React.InputHTMLAttributes<HTMLInputElement> & {
    variant?: "default" | "secondary" | null | undefined;
} & React.RefAttributes<HTMLInputElement>> & {
    Number: React.ForwardRefExoticComponent<(Except<Omit<Omit<import("react-imask").ReactElementProps<HTMLInputElement> & Omit<import("react-imask").ReactMaskProps<HTMLInputElement, {
        [x: string]: unknown;
    }>, "ref"> & Omit<import("imask/esm/index").MaskedDateOptions, "mask"> & {
        mask: DateConstructor;
    } & {
        ref?: React.Ref<React.ComponentType<import("react-imask").IMaskInputProps<HTMLInputElement>>> | undefined;
    }, "ref"> & React.RefAttributes<unknown>, "ref"> | Omit<Omit<import("react-imask").ReactElementProps<HTMLInputElement> & Omit<import("react-imask").ReactMaskProps<HTMLInputElement, {
        [x: string]: unknown;
    }>, "ref"> & {
        mask: typeof import("imask/esm/index").MaskedDate;
    } & Omit<Omit<import("imask/esm/index").MaskedDateOptions, "mask"> & {
        mask: DateConstructor;
    }, "mask"> & {
        ref?: React.Ref<React.ComponentType<import("react-imask").IMaskInputProps<HTMLInputElement>>> | undefined;
    }, "ref"> & React.RefAttributes<unknown>, "ref"> | Omit<Omit<import("react-imask").ReactElementProps<HTMLInputElement> & Omit<import("react-imask").ReactMaskProps<HTMLInputElement, {
        [x: string]: unknown;
    }>, "ref"> & Partial<Pick<import("imask/esm/index").MaskedNumber, "mask" | "max" | "min" | "format" | "scale" | "eager" | "validate" | "parent" | "prepare" | "prepareChar" | "commit" | "parse" | "overwrite" | "skipInvalid" | "autofix" | "radix" | "thousandsSeparator" | "mapToRadix" | "normalizeZeros" | "padFractionalZeros">> & {
        ref?: React.Ref<React.ComponentType<import("react-imask").IMaskInputProps<HTMLInputElement>>> | undefined;
    }, "ref"> & React.RefAttributes<unknown>, "ref"> | Omit<Omit<import("react-imask").ReactElementProps<HTMLInputElement> & Omit<import("react-imask").ReactMaskProps<HTMLInputElement, {
        [x: string]: unknown;
    }>, "ref"> & {
        mask: typeof import("imask/esm/index").MaskedNumber;
    } & Omit<Partial<Pick<import("imask/esm/index").MaskedNumber, "mask" | "max" | "min" | "format" | "scale" | "eager" | "validate" | "parent" | "prepare" | "prepareChar" | "commit" | "parse" | "overwrite" | "skipInvalid" | "autofix" | "radix" | "thousandsSeparator" | "mapToRadix" | "normalizeZeros" | "padFractionalZeros">>, "mask"> & {
        ref?: React.Ref<React.ComponentType<import("react-imask").IMaskInputProps<HTMLInputElement>>> | undefined;
    }, "ref"> & React.RefAttributes<unknown>, "ref"> | Omit<Omit<import("react-imask").ReactElementProps<HTMLInputElement> & Omit<import("react-imask").ReactMaskProps<HTMLInputElement, {
        [x: string]: unknown;
    }>, "ref"> & Partial<Pick<import("imask/esm/index").MaskedPattern<string>, "mask" | "format" | "eager" | "lazy" | "validate" | "parent" | "prepare" | "prepareChar" | "commit" | "parse" | "overwrite" | "skipInvalid" | "autofix" | "definitions" | "blocks" | "placeholderChar" | "displayChar">> & {
        ref?: React.Ref<React.ComponentType<import("react-imask").IMaskInputProps<HTMLInputElement>>> | undefined;
    }, "ref"> & React.RefAttributes<unknown>, "ref"> | Omit<Omit<import("react-imask").ReactElementProps<HTMLInputElement> & Omit<import("react-imask").ReactMaskProps<HTMLInputElement, {
        [x: string]: unknown;
    }>, "ref"> & {
        mask: typeof import("imask/esm/index").MaskedEnum;
    } & Omit<import("imask/esm/index").MaskedEnumOptions, "mask"> & {
        ref?: React.Ref<React.ComponentType<import("react-imask").IMaskInputProps<HTMLInputElement>>> | undefined;
    }, "ref"> & React.RefAttributes<unknown>, "ref"> | Omit<Omit<import("react-imask").ReactElementProps<HTMLInputElement> & Omit<import("react-imask").ReactMaskProps<HTMLInputElement, {
        [x: string]: unknown;
    }>, "ref"> & {
        mask: typeof import("imask/esm/index").MaskedRange;
    } & Omit<import("imask/esm/index").MaskedRangeOptions, "mask"> & {
        ref?: React.Ref<React.ComponentType<import("react-imask").IMaskInputProps<HTMLInputElement>>> | undefined;
    }, "ref"> & React.RefAttributes<unknown>, "ref"> | Omit<Omit<import("react-imask").ReactElementProps<HTMLInputElement> & Omit<import("react-imask").ReactMaskProps<HTMLInputElement, {
        [x: string]: unknown;
    }>, "ref"> & Partial<Pick<import("imask/esm/index").MaskedRegExp, "mask" | "format" | "eager" | "validate" | "parent" | "prepare" | "prepareChar" | "commit" | "parse" | "overwrite" | "skipInvalid" | "autofix">> & {
        ref?: React.Ref<React.ComponentType<import("react-imask").IMaskInputProps<HTMLInputElement>>> | undefined;
    }, "ref"> & React.RefAttributes<unknown>, "ref"> | Omit<Omit<import("react-imask").ReactElementProps<HTMLInputElement> & Omit<import("react-imask").ReactMaskProps<HTMLInputElement, {
        [x: string]: unknown;
    }>, "ref"> & {
        mask: typeof import("imask/esm/index").MaskedRegExp;
    } & Omit<Partial<Pick<import("imask/esm/index").MaskedRegExp, "mask" | "format" | "eager" | "validate" | "parent" | "prepare" | "prepareChar" | "commit" | "parse" | "overwrite" | "skipInvalid" | "autofix">>, "mask"> & {
        ref?: React.Ref<React.ComponentType<import("react-imask").IMaskInputProps<HTMLInputElement>>> | undefined;
    }, "ref"> & React.RefAttributes<unknown>, "ref"> | Omit<Omit<import("react-imask").ReactElementProps<HTMLInputElement> & Omit<import("react-imask").ReactMaskProps<HTMLInputElement, {
        [x: string]: unknown;
    }>, "ref"> & Partial<Pick<import("imask/esm/index").MaskedFunction<any>, "mask" | "format" | "eager" | "validate" | "parent" | "prepare" | "prepareChar" | "commit" | "parse" | "overwrite" | "skipInvalid" | "autofix">> & {
        ref?: React.Ref<React.ComponentType<import("react-imask").IMaskInputProps<HTMLInputElement>>> | undefined;
    }, "ref"> & React.RefAttributes<unknown>, "ref"> | Omit<Omit<import("react-imask").ReactElementProps<HTMLInputElement> & Omit<import("react-imask").ReactMaskProps<HTMLInputElement, {
        [x: string]: unknown;
    }>, "ref"> & {
        mask: typeof import("imask/esm/index").MaskedFunction;
    } & Omit<Partial<Pick<import("imask/esm/index").MaskedFunction<any>, "mask" | "format" | "eager" | "validate" | "parent" | "prepare" | "prepareChar" | "commit" | "parse" | "overwrite" | "skipInvalid" | "autofix">>, "mask"> & {
        ref?: React.Ref<React.ComponentType<import("react-imask").IMaskInputProps<HTMLInputElement>>> | undefined;
    }, "ref"> & React.RefAttributes<unknown>, "ref"> | Omit<Omit<import("react-imask").ReactElementProps<HTMLInputElement> & Omit<import("react-imask").ReactMaskProps<HTMLInputElement, {
        [x: string]: unknown;
    }>, "ref"> & {
        mask: typeof import("imask/esm/index").MaskedPattern;
    } & Omit<Partial<Pick<import("imask/esm/index").MaskedPattern<string>, "mask" | "format" | "eager" | "lazy" | "validate" | "parent" | "prepare" | "prepareChar" | "commit" | "parse" | "overwrite" | "skipInvalid" | "autofix" | "definitions" | "blocks" | "placeholderChar" | "displayChar">>, "mask"> & {
        ref?: React.Ref<React.ComponentType<import("react-imask").IMaskInputProps<HTMLInputElement>>> | undefined;
    }, "ref"> & React.RefAttributes<unknown>, "ref"> | Omit<Omit<import("react-imask").ReactElementProps<HTMLInputElement> & Omit<import("react-imask").ReactMaskProps<HTMLInputElement, {
        [x: string]: unknown;
    }>, "ref"> & Partial<Pick<import("imask/esm/index").MaskedDynamic<any>, "mask" | "format" | "eager" | "validate" | "parent" | "prepare" | "prepareChar" | "commit" | "parse" | "overwrite" | "skipInvalid" | "autofix" | "dispatch">> & {
        ref?: React.Ref<React.ComponentType<import("react-imask").IMaskInputProps<HTMLInputElement>>> | undefined;
    }, "ref"> & React.RefAttributes<unknown>, "ref"> | Omit<Omit<import("react-imask").ReactElementProps<HTMLInputElement> & Omit<import("react-imask").ReactMaskProps<HTMLInputElement, {
        [x: string]: unknown;
    }>, "ref"> & {
        mask: typeof import("imask/esm/index").MaskedDynamic;
    } & Omit<Partial<Pick<import("imask/esm/index").MaskedDynamic<any>, "mask" | "format" | "eager" | "validate" | "parent" | "prepare" | "prepareChar" | "commit" | "parse" | "overwrite" | "skipInvalid" | "autofix" | "dispatch">>, "mask"> & {
        ref?: React.Ref<React.ComponentType<import("react-imask").IMaskInputProps<HTMLInputElement>>> | undefined;
    }, "ref"> & React.RefAttributes<unknown>, "ref"> | Omit<Omit<import("react-imask").ReactElementProps<HTMLInputElement> & Omit<import("react-imask").ReactMaskProps<HTMLInputElement, {
        [x: string]: unknown;
    }>, "ref"> & {
        mask: typeof import("imask/esm/index").Masked;
    } & Omit<Partial<Pick<import("imask/esm/index").Masked<any>, "mask" | "format" | "eager" | "validate" | "parent" | "prepare" | "prepareChar" | "commit" | "parse" | "overwrite" | "skipInvalid" | "autofix">>, "mask"> & {
        ref?: React.Ref<React.ComponentType<import("react-imask").IMaskInputProps<HTMLInputElement>>> | undefined;
    }, "ref"> & React.RefAttributes<unknown>, "ref"> | Omit<Omit<import("react-imask").ReactElementProps<HTMLInputElement> & Omit<import("react-imask").ReactMaskProps<HTMLInputElement, {
        [x: string]: unknown;
    }>, "ref"> & {
        mask: import("imask/esm/index").MaskedDate;
    } & Omit<Omit<import("imask/esm/index").MaskedDateOptions, "mask"> & {
        mask: DateConstructor;
    }, "mask"> & {
        ref?: React.Ref<React.ComponentType<import("react-imask").IMaskInputProps<HTMLInputElement>>> | undefined;
    }, "ref"> & React.RefAttributes<unknown>, "ref"> | Omit<Omit<import("react-imask").ReactElementProps<HTMLInputElement> & Omit<import("react-imask").ReactMaskProps<HTMLInputElement, {
        [x: string]: unknown;
    }>, "ref"> & {
        mask: import("imask/esm/index").MaskedNumber;
    } & Omit<Partial<Pick<import("imask/esm/index").MaskedNumber, "mask" | "max" | "min" | "format" | "scale" | "eager" | "validate" | "parent" | "prepare" | "prepareChar" | "commit" | "parse" | "overwrite" | "skipInvalid" | "autofix" | "radix" | "thousandsSeparator" | "mapToRadix" | "normalizeZeros" | "padFractionalZeros">>, "mask"> & {
        ref?: React.Ref<React.ComponentType<import("react-imask").IMaskInputProps<HTMLInputElement>>> | undefined;
    }, "ref"> & React.RefAttributes<unknown>, "ref"> | Omit<Omit<import("react-imask").ReactElementProps<HTMLInputElement> & Omit<import("react-imask").ReactMaskProps<HTMLInputElement, {
        [x: string]: unknown;
    }>, "ref"> & {
        mask: import("imask/esm/index").MaskedEnum;
    } & Omit<import("imask/esm/index").MaskedEnumOptions, "mask"> & {
        ref?: React.Ref<React.ComponentType<import("react-imask").IMaskInputProps<HTMLInputElement>>> | undefined;
    }, "ref"> & React.RefAttributes<unknown>, "ref"> | Omit<Omit<import("react-imask").ReactElementProps<HTMLInputElement> & Omit<import("react-imask").ReactMaskProps<HTMLInputElement, {
        [x: string]: unknown;
    }>, "ref"> & {
        mask: import("imask/esm/index").MaskedRange;
    } & Omit<import("imask/esm/index").MaskedRangeOptions, "mask"> & {
        ref?: React.Ref<React.ComponentType<import("react-imask").IMaskInputProps<HTMLInputElement>>> | undefined;
    }, "ref"> & React.RefAttributes<unknown>, "ref"> | Omit<Omit<import("react-imask").ReactElementProps<HTMLInputElement> & Omit<import("react-imask").ReactMaskProps<HTMLInputElement, {
        [x: string]: unknown;
    }>, "ref"> & {
        mask: import("imask/esm/index").MaskedRegExp;
    } & Omit<Partial<Pick<import("imask/esm/index").MaskedRegExp, "mask" | "format" | "eager" | "validate" | "parent" | "prepare" | "prepareChar" | "commit" | "parse" | "overwrite" | "skipInvalid" | "autofix">>, "mask"> & {
        ref?: React.Ref<React.ComponentType<import("react-imask").IMaskInputProps<HTMLInputElement>>> | undefined;
    }, "ref"> & React.RefAttributes<unknown>, "ref"> | Omit<Omit<import("react-imask").ReactElementProps<HTMLInputElement> & Omit<import("react-imask").ReactMaskProps<HTMLInputElement, {
        [x: string]: unknown;
    }>, "ref"> & {
        mask: import("imask/esm/index").MaskedFunction<any>;
    } & Omit<Partial<Pick<import("imask/esm/index").MaskedFunction<any>, "mask" | "format" | "eager" | "validate" | "parent" | "prepare" | "prepareChar" | "commit" | "parse" | "overwrite" | "skipInvalid" | "autofix">>, "mask"> & {
        ref?: React.Ref<React.ComponentType<import("react-imask").IMaskInputProps<HTMLInputElement>>> | undefined;
    }, "ref"> & React.RefAttributes<unknown>, "ref"> | Omit<Omit<import("react-imask").ReactElementProps<HTMLInputElement> & Omit<import("react-imask").ReactMaskProps<HTMLInputElement, {
        [x: string]: unknown;
    }>, "ref"> & {
        mask: import("imask/esm/index").MaskedPattern<string>;
    } & Omit<Partial<Pick<import("imask/esm/index").MaskedPattern<string>, "mask" | "format" | "eager" | "lazy" | "validate" | "parent" | "prepare" | "prepareChar" | "commit" | "parse" | "overwrite" | "skipInvalid" | "autofix" | "definitions" | "blocks" | "placeholderChar" | "displayChar">>, "mask"> & {
        ref?: React.Ref<React.ComponentType<import("react-imask").IMaskInputProps<HTMLInputElement>>> | undefined;
    }, "ref"> & React.RefAttributes<unknown>, "ref"> | Omit<Omit<import("react-imask").ReactElementProps<HTMLInputElement> & Omit<import("react-imask").ReactMaskProps<HTMLInputElement, {
        [x: string]: unknown;
    }>, "ref"> & {
        mask: import("imask/esm/index").MaskedDynamic<any>;
    } & Omit<Partial<Pick<import("imask/esm/index").MaskedDynamic<any>, "mask" | "format" | "eager" | "validate" | "parent" | "prepare" | "prepareChar" | "commit" | "parse" | "overwrite" | "skipInvalid" | "autofix" | "dispatch">>, "mask"> & {
        ref?: React.Ref<React.ComponentType<import("react-imask").IMaskInputProps<HTMLInputElement>>> | undefined;
    }, "ref"> & React.RefAttributes<unknown>, "ref"> | Omit<Omit<import("react-imask").ReactElementProps<HTMLInputElement> & Omit<import("react-imask").ReactMaskProps<HTMLInputElement, {
        [x: string]: unknown;
    }>, "ref"> & {
        mask: import("imask/esm/index").Masked<any>;
    } & Omit<Partial<Pick<import("imask/esm/index").Masked<any>, "mask" | "format" | "eager" | "validate" | "parent" | "prepare" | "prepareChar" | "commit" | "parse" | "overwrite" | "skipInvalid" | "autofix">>, "mask"> & {
        ref?: React.Ref<React.ComponentType<import("react-imask").IMaskInputProps<HTMLInputElement>>> | undefined;
    }, "ref"> & React.RefAttributes<unknown>, "ref">, "onChange" | "value"> & {
        onChange?: (value?: number | "") => void;
        value?: number;
    }) & React.RefAttributes<unknown>>;
};
