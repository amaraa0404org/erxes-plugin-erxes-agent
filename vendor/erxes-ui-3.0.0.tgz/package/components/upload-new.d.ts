import { UseErxesUploadReturn } from 'erxes-ui/hooks/use-upload-new';
export declare const getFileIcon: (fileType: string, fileName: string) => import("react/jsx-runtime").JSX.Element;
export declare const formatBytes: (bytes: number, decimals?: number, size?: "bytes" | "KB" | "MB" | "GB" | "TB" | "PB" | "EB" | "ZB" | "YB") => string;
type DropzoneContextType = Omit<UseErxesUploadReturn, 'getRootProps' | 'getInputProps'>;
type DropzoneProps = UseErxesUploadReturn & {
    className?: string;
};
declare const Dropzone: ({ className, children, getRootProps, getInputProps, ...restProps }: React.PropsWithChildren<DropzoneProps>) => import("react/jsx-runtime").JSX.Element;
declare const DropzoneContent: ({ className }: {
    className?: string;
}) => import("react/jsx-runtime").JSX.Element;
declare const DropzoneEmptyState: ({ className }: {
    className?: string;
}) => import("react/jsx-runtime").JSX.Element | null;
declare const useDropzoneContext: () => DropzoneContextType;
export { Dropzone, DropzoneContent, DropzoneEmptyState, useDropzoneContext };
