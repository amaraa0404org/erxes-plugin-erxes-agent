import { type ClassValue } from 'clsx';
export declare function cn(...inputs: ClassValue[]): string;
export declare function fixNum(value: any, p?: number): number;
export declare function displayNum(value: any, p?: number): string;
/**
 * Send desktop notification
 */
export declare const sendDesktopNotification: (doc: {
    title: string;
    content?: string;
}) => void;
