import { ThemeOption } from '../types';
export declare const themeState: import("jotai").WritableAtom<ThemeOption, [ThemeOption | typeof import("jotai/utils").RESET | ((prev: ThemeOption) => ThemeOption | typeof import("jotai/utils").RESET)], void>;
