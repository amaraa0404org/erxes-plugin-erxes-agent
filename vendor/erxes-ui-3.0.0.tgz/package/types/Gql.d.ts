export interface ICursorListResponse<T> {
    [key: string]: {
        list: T[];
        totalCount: number;
        pageInfo: {
            hasNextPage: boolean;
            hasPreviousPage: boolean;
            startCursor: string;
            endCursor: string;
        };
    };
}
export declare const PAGE_INFO_FRAGMENT: import("@apollo/client").DocumentNode;
export declare const ATTACHMENT_FRAGMENT: import("@apollo/client").DocumentNode;
