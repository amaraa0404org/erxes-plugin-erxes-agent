export declare enum ValidationStatus {
    Valid = "valid",
    Invalid = "invalid"
}
