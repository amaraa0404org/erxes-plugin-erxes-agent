export declare const useIsMatchingLocation: (basePath?: string) => (path: string) => boolean;
