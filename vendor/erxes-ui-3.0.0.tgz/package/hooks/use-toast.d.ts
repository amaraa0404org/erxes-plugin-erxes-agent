import * as React from 'react';
import type { ToastActionElement, ToastProps } from '../components/toasts';
type ToasterToast = ToastProps & {
    id: string;
    title?: React.ReactNode;
    description?: React.ReactNode;
    action?: ToastActionElement;
    dismissOnPointerEnter?: boolean;
};
type Toast = Omit<ToasterToast, 'id'>;
export declare function toast({ ...props }: Toast): {
    id: string;
    dismiss: () => void;
    update: (props: ToasterToast) => void;
};
export declare function useToast(): {
    toast: typeof toast;
    dismiss: (toastId?: string) => void;
    toasts: ToasterToast[];
};
export {};
