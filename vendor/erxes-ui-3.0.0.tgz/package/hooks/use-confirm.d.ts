import { z } from 'zod';
type OptionProps = {
    okLabel?: string;
    cancelLabel?: string;
    description?: string;
    confirmationValue?: string;
};
export declare const confirmValidationSchema: z.ZodObject<{
    confirm: z.ZodString;
}, "strip", z.ZodTypeAny, {
    confirm: string;
}, {
    confirm: string;
}>;
export type FormType = z.infer<typeof confirmValidationSchema>;
export declare const useConfirm: () => {
    confirm: ({ message, options }: {
        message: string;
        options?: OptionProps;
    }) => Promise<void>;
};
export {};
