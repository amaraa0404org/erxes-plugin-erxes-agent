export type QueryState<T> = [T | null, (value: T | null) => void];
export declare function useQueryState<T>(queryKey: string, options?: {
    defaultValue?: T;
}): QueryState<T>;
type QueryTypes = Record<string, unknown>;
type QueryValues<T extends QueryTypes> = {
    [K in keyof T]: T[K] | null;
};
export declare function useMultiQueryState<T extends QueryTypes>(queryKeys: (keyof T)[]): [QueryValues<T>, (values: Partial<QueryValues<T>>) => void];
export declare const useNonNullMultiQueryState: <T extends QueryTypes>(queryKeys: (keyof T)[]) => QueryValues<T>;
export declare function useSetQueryStateByKey(): (key: string, value: string) => void;
export declare function useRemoveQueryStateByKey(): (key: string) => void;
export {};
