export declare const useCursorScroll: ({ dataLength, hasPreviousPage, offset, }: {
    dataLength?: number;
    hasPreviousPage?: boolean;
    offset?: number;
}) => {
    scrollRef: import("react").RefObject<HTMLDivElement>;
    isFetchBackward: boolean;
    setIsFetchBackward: import("react").Dispatch<import("react").SetStateAction<boolean>>;
    distanceFromBottomRef: import("react").MutableRefObject<number>;
};
