import { type FileError, type FileRejection } from 'react-dropzone';
export interface FileWithPreview extends File {
    preview?: string;
    errors: readonly FileError[];
}
type UseErxesUploadOptions = {
    /**
     * Allowed MIME types for each file upload (e.g `image/png`, `text/html`, etc). Wildcards are also supported (e.g `image/*`).
     *
     * Defaults to allowing uploading of all MIME types.
     */
    allowedMimeTypes?: string[];
    /**
     * Maximum upload size of each file allowed in bytes. (e.g 1000 bytes = 1 KB)
     */
    maxFileSize?: number;
    /**
     * Maximum number of files allowed per upload.
     */
    maxFiles?: number;
    onFilesAdded?: (addedFiles: {
        name: string;
        url: string;
        type: string;
        size: number;
    }[]) => void;
};
type UseErxesUploadReturn = ReturnType<typeof useErxesUpload>;
type FileUploadResponse = {
    name: string;
    message: string | undefined;
    url?: string;
};
declare const useErxesUpload: (options: UseErxesUploadOptions) => {
    open: () => void;
    isFocused: boolean;
    isDragActive: boolean;
    isDragAccept: boolean;
    isDragReject: boolean;
    isFileDialogActive: boolean;
    acceptedFiles: readonly import("react-dropzone").FileWithPath[];
    fileRejections: readonly FileRejection[];
    rootRef: React.RefObject<HTMLElement>;
    inputRef: React.RefObject<HTMLInputElement>;
    getRootProps: <T extends import("react-dropzone").DropzoneRootProps>(props?: T) => T;
    getInputProps: <T extends import("react-dropzone").DropzoneInputProps>(props?: T) => T;
    files: FileWithPreview[];
    setFiles: import("react").Dispatch<import("react").SetStateAction<FileWithPreview[]>>;
    successes: string[];
    isSuccess: boolean;
    loading: boolean;
    errors: {
        name: string;
        message?: string;
        url?: string;
    }[];
    setErrors: import("react").Dispatch<import("react").SetStateAction<{
        name: string;
        message?: string;
        url?: string;
    }[]>>;
    onUpload: () => Promise<void>;
    uploadFile: (file: File) => Promise<FileUploadResponse>;
    maxFileSize: number;
    maxFiles: number;
    allowedMimeTypes: string[];
};
export { useErxesUpload, type UseErxesUploadOptions, type UseErxesUploadReturn, };
export declare const useRemoveFile: () => {
    isLoading: boolean;
    error: string | null;
    removeFile: (fileName: string, afterRemove: (status: string) => void) => Promise<void>;
};
