export type ChunkedUploadResult = {
    name: string;
    url: string;
    type: string;
    size: number;
};
export declare const useUploadChunked: () => {
    upload: (file: File) => Promise<ChunkedUploadResult | null>;
    cancel: () => void;
    progress: number;
    loading: boolean;
    error: string | null;
};
