type FileInfo = {
    name: string;
    size: number;
    type: string;
    duration: number;
};
type AfterUploadParams = {
    status: 'ok' | 'error';
    response: any;
    fileInfo: FileInfo;
};
type AfterReadParams = {
    result: any;
    fileInfo: FileInfo;
};
type UploadProps = {
    files: FileList | null;
    beforeUpload?: () => void;
    afterUpload: (params: AfterUploadParams) => void;
    afterRead?: (params: AfterReadParams) => void;
    url?: string;
    kind?: string;
    userId?: string;
    responseType?: string;
    extraFormData?: Array<{
        key: string;
        value: string;
    }>;
    maxHeight?: number;
    maxWidth?: number;
};
type RemoveProps = {
    fileName: string;
    url?: string;
    afterRemove: ({ status }: {
        status: string;
    }) => any;
};
export declare const useUpload: () => {
    isLoading: boolean;
    status: boolean;
    upload: ({ files, beforeUpload, afterUpload, afterRead, url, kind, responseType, userId, maxHeight, maxWidth, }: UploadProps) => void;
    remove: ({ fileName, url, afterRemove, }: RemoveProps) => void;
};
export {};
