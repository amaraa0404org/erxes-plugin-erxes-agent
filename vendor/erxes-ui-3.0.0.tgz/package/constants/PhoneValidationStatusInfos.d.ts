export declare const PhoneIconComponents: {
    readonly IconCircleDashedCheck: import("react").ForwardRefExoticComponent<import("@tabler/icons-react").IconProps & import("react").RefAttributes<import("@tabler/icons-react").Icon>>;
    readonly IconCircleDashed: import("react").ForwardRefExoticComponent<import("@tabler/icons-react").IconProps & import("react").RefAttributes<import("@tabler/icons-react").Icon>>;
    readonly IconDeviceMobile: import("react").ForwardRefExoticComponent<import("@tabler/icons-react").IconProps & import("react").RefAttributes<import("@tabler/icons-react").Icon>>;
};
export type TPhoneValidationStatusInfo = {
    label: string;
    value: string;
    icon: keyof typeof PhoneIconComponents;
    className?: string;
}[];
export declare const PHONE_VALIDATION_STATUS_INFOS: TPhoneValidationStatusInfo;
