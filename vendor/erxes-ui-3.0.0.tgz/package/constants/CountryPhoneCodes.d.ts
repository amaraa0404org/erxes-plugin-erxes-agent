import { TCountryCode } from 'erxes-ui/types/CountryCode';
export declare const CountryPhoneCodes: TCountryCode[];
