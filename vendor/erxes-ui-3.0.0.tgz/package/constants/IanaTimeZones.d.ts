/**
 * Standard IANA time zones.
 * @see https://www.iana.org/time-zones
 */
export declare const IANA_TIME_ZONES: string[];
