export declare const EmailIconComponents: {
    readonly IconCircleDashedCheck: import("react").ForwardRefExoticComponent<import("@tabler/icons-react").IconProps & import("react").RefAttributes<import("@tabler/icons-react").Icon>>;
    readonly IconCircleDashed: import("react").ForwardRefExoticComponent<import("@tabler/icons-react").IconProps & import("react").RefAttributes<import("@tabler/icons-react").Icon>>;
};
export type TEmailValidationStatusInfo = {
    label: string;
    value: string;
    icon: keyof typeof EmailIconComponents;
    className?: string;
}[];
export declare const EMAIL_VALIDATION_STATUS_INFOS: TEmailValidationStatusInfo;
