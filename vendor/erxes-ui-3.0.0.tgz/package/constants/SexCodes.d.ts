import { SexCode } from 'erxes-ui/types';
export declare const SexCodes: Record<SexCode, {
    label: string;
}>;
