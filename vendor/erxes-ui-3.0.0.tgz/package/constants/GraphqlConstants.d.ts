export declare const GQL_PAGE_INFO = "\n  totalCount\n  pageInfo {\n    hasNextPage\n    hasPreviousPage\n    startCursor\n    endCursor\n  }\n";
export declare const GQL_CURSOR_PARAM_DEFS = "\n  $cursor: String\n  $cursorMode: CURSOR_MODE\n  $direction: CURSOR_DIRECTION\n  $limit: Int\n";
export declare const GQL_CURSOR_PARAMS = "\n  cursor: $cursor\n  cursorMode: $cursorMode\n  direction: $direction\n  limit: $limit\n";
