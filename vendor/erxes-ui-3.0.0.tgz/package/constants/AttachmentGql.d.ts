export declare const ATTACHMENT_GQL = "\n  attachments {\n    url\n    name\n    type\n    size\n    duration\n  }\n";
