import { TablerIcon } from '@tabler/icons-react';
import { CurrencyCode } from 'erxes-ui/types';
export declare const CURRENCY_CODES: Record<CurrencyCode, {
    label: string;
    Icon: TablerIcon;
}>;
