export declare const DateFilterCommand: ({ value, selected, onSelect, focusOnMount, label, }: {
    value: string;
    selected: string;
    onSelect: (value: string | null) => void;
    focusOnMount?: boolean;
    label?: string;
}) => import("react/jsx-runtime").JSX.Element;
