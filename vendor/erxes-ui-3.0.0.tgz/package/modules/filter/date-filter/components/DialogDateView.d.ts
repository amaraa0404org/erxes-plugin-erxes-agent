export declare const FilterDialogDateView: ({ filterKey, label, }: {
    filterKey: string;
    label?: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const DateRangeDialogContent: ({ label, value, onApply, }: {
    label: string;
    value?: string | null;
    onApply: (value: string) => void;
}) => import("react/jsx-runtime").JSX.Element;
