export declare const MONTHS: string[];
export declare const QUARTERS: string[];
export declare const FIXED_DATES: string[];
