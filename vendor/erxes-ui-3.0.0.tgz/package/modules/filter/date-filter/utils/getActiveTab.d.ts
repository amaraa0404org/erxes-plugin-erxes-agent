export declare const getActiveTab: (date: string) => "month" | "day" | "halfYear" | "quarter" | "year";
