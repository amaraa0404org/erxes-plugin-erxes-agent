export declare const getDisplayValue: (value: string) => string;
