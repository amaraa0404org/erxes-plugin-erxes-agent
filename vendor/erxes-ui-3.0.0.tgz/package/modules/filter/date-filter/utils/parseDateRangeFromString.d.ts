export declare const parseDateRangeFromString: (date?: string | null) => {
    from: Date;
    to: Date;
} | undefined;
