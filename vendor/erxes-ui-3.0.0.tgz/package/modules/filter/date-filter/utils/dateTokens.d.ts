export declare const parseQuarterToken: (value: string) => {
    year: number;
    quarter: number;
} | null;
export declare const parseHalfToken: (value: string) => {
    year: number;
    half: number;
} | null;
