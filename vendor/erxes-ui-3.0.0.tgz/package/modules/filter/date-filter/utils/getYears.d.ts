export declare const getYearsArray: (startYearOffset: number, endYearOffset: number) => number[];
