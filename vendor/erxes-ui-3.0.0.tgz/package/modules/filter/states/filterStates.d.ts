export declare const EditModePositionComponentState: import("jotai/vanilla/utils/atomFamily").AtomFamily<string, import("jotai").PrimitiveAtom<boolean> & {
    init: boolean;
}>;
export declare const openPopoverState: import("jotai/vanilla/utils/atomFamily").AtomFamily<string, import("jotai").PrimitiveAtom<boolean> & {
    init: boolean;
}>;
export declare const filterPopoverViewState: import("jotai/vanilla/utils/atomFamily").AtomFamily<string, import("jotai").PrimitiveAtom<string> & {
    init: string;
}>;
export declare const openDialogState: import("jotai/vanilla/utils/atomFamily").AtomFamily<string, import("jotai").PrimitiveAtom<boolean> & {
    init: boolean;
}>;
export declare const filterDialogViewState: import("jotai/vanilla/utils/atomFamily").AtomFamily<string, import("jotai").PrimitiveAtom<string> & {
    init: string;
}>;
