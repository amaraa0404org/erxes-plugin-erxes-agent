export declare const useFilterContext: () => import("..").IFilterContext;
