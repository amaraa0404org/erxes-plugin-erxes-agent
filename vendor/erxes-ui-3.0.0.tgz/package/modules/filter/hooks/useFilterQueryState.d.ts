import { QueryState } from 'erxes-ui/hooks/use-query-state';
export declare function useFilterQueryState<T>(queryKey: string, cursorKey?: string, options?: {
    defaultValue?: T;
}): QueryState<T>;
