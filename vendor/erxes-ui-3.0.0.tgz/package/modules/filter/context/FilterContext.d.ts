import { IFilterContext } from '../types/filter';
export declare const FilterContext: import("react").Context<IFilterContext>;
