export type IAttachment = {
    url: string;
    name: string;
    size: number;
    type: string;
    duration?: number;
};
export type AttachmentContextType = {
    attachments: IAttachment[];
    addAttachment: (attachment: IAttachment) => void;
    handleRemoveAttachment: (e: React.MouseEvent, attachment: IAttachment) => void;
    resetAttachments: () => void;
    removingUrl: string | null;
    isLoading: boolean;
};
export type AttachmentSavePayload = {
    attachments: IAttachment[];
};
export declare const parseFilesAsAttachments: (value: unknown) => IAttachment[];
