import React from 'react';
import type { AttachmentContextType, IAttachment } from './types';
export declare const useAttachmentContext: () => AttachmentContextType;
export type AttachmentRootProps = {
    children: React.ReactNode;
    initialAttachments?: IAttachment[];
    onSave?: (attachments: IAttachment[]) => Promise<void> | void;
    onRemove?: (attachment: IAttachment, remaining: IAttachment[]) => Promise<boolean | void> | boolean | void;
    confirmRemove?: (attachment: IAttachment) => Promise<boolean> | boolean;
    isLoading?: boolean;
};
export declare const AttachmentRoot: ({ children, initialAttachments, onSave, onRemove, confirmRemove, isLoading: externalLoading, }: AttachmentRootProps) => import("react/jsx-runtime").JSX.Element;
