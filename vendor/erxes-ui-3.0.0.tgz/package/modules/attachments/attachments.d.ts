import { type AttachmentRootProps } from './context';
import type { IAttachment } from './types';
export type AttachmentFilesProps = {
    /** Override the accepted MIME type set. */
    fileTypes?: Set<string>;
    heading?: string;
};
export type AttachmentPreviewProps = {
    heading?: string;
    className?: string;
    renderThumbnails?: (openPreview: (index: number) => void) => React.ReactNode;
};
export type AttachmentVideoProps = {
    heading?: string;
};
export type AttachmentAudioProps = {
    heading?: string;
};
export type AttachmentUploaderProps = {
    onSave?: (attachments: IAttachment[]) => Promise<void> | void;
    id?: string;
    label?: string;
};
export type AttachmentsInlineProps = {
    attachments: IAttachment[];
    /** Override the file MIME type set used to identify non-image files. */
    fileTypes?: Set<string>;
};
export declare const Attachments: {
    readonly Root: ({ children, initialAttachments, onSave, onRemove, confirmRemove, isLoading: externalLoading, }: AttachmentRootProps) => import("react/jsx-runtime").JSX.Element;
    readonly Files: ({ fileTypes, heading, }: AttachmentFilesProps) => import("react/jsx-runtime").JSX.Element | null;
    readonly Preview: ({ heading, className, renderThumbnails, }: AttachmentPreviewProps) => import("react/jsx-runtime").JSX.Element | null;
    readonly Video: ({ heading, }: AttachmentVideoProps) => import("react/jsx-runtime").JSX.Element | null;
    readonly Audio: ({ heading, }: AttachmentAudioProps) => import("react/jsx-runtime").JSX.Element | null;
    readonly Uploader: ({ onSave, id, label, }: AttachmentUploaderProps) => import("react/jsx-runtime").JSX.Element;
    readonly Inline: ({ attachments, fileTypes, }: AttachmentsInlineProps) => import("react/jsx-runtime").JSX.Element;
};
export type { AttachmentRootProps };
