import type { ChartVizPayload } from '../types/chatVizTypes';
/**
 * Validate and sanitize an untrusted chat message payload before rendering.
 * Returns null if the payload is not a valid chart-viz message.
 *
 * XSS: all user-visible string fields are length-capped; CSS color and key
 * values are regex-validated before being used in CSS custom properties.
 *
 * IDOR: no data source IDs are present — only inlined data. Authorization
 * must be enforced server-side before this payload is stored or delivered.
 */
export declare function sanitizeChartVizPayload(raw: unknown): ChartVizPayload | null;
/**
 * Sanitize then serialize a chart payload for embedding in a chat message.
 * Returns null if the payload fails validation.
 *
 * Always go through this function when sending — never serialize raw
 * user-supplied objects directly.
 */
export declare function serializeChartVizPayload(input: Omit<ChartVizPayload, 'type' | 'sentAt'>): string | null;
/**
 * Parse and sanitize a raw JSON string received from a chat message.
 * Returns null on invalid JSON or invalid payload shape.
 */
export declare function parseChartVizMessage(raw: string): ChartVizPayload | null;
