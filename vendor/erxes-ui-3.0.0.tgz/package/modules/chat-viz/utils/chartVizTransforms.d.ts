import type { ChartVizPayload } from '../types/chatVizTypes';
export type ChartVizControlValues = Record<string, number>;
/** Returns the persisted baseline values for every declarative control. */
export declare function getDefaultChartVizControlValues(payload: ChartVizPayload): ChartVizControlValues;
/**
 * Applies the small allow-listed transform language to an already sanitized
 * payload. This is deliberately an interpreter over data: it never evaluates
 * model-authored JavaScript, expressions, HTML, or property paths.
 */
export declare function applyChartVizTransforms(payload: ChartVizPayload, values: ChartVizControlValues): ChartVizPayload;
/**
 * Calculates one axis domain across every meaningful control extreme. Keeping
 * this domain stable while sliders move makes the geometry visibly move;
 * auto-scaling each new data set would leave the same-looking curve in place
 * and change only its tick labels.
 */
export declare function getChartVizInteractiveDomain(payload: ChartVizPayload, { includeZero }?: {
    includeZero?: boolean;
}): [number, number] | undefined;
