/** Core theme chart values are complete CSS colors (currently oklch). */
export declare const getDefaultChartVizColor: (index: number) => string;
/** Formats numeric axis ticks compactly without changing chart values. */
export declare const formatChartVizAxisValue: (value: number) => string;
/**
 * Adds breathing room around line/area data, especially a constant series.
 * Recharts' default zero-based domain pins a flat, large-value line against
 * the top edge and makes it look missing.
 */
export declare const getChartVizTrendDomain: ([dataMin, dataMax]: [number, number]) => [number, number];
