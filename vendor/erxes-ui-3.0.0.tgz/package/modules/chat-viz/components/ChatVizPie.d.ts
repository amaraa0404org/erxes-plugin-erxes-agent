import type { ChartVizPayload } from '../types/chatVizTypes';
interface Props {
    payload: ChartVizPayload;
    className?: string;
}
/**
 * Pie chart variant.
 *
 * For pie charts, each data row is a slice. The first series key is used as the
 * value field; `label` is used as the slice name. Additional series are ignored.
 */
export declare function ChatVizPie({ payload, className }: Readonly<Props>): import("react/jsx-runtime").JSX.Element;
export {};
