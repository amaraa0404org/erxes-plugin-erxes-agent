interface Props {
    /**
     * Raw parsed value from a chat message (e.g. JSON.parse of message.content).
     * Will be fully sanitized before any rendering occurs.
     *
     * XSS: all fields are validated/escaped inside sanitizeChartVizPayload.
     * SSR: chart components are client-only — a skeleton is shown until mount.
     * IDOR: this component renders only data embedded in the payload; it never
     *   fetches data by ID. Server-side authorization must gate what data may
     *   be embedded when the message is created.
     */
    rawPayload: unknown;
    className?: string;
}
export declare function ChatVizMessage({ rawPayload, className }: Readonly<Props>): import("react/jsx-runtime").JSX.Element | null;
export {};
