import type { ChartVizPayload } from '../types/chatVizTypes';
interface Props {
    payload: ChartVizPayload;
    className?: string;
    /** Frozen axis domain for interactive charts; falls back to a padded fit. */
    domain?: [number, number];
}
export declare function ChatVizLine({ payload, className, domain }: Readonly<Props>): import("react/jsx-runtime").JSX.Element;
export {};
