import { type YAxisProps } from 'recharts';
interface Props {
    domain?: YAxisProps['domain'];
}
/** Shared axes, grid, tooltip, and legend for cartesian chat charts. */
export declare function ChatVizCartesianDecorations({ domain }: Readonly<Props>): import("react/jsx-runtime").JSX.Element;
export {};
