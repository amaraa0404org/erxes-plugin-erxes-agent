import type { ChartVizPayload } from '../types/chatVizTypes';
interface Props {
    /**
     * The chart data to send. `type` and `sentAt` are set automatically.
     *
     * Security: the payload is run through serializeChartVizPayload (sanitize
     * then JSON.stringify) before being handed to onSend. Never bypass this by
     * passing a pre-serialized string directly to onSend.
     */
    payload: Omit<ChartVizPayload, 'type' | 'sentAt'>;
    /** Receives the sanitized JSON string to embed in a chat message */
    onSend: (serialized: string) => void;
    disabled?: boolean;
    label?: string;
}
export declare function ChatVizSendButton({ payload, onSend, disabled, label, }: Props): import("react/jsx-runtime").JSX.Element;
export {};
