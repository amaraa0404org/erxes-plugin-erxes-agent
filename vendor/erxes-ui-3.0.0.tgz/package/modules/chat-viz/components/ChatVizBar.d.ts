import type { ChartVizPayload } from '../types/chatVizTypes';
interface Props {
    payload: ChartVizPayload;
    className?: string;
    /** Frozen zero-based axis domain for interactive charts. */
    domain?: [number, number];
}
export declare function ChatVizBar({ payload, className, domain }: Readonly<Props>): import("react/jsx-runtime").JSX.Element;
export {};
