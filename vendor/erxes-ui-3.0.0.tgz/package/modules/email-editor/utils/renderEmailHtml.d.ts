import type { JSONContent } from '@tiptap/core';
/** The email as html, with every field left as a placeholder for the server. */
export declare const renderEmailHtml: (contentJson?: JSONContent, { previewText }?: {
    previewText?: string;
}) => Promise<string>;
