import type { JSONContent } from '@tiptap/core';
export declare const expandCustomNodes: (node: JSONContent) => JSONContent;
