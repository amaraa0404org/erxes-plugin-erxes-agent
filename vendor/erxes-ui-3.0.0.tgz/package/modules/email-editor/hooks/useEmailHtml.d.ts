import type { JSONContent } from '@tiptap/core';
/** The email as html, following the content while it is being written. */
export declare const useEmailHtml: (contentJson?: JSONContent, previewText?: string) => {
    html: string;
    error: Error | undefined;
};
