import { EmailEditorProps } from '../types';
export declare const uploadEmailEditorImage: (file: File) => Promise<string>;
export declare const EmailEditor: ({ contentJson, onChange, onCreate, variables, onImageUpload, blocks, extensions: additionalExtensions, placeholder, className, editable, }: EmailEditorProps) => import("react/jsx-runtime").JSX.Element;
