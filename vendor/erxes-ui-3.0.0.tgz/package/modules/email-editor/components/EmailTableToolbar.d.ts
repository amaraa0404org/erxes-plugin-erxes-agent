import type { Editor } from '@tiptap/core';
/**
 * Shown only while the caret is inside a table: the editor has no chrome of
 * its own for one, and a table you cannot add a row to is not a table.
 */
export declare const EmailTableToolbar: ({ editor }: {
    editor: Editor | null;
}) => import("react/jsx-runtime").JSX.Element | null;
