import { EmailPreviewDevice } from '../types';
export interface EmailPreviewFrameProps {
    html: string;
    className?: string;
    /** The width the email is read at. Mobile is where most of it is read. */
    device?: EmailPreviewDevice;
}
export declare const EmailPreviewFrame: ({ html, className, device, }: EmailPreviewFrameProps) => import("react/jsx-runtime").JSX.Element;
