import type { Editor } from '@tiptap/core';
export declare const EmailTableBackground: ({ editor }: {
    editor: Editor;
}) => import("react/jsx-runtime").JSX.Element;
