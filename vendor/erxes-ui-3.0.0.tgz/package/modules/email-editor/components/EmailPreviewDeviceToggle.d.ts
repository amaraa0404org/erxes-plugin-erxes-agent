import { EmailPreviewDevice } from '../types';
/** Which width the rendered email is being read at. */
export declare const EmailPreviewDeviceToggle: ({ value, onChange, className, }: {
    value: EmailPreviewDevice;
    onChange: (device: EmailPreviewDevice) => void;
    className?: string;
}) => import("react/jsx-runtime").JSX.Element;
