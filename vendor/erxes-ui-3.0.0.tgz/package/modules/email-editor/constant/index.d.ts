import type { EditorProps as MailyEditorProps } from '@maily-to/core';
type BlockGroups = NonNullable<MailyEditorProps['blocks']>;
export declare const DEFAULT_EMAIL_BLOCKS: BlockGroups;
export {};
