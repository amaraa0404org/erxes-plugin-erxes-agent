import { Node } from '@tiptap/core';
declare module '@tiptap/core' {
    interface Commands<ReturnType> {
        emailTable: {
            insertTable: (options?: {
                rows?: number;
                cols?: number;
            }) => ReturnType;
            addRowBefore: () => ReturnType;
            addRowAfter: () => ReturnType;
            deleteRow: () => ReturnType;
            addColumnBefore: () => ReturnType;
            addColumnAfter: () => ReturnType;
            deleteColumn: () => ReturnType;
            toggleHeaderRow: () => ReturnType;
            mergeCells: () => ReturnType;
            splitCell: () => ReturnType;
            deleteTable: () => ReturnType;
            setTableBackground: (options: {
                color: string | null;
                scope: TEmailTableBackgroundScope;
            }) => ReturnType;
        };
    }
}
/** How far a background colour reaches from the cell the caret is in. */
export type TEmailTableBackgroundScope = 'cell' | 'row' | 'column' | 'table';
/**
 * Email tables, kept deliberately plain: no column resizing, because what is
 * sent has to survive mail clients that ignore half of it anyway.
 */
export declare const EmailTable: Node<any, any>;
/** What a header cell starts out as, until someone picks something else. */
export declare const HEADER_BACKGROUND = "#f9fafb";
export declare const EmailTableRow: Node<any, any>;
export declare const EmailTableCell: Node<any, any>;
export declare const EmailTableHeader: Node<any, any>;
export declare const EMAIL_TABLE_EXTENSIONS: Node<any, any>[];
