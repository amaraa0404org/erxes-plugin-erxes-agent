import type { Editor, Range } from '@tiptap/core';
import type { EditorProps as MailyEditorProps } from '@maily-to/core';
type BlockGroups = NonNullable<MailyEditorProps['blocks']>;
/**
 * Which document to embed is answered outside the editor, so the entry hands
 * the editor back to whoever opens the picker and inserts nothing itself.
 */
export declare const createDocumentPlaceholderBlock: (onOpen: (editor: Editor) => void) => {
    title: string;
    description: string;
    searchTerms: string[];
    icon: import("react/jsx-runtime").JSX.Element;
    command: ({ editor, range }: {
        editor: Editor;
        range: Range;
    }) => void;
};
export declare const withEmailDocumentBlock: (onOpen: (editor: Editor) => void, blocks?: BlockGroups) => BlockGroups;
export {};
