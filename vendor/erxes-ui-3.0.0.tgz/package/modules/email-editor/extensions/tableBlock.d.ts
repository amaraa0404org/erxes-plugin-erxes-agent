import type { Editor, Range } from '@tiptap/core';
/** The slash-command entry that drops a table into the email. */
export declare const tableBlock: {
    title: string;
    description: string;
    searchTerms: string[];
    icon: import("react/jsx-runtime").JSX.Element;
    command: ({ editor, range }: {
        editor: Editor;
        range: Range;
    }) => void;
};
