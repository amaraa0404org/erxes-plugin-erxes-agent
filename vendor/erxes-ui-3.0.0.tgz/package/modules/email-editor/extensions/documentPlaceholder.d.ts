import { Node } from '@tiptap/core';
export interface EmailDocumentPlaceholderAttrs {
    documentId: string;
    documentName?: string;
    documentCode?: string;
    documentPreview?: string;
}
declare module '@tiptap/core' {
    interface Commands<ReturnType> {
        emailDocumentPlaceholder: {
            insertDocumentPlaceholder: (attrs: EmailDocumentPlaceholderAttrs) => ReturnType;
        };
    }
}
/**
 * A document rendered into the email at send time. The node holds only which
 * document it is: the body is produced per recipient, so the editor shows the
 * document's name and a teaser of it rather than its content.
 */
export declare const EmailDocumentPlaceholder: Node<any, any>;
