export declare const usePhoneFields: () => {
    recordId: string;
    onValueChange?: (phones: import("..").TPhones) => void;
    onValidationStatusChange?: (status: IPhoneStatus) => void;
};
