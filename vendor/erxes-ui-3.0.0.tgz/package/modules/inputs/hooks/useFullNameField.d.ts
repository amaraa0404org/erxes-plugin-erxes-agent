export declare const useFullNameField: () => {
    fullName: string;
    firstName: string;
    lastName: string;
    setFirstName: (firstName: string) => void;
    setLastName: (lastName: string) => void;
};
