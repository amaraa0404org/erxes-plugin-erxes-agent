export declare const useEmailFields: () => {
    recordId: string;
    onValueChange?: (emails: import("..").TEmails) => void;
    noValidation?: boolean;
    onValidationStatusChange?: (status: import("../../..").ValidationStatus) => void;
};
