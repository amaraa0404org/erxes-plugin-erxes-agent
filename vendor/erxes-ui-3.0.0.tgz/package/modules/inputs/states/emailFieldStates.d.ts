import { TEmails } from '../components/EmailField';
export declare const showEmailInputFamilyState: import("jotai/vanilla/utils/atomFamily").AtomFamily<string, import("jotai").PrimitiveAtom<boolean> & {
    init: boolean;
}>;
export declare const emailsFamilyState: import("jotai/vanilla/utils/atomFamily").AtomFamily<string, import("jotai").PrimitiveAtom<TEmails> & {
    init: TEmails;
}>;
export declare const editingEmailFamilyState: import("jotai/vanilla/utils/atomFamily").AtomFamily<string, import("jotai").PrimitiveAtom<string | null> & {
    init: string | null;
}>;
