import { TPhones } from '../components/PhoneField';
export declare const showPhoneInputFamilyState: import("jotai/vanilla/utils/atomFamily").AtomFamily<string, import("jotai").PrimitiveAtom<boolean> & {
    init: boolean;
}>;
export declare const phonesFamilyState: import("jotai/vanilla/utils/atomFamily").AtomFamily<string, import("jotai").PrimitiveAtom<TPhones> & {
    init: TPhones;
}>;
export declare const editingPhoneFamilyState: import("jotai/vanilla/utils/atomFamily").AtomFamily<string, import("jotai").PrimitiveAtom<string | null> & {
    init: string | null;
}>;
