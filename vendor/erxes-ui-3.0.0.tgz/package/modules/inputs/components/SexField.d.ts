import { SexCode } from 'erxes-ui/types';
export declare const SexField: ({ value, onValueChange, }: {
    value: SexCode;
    onValueChange: (value: SexCode) => void;
}) => import("react/jsx-runtime").JSX.Element;
