import React from 'react';
export declare const FullNameValue: () => string | import("react/jsx-runtime").JSX.Element;
export declare const FullNameField: ({ children, firstName, lastName, onValueChange, scope, }: {
    children: React.ReactNode;
    scope: string;
    firstName?: string;
    lastName?: string;
    onValueChange: (firstName: string, lastName: string) => void;
}) => import("react/jsx-runtime").JSX.Element;
