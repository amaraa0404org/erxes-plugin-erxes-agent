import { Currency, CurrencyCode } from 'erxes-ui/types';
import React from 'react';
import { Except } from 'type-fest';
export declare const CurrencyField: React.ForwardRefExoticComponent<React.HTMLAttributes<HTMLDivElement> & React.RefAttributes<HTMLDivElement>> & {
    ValueInput: React.ForwardRefExoticComponent<(Except<Omit<Omit<import("react-imask").ReactElementProps<HTMLInputElement> & Omit<import("react-imask").ReactMaskProps<HTMLInputElement, {
        [x: string]: unknown;
    }>, "ref"> & Omit<import("imask/esm/index").MaskedDateOptions, "mask"> & {
        mask: DateConstructor;
    } & {
        ref?: React.Ref<React.ComponentType<import("react-imask").IMaskInputProps<HTMLInputElement>>> | undefined;
    }, "ref"> & React.RefAttributes<unknown>, "ref"> | Omit<Omit<import("react-imask").ReactElementProps<HTMLInputElement> & Omit<import("react-imask").ReactMaskProps<HTMLInputElement, {
        [x: string]: unknown;
    }>, "ref"> & {
        mask: typeof import("imask/esm/index").MaskedDate;
    } & Omit<Omit<import("imask/esm/index").MaskedDateOptions, "mask"> & {
        mask: DateConstructor;
    }, "mask"> & {
        ref?: React.Ref<React.ComponentType<import("react-imask").IMaskInputProps<HTMLInputElement>>> | undefined;
    }, "ref"> & React.RefAttributes<unknown>, "ref"> | Omit<Omit<import("react-imask").ReactElementProps<HTMLInputElement> & Omit<import("react-imask").ReactMaskProps<HTMLInputElement, {
        [x: string]: unknown;
    }>, "ref"> & Partial<Pick<import("imask/esm/index").MaskedNumber, "mask" | "max" | "min" | "format" | "scale" | "eager" | "validate" | "parent" | "prepare" | "prepareChar" | "commit" | "parse" | "overwrite" | "skipInvalid" | "autofix" | "radix" | "thousandsSeparator" | "mapToRadix" | "normalizeZeros" | "padFractionalZeros">> & {
        ref?: React.Ref<React.ComponentType<import("react-imask").IMaskInputProps<HTMLInputElement>>> | undefined;
    }, "ref"> & React.RefAttributes<unknown>, "ref"> | Omit<Omit<import("react-imask").ReactElementProps<HTMLInputElement> & Omit<import("react-imask").ReactMaskProps<HTMLInputElement, {
        [x: string]: unknown;
    }>, "ref"> & {
        mask: typeof import("imask/esm/index").MaskedNumber;
    } & Omit<Partial<Pick<import("imask/esm/index").MaskedNumber, "mask" | "max" | "min" | "format" | "scale" | "eager" | "validate" | "parent" | "prepare" | "prepareChar" | "commit" | "parse" | "overwrite" | "skipInvalid" | "autofix" | "radix" | "thousandsSeparator" | "mapToRadix" | "normalizeZeros" | "padFractionalZeros">>, "mask"> & {
        ref?: React.Ref<React.ComponentType<import("react-imask").IMaskInputProps<HTMLInputElement>>> | undefined;
    }, "ref"> & React.RefAttributes<unknown>, "ref"> | Omit<Omit<import("react-imask").ReactElementProps<HTMLInputElement> & Omit<import("react-imask").ReactMaskProps<HTMLInputElement, {
        [x: string]: unknown;
    }>, "ref"> & Partial<Pick<import("imask/esm/index").MaskedPattern<string>, "mask" | "format" | "eager" | "lazy" | "validate" | "parent" | "prepare" | "prepareChar" | "commit" | "parse" | "overwrite" | "skipInvalid" | "autofix" | "definitions" | "blocks" | "placeholderChar" | "displayChar">> & {
        ref?: React.Ref<React.ComponentType<import("react-imask").IMaskInputProps<HTMLInputElement>>> | undefined;
    }, "ref"> & React.RefAttributes<unknown>, "ref"> | Omit<Omit<import("react-imask").ReactElementProps<HTMLInputElement> & Omit<import("react-imask").ReactMaskProps<HTMLInputElement, {
        [x: string]: unknown;
    }>, "ref"> & {
        mask: typeof import("imask/esm/index").MaskedEnum;
    } & Omit<import("imask/esm/index").MaskedEnumOptions, "mask"> & {
        ref?: React.Ref<React.ComponentType<import("react-imask").IMaskInputProps<HTMLInputElement>>> | undefined;
    }, "ref"> & React.RefAttributes<unknown>, "ref"> | Omit<Omit<import("react-imask").ReactElementProps<HTMLInputElement> & Omit<import("react-imask").ReactMaskProps<HTMLInputElement, {
        [x: string]: unknown;
    }>, "ref"> & {
        mask: typeof import("imask/esm/index").MaskedRange;
    } & Omit<import("imask/esm/index").MaskedRangeOptions, "mask"> & {
        ref?: React.Ref<React.ComponentType<import("react-imask").IMaskInputProps<HTMLInputElement>>> | undefined;
    }, "ref"> & React.RefAttributes<unknown>, "ref"> | Omit<Omit<import("react-imask").ReactElementProps<HTMLInputElement> & Omit<import("react-imask").ReactMaskProps<HTMLInputElement, {
        [x: string]: unknown;
    }>, "ref"> & Partial<Pick<import("imask/esm/index").MaskedRegExp, "mask" | "format" | "eager" | "validate" | "parent" | "prepare" | "prepareChar" | "commit" | "parse" | "overwrite" | "skipInvalid" | "autofix">> & {
        ref?: React.Ref<React.ComponentType<import("react-imask").IMaskInputProps<HTMLInputElement>>> | undefined;
    }, "ref"> & React.RefAttributes<unknown>, "ref"> | Omit<Omit<import("react-imask").ReactElementProps<HTMLInputElement> & Omit<import("react-imask").ReactMaskProps<HTMLInputElement, {
        [x: string]: unknown;
    }>, "ref"> & {
        mask: typeof import("imask/esm/index").MaskedRegExp;
    } & Omit<Partial<Pick<import("imask/esm/index").MaskedRegExp, "mask" | "format" | "eager" | "validate" | "parent" | "prepare" | "prepareChar" | "commit" | "parse" | "overwrite" | "skipInvalid" | "autofix">>, "mask"> & {
        ref?: React.Ref<React.ComponentType<import("react-imask").IMaskInputProps<HTMLInputElement>>> | undefined;
    }, "ref"> & React.RefAttributes<unknown>, "ref"> | Omit<Omit<import("react-imask").ReactElementProps<HTMLInputElement> & Omit<import("react-imask").ReactMaskProps<HTMLInputElement, {
        [x: string]: unknown;
    }>, "ref"> & Partial<Pick<import("imask/esm/index").MaskedFunction<any>, "mask" | "format" | "eager" | "validate" | "parent" | "prepare" | "prepareChar" | "commit" | "parse" | "overwrite" | "skipInvalid" | "autofix">> & {
        ref?: React.Ref<React.ComponentType<import("react-imask").IMaskInputProps<HTMLInputElement>>> | undefined;
    }, "ref"> & React.RefAttributes<unknown>, "ref"> | Omit<Omit<import("react-imask").ReactElementProps<HTMLInputElement> & Omit<import("react-imask").ReactMaskProps<HTMLInputElement, {
        [x: string]: unknown;
    }>, "ref"> & {
        mask: typeof import("imask/esm/index").MaskedFunction;
    } & Omit<Partial<Pick<import("imask/esm/index").MaskedFunction<any>, "mask" | "format" | "eager" | "validate" | "parent" | "prepare" | "prepareChar" | "commit" | "parse" | "overwrite" | "skipInvalid" | "autofix">>, "mask"> & {
        ref?: React.Ref<React.ComponentType<import("react-imask").IMaskInputProps<HTMLInputElement>>> | undefined;
    }, "ref"> & React.RefAttributes<unknown>, "ref"> | Omit<Omit<import("react-imask").ReactElementProps<HTMLInputElement> & Omit<import("react-imask").ReactMaskProps<HTMLInputElement, {
        [x: string]: unknown;
    }>, "ref"> & {
        mask: typeof import("imask/esm/index").MaskedPattern;
    } & Omit<Partial<Pick<import("imask/esm/index").MaskedPattern<string>, "mask" | "format" | "eager" | "lazy" | "validate" | "parent" | "prepare" | "prepareChar" | "commit" | "parse" | "overwrite" | "skipInvalid" | "autofix" | "definitions" | "blocks" | "placeholderChar" | "displayChar">>, "mask"> & {
        ref?: React.Ref<React.ComponentType<import("react-imask").IMaskInputProps<HTMLInputElement>>> | undefined;
    }, "ref"> & React.RefAttributes<unknown>, "ref"> | Omit<Omit<import("react-imask").ReactElementProps<HTMLInputElement> & Omit<import("react-imask").ReactMaskProps<HTMLInputElement, {
        [x: string]: unknown;
    }>, "ref"> & Partial<Pick<import("imask/esm/index").MaskedDynamic<any>, "mask" | "format" | "eager" | "validate" | "parent" | "prepare" | "prepareChar" | "commit" | "parse" | "overwrite" | "skipInvalid" | "autofix" | "dispatch">> & {
        ref?: React.Ref<React.ComponentType<import("react-imask").IMaskInputProps<HTMLInputElement>>> | undefined;
    }, "ref"> & React.RefAttributes<unknown>, "ref"> | Omit<Omit<import("react-imask").ReactElementProps<HTMLInputElement> & Omit<import("react-imask").ReactMaskProps<HTMLInputElement, {
        [x: string]: unknown;
    }>, "ref"> & {
        mask: typeof import("imask/esm/index").MaskedDynamic;
    } & Omit<Partial<Pick<import("imask/esm/index").MaskedDynamic<any>, "mask" | "format" | "eager" | "validate" | "parent" | "prepare" | "prepareChar" | "commit" | "parse" | "overwrite" | "skipInvalid" | "autofix" | "dispatch">>, "mask"> & {
        ref?: React.Ref<React.ComponentType<import("react-imask").IMaskInputProps<HTMLInputElement>>> | undefined;
    }, "ref"> & React.RefAttributes<unknown>, "ref"> | Omit<Omit<import("react-imask").ReactElementProps<HTMLInputElement> & Omit<import("react-imask").ReactMaskProps<HTMLInputElement, {
        [x: string]: unknown;
    }>, "ref"> & {
        mask: typeof import("imask/esm/index").Masked;
    } & Omit<Partial<Pick<import("imask/esm/index").Masked<any>, "mask" | "format" | "eager" | "validate" | "parent" | "prepare" | "prepareChar" | "commit" | "parse" | "overwrite" | "skipInvalid" | "autofix">>, "mask"> & {
        ref?: React.Ref<React.ComponentType<import("react-imask").IMaskInputProps<HTMLInputElement>>> | undefined;
    }, "ref"> & React.RefAttributes<unknown>, "ref"> | Omit<Omit<import("react-imask").ReactElementProps<HTMLInputElement> & Omit<import("react-imask").ReactMaskProps<HTMLInputElement, {
        [x: string]: unknown;
    }>, "ref"> & {
        mask: import("imask/esm/index").MaskedDate;
    } & Omit<Omit<import("imask/esm/index").MaskedDateOptions, "mask"> & {
        mask: DateConstructor;
    }, "mask"> & {
        ref?: React.Ref<React.ComponentType<import("react-imask").IMaskInputProps<HTMLInputElement>>> | undefined;
    }, "ref"> & React.RefAttributes<unknown>, "ref"> | Omit<Omit<import("react-imask").ReactElementProps<HTMLInputElement> & Omit<import("react-imask").ReactMaskProps<HTMLInputElement, {
        [x: string]: unknown;
    }>, "ref"> & {
        mask: import("imask/esm/index").MaskedNumber;
    } & Omit<Partial<Pick<import("imask/esm/index").MaskedNumber, "mask" | "max" | "min" | "format" | "scale" | "eager" | "validate" | "parent" | "prepare" | "prepareChar" | "commit" | "parse" | "overwrite" | "skipInvalid" | "autofix" | "radix" | "thousandsSeparator" | "mapToRadix" | "normalizeZeros" | "padFractionalZeros">>, "mask"> & {
        ref?: React.Ref<React.ComponentType<import("react-imask").IMaskInputProps<HTMLInputElement>>> | undefined;
    }, "ref"> & React.RefAttributes<unknown>, "ref"> | Omit<Omit<import("react-imask").ReactElementProps<HTMLInputElement> & Omit<import("react-imask").ReactMaskProps<HTMLInputElement, {
        [x: string]: unknown;
    }>, "ref"> & {
        mask: import("imask/esm/index").MaskedEnum;
    } & Omit<import("imask/esm/index").MaskedEnumOptions, "mask"> & {
        ref?: React.Ref<React.ComponentType<import("react-imask").IMaskInputProps<HTMLInputElement>>> | undefined;
    }, "ref"> & React.RefAttributes<unknown>, "ref"> | Omit<Omit<import("react-imask").ReactElementProps<HTMLInputElement> & Omit<import("react-imask").ReactMaskProps<HTMLInputElement, {
        [x: string]: unknown;
    }>, "ref"> & {
        mask: import("imask/esm/index").MaskedRange;
    } & Omit<import("imask/esm/index").MaskedRangeOptions, "mask"> & {
        ref?: React.Ref<React.ComponentType<import("react-imask").IMaskInputProps<HTMLInputElement>>> | undefined;
    }, "ref"> & React.RefAttributes<unknown>, "ref"> | Omit<Omit<import("react-imask").ReactElementProps<HTMLInputElement> & Omit<import("react-imask").ReactMaskProps<HTMLInputElement, {
        [x: string]: unknown;
    }>, "ref"> & {
        mask: import("imask/esm/index").MaskedRegExp;
    } & Omit<Partial<Pick<import("imask/esm/index").MaskedRegExp, "mask" | "format" | "eager" | "validate" | "parent" | "prepare" | "prepareChar" | "commit" | "parse" | "overwrite" | "skipInvalid" | "autofix">>, "mask"> & {
        ref?: React.Ref<React.ComponentType<import("react-imask").IMaskInputProps<HTMLInputElement>>> | undefined;
    }, "ref"> & React.RefAttributes<unknown>, "ref"> | Omit<Omit<import("react-imask").ReactElementProps<HTMLInputElement> & Omit<import("react-imask").ReactMaskProps<HTMLInputElement, {
        [x: string]: unknown;
    }>, "ref"> & {
        mask: import("imask/esm/index").MaskedFunction<any>;
    } & Omit<Partial<Pick<import("imask/esm/index").MaskedFunction<any>, "mask" | "format" | "eager" | "validate" | "parent" | "prepare" | "prepareChar" | "commit" | "parse" | "overwrite" | "skipInvalid" | "autofix">>, "mask"> & {
        ref?: React.Ref<React.ComponentType<import("react-imask").IMaskInputProps<HTMLInputElement>>> | undefined;
    }, "ref"> & React.RefAttributes<unknown>, "ref"> | Omit<Omit<import("react-imask").ReactElementProps<HTMLInputElement> & Omit<import("react-imask").ReactMaskProps<HTMLInputElement, {
        [x: string]: unknown;
    }>, "ref"> & {
        mask: import("imask/esm/index").MaskedPattern<string>;
    } & Omit<Partial<Pick<import("imask/esm/index").MaskedPattern<string>, "mask" | "format" | "eager" | "lazy" | "validate" | "parent" | "prepare" | "prepareChar" | "commit" | "parse" | "overwrite" | "skipInvalid" | "autofix" | "definitions" | "blocks" | "placeholderChar" | "displayChar">>, "mask"> & {
        ref?: React.Ref<React.ComponentType<import("react-imask").IMaskInputProps<HTMLInputElement>>> | undefined;
    }, "ref"> & React.RefAttributes<unknown>, "ref"> | Omit<Omit<import("react-imask").ReactElementProps<HTMLInputElement> & Omit<import("react-imask").ReactMaskProps<HTMLInputElement, {
        [x: string]: unknown;
    }>, "ref"> & {
        mask: import("imask/esm/index").MaskedDynamic<any>;
    } & Omit<Partial<Pick<import("imask/esm/index").MaskedDynamic<any>, "mask" | "format" | "eager" | "validate" | "parent" | "prepare" | "prepareChar" | "commit" | "parse" | "overwrite" | "skipInvalid" | "autofix" | "dispatch">>, "mask"> & {
        ref?: React.Ref<React.ComponentType<import("react-imask").IMaskInputProps<HTMLInputElement>>> | undefined;
    }, "ref"> & React.RefAttributes<unknown>, "ref"> | Omit<Omit<import("react-imask").ReactElementProps<HTMLInputElement> & Omit<import("react-imask").ReactMaskProps<HTMLInputElement, {
        [x: string]: unknown;
    }>, "ref"> & {
        mask: import("imask/esm/index").Masked<any>;
    } & Omit<Partial<Pick<import("imask/esm/index").Masked<any>, "mask" | "format" | "eager" | "validate" | "parent" | "prepare" | "prepareChar" | "commit" | "parse" | "overwrite" | "skipInvalid" | "autofix">>, "mask"> & {
        ref?: React.Ref<React.ComponentType<import("react-imask").IMaskInputProps<HTMLInputElement>>> | undefined;
    }, "ref"> & React.RefAttributes<unknown>, "ref">, "onChange" | "value"> & {
        displayScale?: number;
        editScale?: number;
        onChange?: (value: number) => void;
        value?: number;
    }) & React.RefAttributes<unknown>>;
    SelectCurrency: React.ForwardRefExoticComponent<{
        dir?: string | undefined | undefined;
        form?: string | undefined | undefined;
        slot?: string | undefined | undefined;
        style?: React.CSSProperties | undefined;
        title?: string | undefined | undefined;
        key?: React.Key | null | undefined;
        defaultChecked?: boolean | undefined | undefined;
        defaultValue?: string | number | readonly string[] | undefined;
        suppressContentEditableWarning?: boolean | undefined | undefined;
        suppressHydrationWarning?: boolean | undefined | undefined;
        accessKey?: string | undefined | undefined;
        autoFocus?: boolean | undefined | undefined;
        className?: string | undefined | undefined;
        contentEditable?: (boolean | "true" | "false") | "inherit" | "plaintext-only" | undefined;
        contextMenu?: string | undefined | undefined;
        draggable?: (boolean | "true" | "false") | undefined;
        hidden?: boolean | undefined | undefined;
        id?: string | undefined | undefined;
        lang?: string | undefined | undefined;
        nonce?: string | undefined | undefined;
        spellCheck?: (boolean | "true" | "false") | undefined;
        tabIndex?: number | undefined | undefined;
        translate?: "yes" | "no" | undefined | undefined;
        radioGroup?: string | undefined | undefined;
        role?: React.AriaRole | undefined;
        about?: string | undefined | undefined;
        content?: string | undefined | undefined;
        datatype?: string | undefined | undefined;
        inlist?: any;
        prefix?: string | undefined | undefined;
        property?: string | undefined | undefined;
        rel?: string | undefined | undefined;
        resource?: string | undefined | undefined;
        rev?: string | undefined | undefined;
        typeof?: string | undefined | undefined;
        vocab?: string | undefined | undefined;
        autoCapitalize?: string | undefined | undefined;
        autoCorrect?: string | undefined | undefined;
        autoSave?: string | undefined | undefined;
        color?: string | undefined | undefined;
        itemProp?: string | undefined | undefined;
        itemScope?: boolean | undefined | undefined;
        itemType?: string | undefined | undefined;
        itemID?: string | undefined | undefined;
        itemRef?: string | undefined | undefined;
        results?: number | undefined | undefined;
        security?: string | undefined | undefined;
        unselectable?: "on" | "off" | undefined | undefined;
        inputMode?: "none" | "text" | "tel" | "url" | "email" | "numeric" | "decimal" | "search" | undefined | undefined;
        is?: string | undefined | undefined;
        children?: React.ReactNode | Iterable<React.ReactNode>;
        "aria-activedescendant"?: string | undefined | undefined;
        "aria-atomic"?: (boolean | "true" | "false") | undefined;
        "aria-autocomplete"?: "none" | "inline" | "list" | "both" | undefined | undefined;
        "aria-braillelabel"?: string | undefined | undefined;
        "aria-brailleroledescription"?: string | undefined | undefined;
        "aria-busy"?: (boolean | "true" | "false") | undefined;
        "aria-checked"?: boolean | "false" | "mixed" | "true" | undefined | undefined;
        "aria-colcount"?: number | undefined | undefined;
        "aria-colindex"?: number | undefined | undefined;
        "aria-colindextext"?: string | undefined | undefined;
        "aria-colspan"?: number | undefined | undefined;
        "aria-controls"?: string | undefined | undefined;
        "aria-current"?: boolean | "false" | "true" | "page" | "step" | "location" | "date" | "time" | undefined | undefined;
        "aria-describedby"?: string | undefined | undefined;
        "aria-description"?: string | undefined | undefined;
        "aria-details"?: string | undefined | undefined;
        "aria-disabled"?: (boolean | "true" | "false") | undefined;
        "aria-dropeffect"?: "none" | "copy" | "execute" | "link" | "move" | "popup" | undefined | undefined;
        "aria-errormessage"?: string | undefined | undefined;
        "aria-expanded"?: (boolean | "true" | "false") | undefined;
        "aria-flowto"?: string | undefined | undefined;
        "aria-grabbed"?: (boolean | "true" | "false") | undefined;
        "aria-haspopup"?: boolean | "false" | "true" | "menu" | "listbox" | "tree" | "grid" | "dialog" | undefined | undefined;
        "aria-hidden"?: (boolean | "true" | "false") | undefined;
        "aria-invalid"?: boolean | "false" | "true" | "grammar" | "spelling" | undefined | undefined;
        "aria-keyshortcuts"?: string | undefined | undefined;
        "aria-label"?: string | undefined | undefined;
        "aria-labelledby"?: string | undefined | undefined;
        "aria-level"?: number | undefined | undefined;
        "aria-live"?: "off" | "assertive" | "polite" | undefined | undefined;
        "aria-modal"?: (boolean | "true" | "false") | undefined;
        "aria-multiline"?: (boolean | "true" | "false") | undefined;
        "aria-multiselectable"?: (boolean | "true" | "false") | undefined;
        "aria-orientation"?: "horizontal" | "vertical" | undefined | undefined;
        "aria-owns"?: string | undefined | undefined;
        "aria-placeholder"?: string | undefined | undefined;
        "aria-posinset"?: number | undefined | undefined;
        "aria-pressed"?: boolean | "false" | "mixed" | "true" | undefined | undefined;
        "aria-readonly"?: (boolean | "true" | "false") | undefined;
        "aria-relevant"?: "additions" | "additions removals" | "additions text" | "all" | "removals" | "removals additions" | "removals text" | "text" | "text additions" | "text removals" | undefined | undefined;
        "aria-required"?: (boolean | "true" | "false") | undefined;
        "aria-roledescription"?: string | undefined | undefined;
        "aria-rowcount"?: number | undefined | undefined;
        "aria-rowindex"?: number | undefined | undefined;
        "aria-rowindextext"?: string | undefined | undefined;
        "aria-rowspan"?: number | undefined | undefined;
        "aria-selected"?: (boolean | "true" | "false") | undefined;
        "aria-setsize"?: number | undefined | undefined;
        "aria-sort"?: "none" | "ascending" | "descending" | "other" | undefined | undefined;
        "aria-valuemax"?: number | undefined | undefined;
        "aria-valuemin"?: number | undefined | undefined;
        "aria-valuenow"?: number | undefined | undefined;
        "aria-valuetext"?: string | undefined | undefined;
        dangerouslySetInnerHTML?: {
            __html: string | TrustedHTML;
        } | undefined | undefined;
        onCopy?: React.ClipboardEventHandler<HTMLButtonElement> | undefined;
        onCopyCapture?: React.ClipboardEventHandler<HTMLButtonElement> | undefined;
        onCut?: React.ClipboardEventHandler<HTMLButtonElement> | undefined;
        onCutCapture?: React.ClipboardEventHandler<HTMLButtonElement> | undefined;
        onPaste?: React.ClipboardEventHandler<HTMLButtonElement> | undefined;
        onPasteCapture?: React.ClipboardEventHandler<HTMLButtonElement> | undefined;
        onCompositionEnd?: React.CompositionEventHandler<HTMLButtonElement> | undefined;
        onCompositionEndCapture?: React.CompositionEventHandler<HTMLButtonElement> | undefined;
        onCompositionStart?: React.CompositionEventHandler<HTMLButtonElement> | undefined;
        onCompositionStartCapture?: React.CompositionEventHandler<HTMLButtonElement> | undefined;
        onCompositionUpdate?: React.CompositionEventHandler<HTMLButtonElement> | undefined;
        onCompositionUpdateCapture?: React.CompositionEventHandler<HTMLButtonElement> | undefined;
        onFocus?: React.FocusEventHandler<HTMLButtonElement> | undefined;
        onFocusCapture?: React.FocusEventHandler<HTMLButtonElement> | undefined;
        onBlur?: React.FocusEventHandler<HTMLButtonElement> | undefined;
        onBlurCapture?: React.FocusEventHandler<HTMLButtonElement> | undefined;
        onChangeCapture?: React.FormEventHandler<HTMLButtonElement> | undefined;
        onBeforeInput?: React.FormEventHandler<HTMLButtonElement> | undefined;
        onBeforeInputCapture?: React.FormEventHandler<HTMLButtonElement> | undefined;
        onInput?: React.FormEventHandler<HTMLButtonElement> | undefined;
        onInputCapture?: React.FormEventHandler<HTMLButtonElement> | undefined;
        onReset?: React.FormEventHandler<HTMLButtonElement> | undefined;
        onResetCapture?: React.FormEventHandler<HTMLButtonElement> | undefined;
        onSubmit?: React.FormEventHandler<HTMLButtonElement> | undefined;
        onSubmitCapture?: React.FormEventHandler<HTMLButtonElement> | undefined;
        onInvalid?: React.FormEventHandler<HTMLButtonElement> | undefined;
        onInvalidCapture?: React.FormEventHandler<HTMLButtonElement> | undefined;
        onLoad?: React.ReactEventHandler<HTMLButtonElement> | undefined;
        onLoadCapture?: React.ReactEventHandler<HTMLButtonElement> | undefined;
        onError?: React.ReactEventHandler<HTMLButtonElement> | undefined;
        onErrorCapture?: React.ReactEventHandler<HTMLButtonElement> | undefined;
        onKeyDown?: React.KeyboardEventHandler<HTMLButtonElement> | undefined;
        onKeyDownCapture?: React.KeyboardEventHandler<HTMLButtonElement> | undefined;
        onKeyPress?: React.KeyboardEventHandler<HTMLButtonElement> | undefined;
        onKeyPressCapture?: React.KeyboardEventHandler<HTMLButtonElement> | undefined;
        onKeyUp?: React.KeyboardEventHandler<HTMLButtonElement> | undefined;
        onKeyUpCapture?: React.KeyboardEventHandler<HTMLButtonElement> | undefined;
        onAbort?: React.ReactEventHandler<HTMLButtonElement> | undefined;
        onAbortCapture?: React.ReactEventHandler<HTMLButtonElement> | undefined;
        onCanPlay?: React.ReactEventHandler<HTMLButtonElement> | undefined;
        onCanPlayCapture?: React.ReactEventHandler<HTMLButtonElement> | undefined;
        onCanPlayThrough?: React.ReactEventHandler<HTMLButtonElement> | undefined;
        onCanPlayThroughCapture?: React.ReactEventHandler<HTMLButtonElement> | undefined;
        onDurationChange?: React.ReactEventHandler<HTMLButtonElement> | undefined;
        onDurationChangeCapture?: React.ReactEventHandler<HTMLButtonElement> | undefined;
        onEmptied?: React.ReactEventHandler<HTMLButtonElement> | undefined;
        onEmptiedCapture?: React.ReactEventHandler<HTMLButtonElement> | undefined;
        onEncrypted?: React.ReactEventHandler<HTMLButtonElement> | undefined;
        onEncryptedCapture?: React.ReactEventHandler<HTMLButtonElement> | undefined;
        onEnded?: React.ReactEventHandler<HTMLButtonElement> | undefined;
        onEndedCapture?: React.ReactEventHandler<HTMLButtonElement> | undefined;
        onLoadedData?: React.ReactEventHandler<HTMLButtonElement> | undefined;
        onLoadedDataCapture?: React.ReactEventHandler<HTMLButtonElement> | undefined;
        onLoadedMetadata?: React.ReactEventHandler<HTMLButtonElement> | undefined;
        onLoadedMetadataCapture?: React.ReactEventHandler<HTMLButtonElement> | undefined;
        onLoadStart?: React.ReactEventHandler<HTMLButtonElement> | undefined;
        onLoadStartCapture?: React.ReactEventHandler<HTMLButtonElement> | undefined;
        onPause?: React.ReactEventHandler<HTMLButtonElement> | undefined;
        onPauseCapture?: React.ReactEventHandler<HTMLButtonElement> | undefined;
        onPlay?: React.ReactEventHandler<HTMLButtonElement> | undefined;
        onPlayCapture?: React.ReactEventHandler<HTMLButtonElement> | undefined;
        onPlaying?: React.ReactEventHandler<HTMLButtonElement> | undefined;
        onPlayingCapture?: React.ReactEventHandler<HTMLButtonElement> | undefined;
        onProgress?: React.ReactEventHandler<HTMLButtonElement> | undefined;
        onProgressCapture?: React.ReactEventHandler<HTMLButtonElement> | undefined;
        onRateChange?: React.ReactEventHandler<HTMLButtonElement> | undefined;
        onRateChangeCapture?: React.ReactEventHandler<HTMLButtonElement> | undefined;
        onResize?: React.ReactEventHandler<HTMLButtonElement> | undefined;
        onResizeCapture?: React.ReactEventHandler<HTMLButtonElement> | undefined;
        onSeeked?: React.ReactEventHandler<HTMLButtonElement> | undefined;
        onSeekedCapture?: React.ReactEventHandler<HTMLButtonElement> | undefined;
        onSeeking?: React.ReactEventHandler<HTMLButtonElement> | undefined;
        onSeekingCapture?: React.ReactEventHandler<HTMLButtonElement> | undefined;
        onStalled?: React.ReactEventHandler<HTMLButtonElement> | undefined;
        onStalledCapture?: React.ReactEventHandler<HTMLButtonElement> | undefined;
        onSuspend?: React.ReactEventHandler<HTMLButtonElement> | undefined;
        onSuspendCapture?: React.ReactEventHandler<HTMLButtonElement> | undefined;
        onTimeUpdate?: React.ReactEventHandler<HTMLButtonElement> | undefined;
        onTimeUpdateCapture?: React.ReactEventHandler<HTMLButtonElement> | undefined;
        onVolumeChange?: React.ReactEventHandler<HTMLButtonElement> | undefined;
        onVolumeChangeCapture?: React.ReactEventHandler<HTMLButtonElement> | undefined;
        onWaiting?: React.ReactEventHandler<HTMLButtonElement> | undefined;
        onWaitingCapture?: React.ReactEventHandler<HTMLButtonElement> | undefined;
        onAuxClick?: React.MouseEventHandler<HTMLButtonElement> | undefined;
        onAuxClickCapture?: React.MouseEventHandler<HTMLButtonElement> | undefined;
        onClick?: React.MouseEventHandler<HTMLButtonElement> | undefined;
        onClickCapture?: React.MouseEventHandler<HTMLButtonElement> | undefined;
        onContextMenu?: React.MouseEventHandler<HTMLButtonElement> | undefined;
        onContextMenuCapture?: React.MouseEventHandler<HTMLButtonElement> | undefined;
        onDoubleClick?: React.MouseEventHandler<HTMLButtonElement> | undefined;
        onDoubleClickCapture?: React.MouseEventHandler<HTMLButtonElement> | undefined;
        onDrag?: React.DragEventHandler<HTMLButtonElement> | undefined;
        onDragCapture?: React.DragEventHandler<HTMLButtonElement> | undefined;
        onDragEnd?: React.DragEventHandler<HTMLButtonElement> | undefined;
        onDragEndCapture?: React.DragEventHandler<HTMLButtonElement> | undefined;
        onDragEnter?: React.DragEventHandler<HTMLButtonElement> | undefined;
        onDragEnterCapture?: React.DragEventHandler<HTMLButtonElement> | undefined;
        onDragExit?: React.DragEventHandler<HTMLButtonElement> | undefined;
        onDragExitCapture?: React.DragEventHandler<HTMLButtonElement> | undefined;
        onDragLeave?: React.DragEventHandler<HTMLButtonElement> | undefined;
        onDragLeaveCapture?: React.DragEventHandler<HTMLButtonElement> | undefined;
        onDragOver?: React.DragEventHandler<HTMLButtonElement> | undefined;
        onDragOverCapture?: React.DragEventHandler<HTMLButtonElement> | undefined;
        onDragStart?: React.DragEventHandler<HTMLButtonElement> | undefined;
        onDragStartCapture?: React.DragEventHandler<HTMLButtonElement> | undefined;
        onDrop?: React.DragEventHandler<HTMLButtonElement> | undefined;
        onDropCapture?: React.DragEventHandler<HTMLButtonElement> | undefined;
        onMouseDown?: React.MouseEventHandler<HTMLButtonElement> | undefined;
        onMouseDownCapture?: React.MouseEventHandler<HTMLButtonElement> | undefined;
        onMouseEnter?: React.MouseEventHandler<HTMLButtonElement> | undefined;
        onMouseLeave?: React.MouseEventHandler<HTMLButtonElement> | undefined;
        onMouseMove?: React.MouseEventHandler<HTMLButtonElement> | undefined;
        onMouseMoveCapture?: React.MouseEventHandler<HTMLButtonElement> | undefined;
        onMouseOut?: React.MouseEventHandler<HTMLButtonElement> | undefined;
        onMouseOutCapture?: React.MouseEventHandler<HTMLButtonElement> | undefined;
        onMouseOver?: React.MouseEventHandler<HTMLButtonElement> | undefined;
        onMouseOverCapture?: React.MouseEventHandler<HTMLButtonElement> | undefined;
        onMouseUp?: React.MouseEventHandler<HTMLButtonElement> | undefined;
        onMouseUpCapture?: React.MouseEventHandler<HTMLButtonElement> | undefined;
        onSelect?: React.ReactEventHandler<HTMLButtonElement> | undefined;
        onSelectCapture?: React.ReactEventHandler<HTMLButtonElement> | undefined;
        onTouchCancel?: React.TouchEventHandler<HTMLButtonElement> | undefined;
        onTouchCancelCapture?: React.TouchEventHandler<HTMLButtonElement> | undefined;
        onTouchEnd?: React.TouchEventHandler<HTMLButtonElement> | undefined;
        onTouchEndCapture?: React.TouchEventHandler<HTMLButtonElement> | undefined;
        onTouchMove?: React.TouchEventHandler<HTMLButtonElement> | undefined;
        onTouchMoveCapture?: React.TouchEventHandler<HTMLButtonElement> | undefined;
        onTouchStart?: React.TouchEventHandler<HTMLButtonElement> | undefined;
        onTouchStartCapture?: React.TouchEventHandler<HTMLButtonElement> | undefined;
        onPointerDown?: React.PointerEventHandler<HTMLButtonElement> | undefined;
        onPointerDownCapture?: React.PointerEventHandler<HTMLButtonElement> | undefined;
        onPointerMove?: React.PointerEventHandler<HTMLButtonElement> | undefined;
        onPointerMoveCapture?: React.PointerEventHandler<HTMLButtonElement> | undefined;
        onPointerUp?: React.PointerEventHandler<HTMLButtonElement> | undefined;
        onPointerUpCapture?: React.PointerEventHandler<HTMLButtonElement> | undefined;
        onPointerCancel?: React.PointerEventHandler<HTMLButtonElement> | undefined;
        onPointerCancelCapture?: React.PointerEventHandler<HTMLButtonElement> | undefined;
        onPointerEnter?: React.PointerEventHandler<HTMLButtonElement> | undefined;
        onPointerLeave?: React.PointerEventHandler<HTMLButtonElement> | undefined;
        onPointerOver?: React.PointerEventHandler<HTMLButtonElement> | undefined;
        onPointerOverCapture?: React.PointerEventHandler<HTMLButtonElement> | undefined;
        onPointerOut?: React.PointerEventHandler<HTMLButtonElement> | undefined;
        onPointerOutCapture?: React.PointerEventHandler<HTMLButtonElement> | undefined;
        onGotPointerCapture?: React.PointerEventHandler<HTMLButtonElement> | undefined;
        onGotPointerCaptureCapture?: React.PointerEventHandler<HTMLButtonElement> | undefined;
        onLostPointerCapture?: React.PointerEventHandler<HTMLButtonElement> | undefined;
        onLostPointerCaptureCapture?: React.PointerEventHandler<HTMLButtonElement> | undefined;
        onScroll?: React.UIEventHandler<HTMLButtonElement> | undefined;
        onScrollCapture?: React.UIEventHandler<HTMLButtonElement> | undefined;
        onWheel?: React.WheelEventHandler<HTMLButtonElement> | undefined;
        onWheelCapture?: React.WheelEventHandler<HTMLButtonElement> | undefined;
        onAnimationStart?: React.AnimationEventHandler<HTMLButtonElement> | undefined;
        onAnimationStartCapture?: React.AnimationEventHandler<HTMLButtonElement> | undefined;
        onAnimationEnd?: React.AnimationEventHandler<HTMLButtonElement> | undefined;
        onAnimationEndCapture?: React.AnimationEventHandler<HTMLButtonElement> | undefined;
        onAnimationIteration?: React.AnimationEventHandler<HTMLButtonElement> | undefined;
        onAnimationIterationCapture?: React.AnimationEventHandler<HTMLButtonElement> | undefined;
        onTransitionEnd?: React.TransitionEventHandler<HTMLButtonElement> | undefined;
        onTransitionEndCapture?: React.TransitionEventHandler<HTMLButtonElement> | undefined;
        asChild?: boolean | undefined;
        disabled?: boolean | undefined | undefined;
        name?: string | undefined | undefined;
        type?: "submit" | "reset" | "button" | undefined | undefined;
        formAction?: string | undefined;
        formEncType?: string | undefined | undefined;
        formMethod?: string | undefined | undefined;
        formNoValidate?: boolean | undefined | undefined;
        formTarget?: string | undefined | undefined;
        size?: "default" | "icon" | "sm" | "lg" | null | undefined;
        variant?: "default" | "link" | "destructive" | "outline" | "secondary" | "ghost" | null | undefined;
        hideChevron?: boolean | undefined;
    } & {
        open?: boolean;
        setOpen?: (open: boolean) => void;
        value?: CurrencyCode;
        currencies?: Record<CurrencyCode, Currency>;
        display?: "icon" | "label" | "code";
        onChange?: (value: CurrencyCode) => void;
    } & React.RefAttributes<HTMLButtonElement>>;
    SelectCurrencyCommand: ({ currencies, value, onSelect, focusOnMount, }: {
        currencies?: Record<CurrencyCode, Currency>;
        value?: CurrencyCode;
        onSelect: (code: CurrencyCode) => void;
        focusOnMount?: boolean;
    }) => import("react/jsx-runtime").JSX.Element;
};
