import React from 'react';
export declare const TimezoneSelect: React.ForwardRefExoticComponent<Omit<Omit<import("erxes-ui/components").ButtonProps & React.RefAttributes<HTMLButtonElement>, "ref"> & {
    hideChevron?: boolean;
} & React.RefAttributes<HTMLButtonElement> & {
    value: string;
    onValueChange: (value: string) => void;
}, "ref"> & React.RefAttributes<HTMLButtonElement>>;
