import { ValidationStatus } from 'erxes-ui/types';
export type TEmailsOnValueChange = ({ primaryEmail, emails, emailValidationStatus, }: {
    primaryEmail: string;
    emails: string[];
    emailValidationStatus: ValidationStatus;
}) => void;
export interface IEmailField {
    email?: string;
    status?: ValidationStatus;
    isPrimary?: boolean;
}
export type TEmails = IEmailField[];
export interface IEmailFieldProps {
    primaryEmail: string;
    emails: string[];
    emailValidationStatus: ValidationStatus;
}
export declare const EmailFieldsProvider: ({ children, recordId, onValueChange, noValidation, onValidationStatusChange, }: {
    children: React.ReactNode;
    recordId: string;
    onValueChange: TEmailsOnValueChange;
    noValidation?: boolean;
    onValidationStatusChange?: (status: ValidationStatus) => void;
}) => import("react/jsx-runtime").JSX.Element;
export declare const EmailListField: ({ recordId, onValueChange, onValidationStatusChange, noValidation, primaryEmail, emails, emailValidationStatus, }: IEmailFieldProps & {
    recordId: string;
    onValueChange: TEmailsOnValueChange;
    onValidationStatusChange?: (status: ValidationStatus) => void;
    noValidation?: boolean;
}) => import("react/jsx-runtime").JSX.Element;
