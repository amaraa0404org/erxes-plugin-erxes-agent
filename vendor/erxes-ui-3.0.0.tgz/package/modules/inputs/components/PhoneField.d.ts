import { ValidationStatus } from 'erxes-ui/types';
export interface IPhoneField {
    phone?: string;
    status?: ValidationStatus;
    isPrimary?: boolean;
}
export type TPhones = IPhoneField[];
interface PhoneListFieldProps extends IPhoneFieldProps {
    recordId: string;
    onValueChange: (values: IPhoneFieldProps) => void;
    onValidationStatusChange?: (status: ValidationStatus) => void;
}
export declare const PhonesBadgeDisplay: ({ phones, }: {
    phones: TPhones | undefined;
}) => import("react/jsx-runtime").JSX.Element;
export interface PhoneListFieldInlineCellProps {
    recordId: string;
    phones: TPhones;
    onValueChange: (phones: TPhones) => void;
    onValidationStatusChange?: (status: ValidationStatus) => void;
    scope?: string;
}
export interface PhoneFieldDetailProps {
    recordId: string;
    phones: TPhones;
    onValueChange: (phones: TPhones) => void;
    onValidationStatusChange?: (status: ValidationStatus) => void;
    scope?: string;
}
export interface IPhoneFieldProps {
    primaryPhone: string;
    phones: string[];
    phoneValidationStatus?: ValidationStatus;
}
export declare const PhoneField: import("react").ForwardRefExoticComponent<PhoneListFieldProps & import("react").HTMLAttributes<HTMLDivElement> & import("react").RefAttributes<HTMLDivElement>> & {
    Provider: import("react").ForwardRefExoticComponent<{
        children: React.ReactNode;
        recordId: string;
        onValueChange: (phones: TPhones) => void;
        onValidationStatusChange?: (status: ValidationStatus) => void;
    } & import("react").HTMLAttributes<HTMLDivElement> & import("react").RefAttributes<HTMLDivElement>>;
    Container: {
        ({ className, ...props }: React.HTMLAttributes<HTMLDivElement>): import("react/jsx-runtime").JSX.Element;
        displayName: string;
    };
    List: ({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) => import("react/jsx-runtime").JSX.Element;
    Item: import("react").ForwardRefExoticComponent<Omit<IPhoneField & import("erxes-ui/components").ButtonProps & import("react").RefAttributes<HTMLButtonElement>, "ref"> & import("react").RefAttributes<HTMLButtonElement>>;
    Options: import("react").ForwardRefExoticComponent<Omit<IPhoneField & import("erxes-ui/components").ButtonProps & import("react").RefAttributes<HTMLButtonElement>, "ref"> & import("react").RefAttributes<HTMLButtonElement>>;
    Form: import("react").ForwardRefExoticComponent<import("react").HTMLAttributes<HTMLDivElement> & {
        defaultCountry?: string;
    } & import("react").RefAttributes<HTMLDivElement>>;
    BadgeDisplay: ({ phones, }: {
        phones: TPhones | undefined;
    }) => import("react/jsx-runtime").JSX.Element;
};
export {};
