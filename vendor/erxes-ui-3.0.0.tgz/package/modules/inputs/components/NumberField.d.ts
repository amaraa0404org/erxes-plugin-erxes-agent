import { IMaskInput } from 'react-imask';
import { Except } from 'type-fest';
export declare const NumberInput: ({ onChange, value, className, ...props }: Except<React.ComponentPropsWithoutRef<typeof IMaskInput>, "onChange" | "value"> & {
    onChange?: (value: number) => void;
    value?: number;
}) => import("react/jsx-runtime").JSX.Element;
