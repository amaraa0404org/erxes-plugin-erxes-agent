import { IPhoneStatus, TPhones } from '../components/PhoneField';
export declare const PhoneFieldsContext: import("react").Context<{
    recordId: string;
    onValueChange?: (phones: TPhones) => void;
    onValidationStatusChange?: (status: IPhoneStatus) => void;
}>;
