import { TEmails } from '../components/EmailField';
import { ValidationStatus } from 'erxes-ui/types';
export declare const EmailFieldsContext: import("react").Context<{
    recordId: string;
    onValueChange?: (emails: TEmails) => void;
    noValidation?: boolean;
    onValidationStatusChange?: (status: ValidationStatus) => void;
}>;
