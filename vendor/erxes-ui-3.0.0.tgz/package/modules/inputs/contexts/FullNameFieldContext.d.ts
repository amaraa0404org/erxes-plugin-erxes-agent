export declare const FullNameFieldContext: import("react").Context<{
    fullName: string;
    firstName: string;
    lastName: string;
    setFirstName: (firstName: string) => void;
    setLastName: (lastName: string) => void;
} | null>;
