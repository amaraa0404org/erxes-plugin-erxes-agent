export declare const NavigationMenuLinkItem: import("react").ForwardRefExoticComponent<Omit<Omit<import("react").ClassAttributes<HTMLButtonElement> & import("react").ButtonHTMLAttributes<HTMLButtonElement> & {
    asChild?: boolean;
    isActive?: boolean;
    tooltip?: string | React.ComponentProps<import("react").ForwardRefExoticComponent<Omit<import("@radix-ui/react-tooltip").TooltipContentProps & import("react").RefAttributes<HTMLDivElement>, "ref"> & import("react").RefAttributes<HTMLDivElement>>>;
    tooltipVisibility?: "collapsed" | "always";
} & import("class-variance-authority").VariantProps<(props?: ({
    variant?: "default" | "outline" | null | undefined;
    size?: "default" | "sm" | "lg" | null | undefined;
} & import("class-variance-authority/types").ClassProp) | undefined) => string>, "ref"> & import("react").RefAttributes<HTMLButtonElement> & {
    name: string;
    icon?: React.ElementType;
    path: string;
    pathPrefix?: string;
    isActive?: boolean;
    label?: React.ReactNode;
    action?: React.ReactNode;
    itemClassName?: string;
}, "ref"> & import("react").RefAttributes<HTMLButtonElement>>;
export declare const SettingsNavigationMenuLinkItem: import("react").ForwardRefExoticComponent<Omit<Omit<Omit<import("react").ClassAttributes<HTMLButtonElement> & import("react").ButtonHTMLAttributes<HTMLButtonElement> & {
    asChild?: boolean;
    isActive?: boolean;
    tooltip?: string | React.ComponentProps<import("react").ForwardRefExoticComponent<Omit<import("@radix-ui/react-tooltip").TooltipContentProps & import("react").RefAttributes<HTMLDivElement>, "ref"> & import("react").RefAttributes<HTMLDivElement>>>;
    tooltipVisibility?: "collapsed" | "always";
} & import("class-variance-authority").VariantProps<(props?: ({
    variant?: "default" | "outline" | null | undefined;
    size?: "default" | "sm" | "lg" | null | undefined;
} & import("class-variance-authority/types").ClassProp) | undefined) => string>, "ref"> & import("react").RefAttributes<HTMLButtonElement> & {
    name: string;
    icon?: React.ElementType;
    path: string;
    pathPrefix?: string;
    isActive?: boolean;
    label?: React.ReactNode;
    action?: React.ReactNode;
    itemClassName?: string;
}, "ref"> & import("react").RefAttributes<HTMLButtonElement>, "ref"> & import("react").RefAttributes<HTMLButtonElement>>;
export declare const NavigationMenuItem: import("react").ForwardRefExoticComponent<Omit<Omit<import("react").ClassAttributes<HTMLButtonElement> & import("react").ButtonHTMLAttributes<HTMLButtonElement> & {
    asChild?: boolean;
    isActive?: boolean;
    tooltip?: string | React.ComponentProps<import("react").ForwardRefExoticComponent<Omit<import("@radix-ui/react-tooltip").TooltipContentProps & import("react").RefAttributes<HTMLDivElement>, "ref"> & import("react").RefAttributes<HTMLDivElement>>>;
    tooltipVisibility?: "collapsed" | "always";
} & import("class-variance-authority").VariantProps<(props?: ({
    variant?: "default" | "outline" | null | undefined;
    size?: "default" | "sm" | "lg" | null | undefined;
} & import("class-variance-authority/types").ClassProp) | undefined) => string>, "ref"> & import("react").RefAttributes<HTMLButtonElement> & {
    name: string;
    icon?: React.ElementType;
}, "ref"> & import("react").RefAttributes<HTMLButtonElement>>;
export declare const NavigationMenuGroup: import("react").ForwardRefExoticComponent<Omit<Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "ref"> & import("react").RefAttributes<HTMLDivElement> & {
    name: string;
    children: React.ReactNode;
    separate?: boolean;
    defaultOpen?: boolean;
    actions?: React.ReactNode;
}, "ref"> & import("react").RefAttributes<HTMLDivElement>>;
