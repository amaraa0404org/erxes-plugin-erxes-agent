import { Icon } from '@tabler/icons-react';
export declare const SideMenuRoot: import("react").ForwardRefExoticComponent<Omit<import("@radix-ui/react-tabs").TabsProps & import("react").RefAttributes<HTMLDivElement>, "ref"> & import("react").RefAttributes<HTMLDivElement>>;
export declare const SideMenuContent: import("react").ForwardRefExoticComponent<Omit<Omit<import("@radix-ui/react-tabs").TabsContentProps & import("react").RefAttributes<HTMLDivElement>, "ref"> & import("react").RefAttributes<HTMLDivElement>, "ref"> & import("react").RefAttributes<HTMLDivElement>>;
export declare const SideMenuContentHeader: import("react").ForwardRefExoticComponent<Omit<import("react").ClassAttributes<HTMLDivElement> & import("react").HTMLAttributes<HTMLDivElement> & {
    Icon?: Icon;
    label?: string;
    hideSeparator?: boolean;
}, "ref"> & import("react").RefAttributes<HTMLDivElement>>;
export declare const SideMenuSidebar: import("react").ForwardRefExoticComponent<Omit<Omit<import("@radix-ui/react-tabs").TabsListProps & import("react").RefAttributes<HTMLDivElement>, "ref"> & import("class-variance-authority").VariantProps<(props?: ({
    variant?: "underline" | "segment" | null | undefined;
} & import("class-variance-authority/types").ClassProp) | undefined) => string> & import("react").RefAttributes<HTMLDivElement>, "ref"> & import("react").RefAttributes<HTMLDivElement>>;
export declare const SideMenuTrigger: import("react").ForwardRefExoticComponent<Omit<Omit<import("@radix-ui/react-tabs").TabsTriggerProps & import("react").RefAttributes<HTMLButtonElement>, "ref"> & import("class-variance-authority").VariantProps<(props?: ({
    variant?: "underline" | "segment" | null | undefined;
} & import("class-variance-authority/types").ClassProp) | undefined) => string> & import("react").RefAttributes<HTMLButtonElement>, "ref"> & {
    label?: string;
    Icon?: Icon;
} & import("react").RefAttributes<HTMLButtonElement>>;
export declare const SideMenu: import("react").ForwardRefExoticComponent<Omit<import("@radix-ui/react-tabs").TabsProps & import("react").RefAttributes<HTMLDivElement>, "ref"> & import("react").RefAttributes<HTMLDivElement>> & {
    Sidebar: import("react").ForwardRefExoticComponent<Omit<Omit<import("@radix-ui/react-tabs").TabsListProps & import("react").RefAttributes<HTMLDivElement>, "ref"> & import("class-variance-authority").VariantProps<(props?: ({
        variant?: "underline" | "segment" | null | undefined;
    } & import("class-variance-authority/types").ClassProp) | undefined) => string> & import("react").RefAttributes<HTMLDivElement>, "ref"> & import("react").RefAttributes<HTMLDivElement>>;
    Content: import("react").ForwardRefExoticComponent<Omit<Omit<import("@radix-ui/react-tabs").TabsContentProps & import("react").RefAttributes<HTMLDivElement>, "ref"> & import("react").RefAttributes<HTMLDivElement>, "ref"> & import("react").RefAttributes<HTMLDivElement>>;
    Header: import("react").ForwardRefExoticComponent<Omit<import("react").ClassAttributes<HTMLDivElement> & import("react").HTMLAttributes<HTMLDivElement> & {
        Icon?: Icon;
        label?: string;
        hideSeparator?: boolean;
    }, "ref"> & import("react").RefAttributes<HTMLDivElement>>;
    Trigger: import("react").ForwardRefExoticComponent<Omit<Omit<import("@radix-ui/react-tabs").TabsTriggerProps & import("react").RefAttributes<HTMLButtonElement>, "ref"> & import("class-variance-authority").VariantProps<(props?: ({
        variant?: "underline" | "segment" | null | undefined;
    } & import("class-variance-authority/types").ClassProp) | undefined) => string> & import("react").RefAttributes<HTMLButtonElement>, "ref"> & {
        label?: string;
        Icon?: Icon;
    } & import("react").RefAttributes<HTMLButtonElement>>;
};
