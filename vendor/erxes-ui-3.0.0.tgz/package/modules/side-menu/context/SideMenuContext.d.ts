import React from 'react';
interface SideMenuContextValue {
    activeTab?: string;
    setActiveTab: (activeTab?: string) => void;
}
export declare const SideMenuContext: React.Context<SideMenuContextValue | null>;
export declare const useSideMenuContext: () => SideMenuContextValue;
export {};
