import { Transition, Variants, AnimatePresenceProps } from 'motion/react';
export type TextLoopProps = {
    children: React.ReactNode[];
    className?: string;
    interval?: number;
    transition?: Transition;
    variants?: Variants;
    onIndexChange?: (index: number) => void;
    trigger?: boolean;
    mode?: AnimatePresenceProps['mode'];
};
export declare function TextLoop({ children, className, interval, transition, variants, onIndexChange, trigger, mode, }: TextLoopProps): import("react/jsx-runtime").JSX.Element;
