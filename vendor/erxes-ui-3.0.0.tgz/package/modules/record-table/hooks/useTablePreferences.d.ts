import type { ColumnPinningState } from '@tanstack/react-table';
export interface TablePrefs {
    columnOrder?: string[];
    columnPinning?: ColumnPinningState;
    columnSizing?: Record<string, number>;
    columnVisibility?: Record<string, boolean>;
}
export declare const useTablePreferences: (tableId: string | undefined) => {
    prefs: TablePrefs;
    savePrefs: (updates: Partial<TablePrefs>) => void;
};
