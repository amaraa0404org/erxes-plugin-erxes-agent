export declare const useRecordTableCursorContext: () => import("..").IRecordTableCursorContext;
