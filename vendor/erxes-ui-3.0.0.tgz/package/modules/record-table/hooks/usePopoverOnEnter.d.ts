export declare const usePopoverOnEnter: (scope: string, onEnter: () => void, dependencies: any[]) => {
    scopeHandleOnOpenChange: (open: boolean) => void;
};
