export declare const useRecordTableCursor: ({ sessionKey, }: {
    sessionKey?: string;
}) => {
    cursor: string;
    setCursor: (args_0: string | ((prev: string) => string)) => void;
};
