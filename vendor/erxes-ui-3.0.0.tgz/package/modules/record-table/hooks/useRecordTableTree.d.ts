export declare const useRecordTableTreeContext: () => import("../types/RecordTableTreeTypes").IRecordTableTreeContext;
export declare const useRecordTableTree: (order: string) => {
    id: string;
    hideChildren: string[];
    toggleHideChildren: (order: string) => void;
    ordered: boolean | undefined;
    isHiddenByParent: boolean;
    isHidden: boolean;
};
