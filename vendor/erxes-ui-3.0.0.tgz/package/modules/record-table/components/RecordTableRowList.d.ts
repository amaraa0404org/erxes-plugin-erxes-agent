import { RecordTableRow } from './RecordTableRow';
export declare const RecordTableRowList: ({ handleRowViewChange, Row, }: {
    handleRowViewChange?: (id: string, inView: boolean) => void;
    Row?: React.ComponentType<React.ComponentProps<typeof RecordTableRow>>;
}) => import("react/jsx-runtime").JSX.Element[];
