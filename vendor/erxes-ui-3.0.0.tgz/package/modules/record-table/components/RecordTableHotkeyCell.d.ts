import React from 'react';
import { Slot } from 'radix-ui';
export declare const RecordTableHotKeyControl: React.ForwardRefExoticComponent<Omit<Slot.SlotProps & React.RefAttributes<HTMLElement>, "ref"> & {
    rowId: string;
    rowIndex: number;
    colIndex?: number;
    enableOnFormTags?: boolean;
} & React.RefAttributes<HTMLElement>>;
