import React from 'react';
import { ButtonProps } from 'erxes-ui/components';
export declare const RecordTableMoreButton: React.ForwardRefExoticComponent<ButtonProps & React.RefAttributes<HTMLButtonElement>>;
