import { ButtonProps } from 'erxes-ui/components';
import React from 'react';
import { IRecordTableTreeContext } from '../types/RecordTableTreeTypes';
export declare const RecordTableTree: (({ id, children, ordered, length, }: IRecordTableTreeContext) => import("react/jsx-runtime").JSX.Element) & {
    Indentation: ({ order, name, }: {
        order: string;
        name: string;
    }) => import("react/jsx-runtime").JSX.Element | null;
    Arrow: React.ForwardRefExoticComponent<ButtonProps & {
        order: string;
        hasChildren: boolean;
    } & React.RefAttributes<HTMLButtonElement>>;
    Trigger: React.ForwardRefExoticComponent<Omit<React.HTMLAttributes<HTMLDivElement>, "children"> & {
        order: string;
        name: string;
        hasChildren: boolean;
        children?: React.ReactNode;
    } & React.RefAttributes<HTMLDivElement>>;
    Row: React.ForwardRefExoticComponent<Omit<React.HTMLAttributes<HTMLTableRowElement> & {
        handleRowViewChange?: (inView: boolean) => void;
        original?: import("@tanstack/table-core").Row<any>["original"];
    } & React.RefAttributes<HTMLTableRowElement>, "ref"> & React.RefAttributes<HTMLTableRowElement>>;
};
