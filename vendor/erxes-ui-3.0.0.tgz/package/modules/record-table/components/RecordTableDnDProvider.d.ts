import { ColumnOrderState } from '@tanstack/react-table';
import type { OnChangeFn } from '@tanstack/table-core';
interface RecordTableDnDProviderProps {
    children: React.ReactNode;
    setColumnOrder: OnChangeFn<ColumnOrderState>;
}
export declare const RecordTableDnDProvider: ({ children, setColumnOrder, }: RecordTableDnDProviderProps) => import("react/jsx-runtime").JSX.Element;
export {};
