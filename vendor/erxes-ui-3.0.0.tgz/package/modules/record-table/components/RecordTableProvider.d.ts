import { HTMLAttributes, type ReactNode } from 'react';
import { ColumnDef, type TableOptions } from '@tanstack/react-table';
import { IRecordTableContext } from 'erxes-ui/modules/record-table/types/recordTableTypes';
export declare function useRecordTable(): IRecordTableContext;
export interface RecordTableProviderProps extends HTMLAttributes<HTMLDivElement> {
    children: ReactNode;
    columns: ColumnDef<any>[];
    data: any[];
    tableOptions?: TableOptions<any>;
    stickyColumns?: string[];
    tableId?: string;
}
export declare const RecordTableProvider: import("react").ForwardRefExoticComponent<RecordTableProviderProps & import("react").RefAttributes<HTMLDivElement>>;
