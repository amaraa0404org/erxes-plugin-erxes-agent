export declare const RecordTableRowSkeleton: ({ rows, handleInView, backward, root, }: {
    rows?: number;
    handleInView?: () => void;
    backward?: boolean;
    root?: Element | null;
}) => import("react/jsx-runtime").JSX.Element;
