import React from 'react';
import { Cell } from '@tanstack/react-table';
export declare const RecordTableCell: React.ForwardRefExoticComponent<React.HTMLAttributes<HTMLTableCellElement> & {
    cell: Cell<any, unknown>;
} & React.RefAttributes<HTMLTableCellElement>>;
