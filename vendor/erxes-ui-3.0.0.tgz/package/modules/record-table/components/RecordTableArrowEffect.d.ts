export declare const RecordTableArrowEffect: ({ columnLength, rowLength, }: {
    columnLength: number;
    rowLength: number;
}) => null;
