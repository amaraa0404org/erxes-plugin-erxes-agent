export declare const RecordTableColumnSelector: ({ children, align, }: {
    children?: React.ReactElement;
    align?: "start" | "center" | "end";
}) => import("react/jsx-runtime").JSX.Element | null;
