import React from 'react';
import { Row } from '@tanstack/react-table';
export declare const RecordTableRow: React.ForwardRefExoticComponent<React.HTMLAttributes<HTMLTableRowElement> & {
    handleRowViewChange?: (inView: boolean) => void;
    original?: Row<any>["original"];
} & React.RefAttributes<HTMLTableRowElement>>;
