import { EnumCursorDirection } from '../types/RecordTableCursorTypes';
export declare const RecordTableCursorProvider: ({ children, hasPreviousPage, loading, dataLength, hasNextPage, sessionKey, offset, }: {
    children: React.ReactNode;
    hasPreviousPage?: boolean;
    hasNextPage?: boolean;
    loading?: boolean;
    dataLength?: number;
    sessionKey?: string;
    offset?: number;
}) => import("react/jsx-runtime").JSX.Element;
export declare const RecordTableBackwardSkeleton: ({ handleFetchMore, }: {
    handleFetchMore: (params: {
        direction: EnumCursorDirection;
    }) => void;
}) => import("react/jsx-runtime").JSX.Element | null;
export declare const RecordTableForwardSkeleton: ({ handleFetchMore, }: {
    handleFetchMore: (params: {
        direction: EnumCursorDirection;
    }) => void;
}) => import("react/jsx-runtime").JSX.Element | null;
