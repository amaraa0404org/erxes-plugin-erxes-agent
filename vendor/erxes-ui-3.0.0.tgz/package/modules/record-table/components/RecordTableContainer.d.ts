import { Table } from '@tanstack/react-table';
interface RecordTableContainerProps {
    table: Table<any>;
    children: React.ReactNode;
}
declare const RecordTableContainer: import("react").ForwardRefExoticComponent<RecordTableContainerProps & import("react").HTMLAttributes<HTMLDivElement> & import("react").RefAttributes<HTMLDivElement>>;
export default RecordTableContainer;
