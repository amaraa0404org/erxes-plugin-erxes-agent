import React from 'react';
import { Header } from '@tanstack/react-table';
export declare const recordTableHeadVariants: (props?: ({
    isDragging?: boolean | null | undefined;
    isPinned?: "right" | "left" | null | undefined;
} & import("class-variance-authority/types").ClassProp) | undefined) => string;
export declare const RecordTableHead: ({ header, children, className, ...props }: React.ComponentProps<"th"> & {
    header: Header<any, unknown>;
}) => import("react/jsx-runtime").JSX.Element;
