import { Icon } from '@tabler/icons-react';
export declare const RecordTableInlineHead: (props: {
    icon?: Icon;
    label: string;
}) => import("react/jsx-runtime").JSX.Element;
