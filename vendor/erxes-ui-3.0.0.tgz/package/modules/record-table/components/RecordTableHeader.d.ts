export declare const RecordTableHeader: ({ showColumnSelector, }: {
    showColumnSelector?: boolean;
}) => import("react/jsx-runtime").JSX.Element;
