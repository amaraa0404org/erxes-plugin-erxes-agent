import React from 'react';
import { Popover as PopoverPrimitive } from 'radix-ui';
import { UseHotkeysOptionsWithoutBuggyOptions } from 'erxes-ui/modules/hotkey';
export interface ReactTablePopoverProps extends React.ComponentPropsWithoutRef<typeof PopoverPrimitive.Root> {
    scope?: string;
    closeOnEnter?: boolean;
    scopeOptions?: UseHotkeysOptionsWithoutBuggyOptions;
}
export declare const RecordTableInlineAnchor: React.ForwardRefExoticComponent<Omit<import("erxes-ui/components").BadgeProps & React.RefAttributes<HTMLDivElement>, "ref"> & React.RefAttributes<HTMLDivElement>>;
export declare const RecordTableInlineCell: React.ForwardRefExoticComponent<Omit<import("erxes-ui/components").ButtonProps & React.RefAttributes<HTMLButtonElement>, "ref"> & React.RefAttributes<HTMLButtonElement>> & {
    Trigger: React.ForwardRefExoticComponent<Omit<import("erxes-ui/components").ButtonProps & React.RefAttributes<HTMLButtonElement>, "ref"> & React.RefAttributes<HTMLButtonElement>>;
    Content: React.ForwardRefExoticComponent<Omit<PopoverPrimitive.PopoverContentProps & React.RefAttributes<HTMLDivElement>, "ref"> & React.RefAttributes<HTMLDivElement>>;
    Anchor: React.ForwardRefExoticComponent<Omit<import("erxes-ui/components").BadgeProps & React.RefAttributes<HTMLDivElement>, "ref"> & React.RefAttributes<HTMLDivElement>>;
};
