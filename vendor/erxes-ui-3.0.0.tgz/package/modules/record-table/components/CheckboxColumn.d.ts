import { ColumnDef } from '@tanstack/react-table';
export declare const checkboxColumn: ColumnDef<any>;
