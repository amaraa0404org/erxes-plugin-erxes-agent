import { IRecordTableCursorPageInfo, EnumCursorDirection } from '../types/RecordTableCursorTypes';
interface ICursorResult<T> {
    pageInfo?: IRecordTableCursorPageInfo;
    list?: T[];
    totalCount?: number;
}
export declare const mergeCursorData: <T>({ direction, fetchMoreResult, prevResult, }: {
    direction: EnumCursorDirection;
    fetchMoreResult: ICursorResult<T>;
    prevResult: ICursorResult<T>;
}) => {
    list: T[];
    pageInfo: {
        endCursor: string | null | undefined;
        hasNextPage: boolean;
        hasPreviousPage: boolean;
        startCursor: string | null | undefined;
    };
    totalCount?: number;
};
export declare const validateFetchMore: ({ direction, pageInfo, }: {
    direction: EnumCursorDirection;
    pageInfo?: IRecordTableCursorPageInfo;
}) => boolean;
export {};
