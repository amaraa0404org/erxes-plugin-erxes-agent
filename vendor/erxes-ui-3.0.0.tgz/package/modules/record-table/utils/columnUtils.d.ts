import { Column } from '@tanstack/react-table';
export declare const STRUCTURAL_COLUMN_IDS: string[];
export declare const isStructuralColumn: (columnId: string) => boolean;
export declare const isFixedWidthColumn: <TData, TValue>(column: Column<TData, TValue>) => boolean;
