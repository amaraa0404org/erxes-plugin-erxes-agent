export declare const EditModePositionComponentState: import("jotai/vanilla/utils/atomFamily").AtomFamily<string, import("jotai").PrimitiveAtom<boolean> & {
    init: boolean;
}>;
