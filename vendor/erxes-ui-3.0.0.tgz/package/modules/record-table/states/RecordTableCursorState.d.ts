export declare const recordTableCursorAtomFamily: import("jotai/vanilla/utils/atomFamily").AtomFamily<string, import("jotai").PrimitiveAtom<string> & {
    init: string;
}>;
