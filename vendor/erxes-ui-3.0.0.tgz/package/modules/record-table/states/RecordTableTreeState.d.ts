export declare const recordTableTreeHideChildrenAtomFamily: import("jotai/vanilla/utils/atomFamily").AtomFamily<string, import("jotai").PrimitiveAtom<string[]> & {
    init: string[];
}>;
