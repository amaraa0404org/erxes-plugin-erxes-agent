import { IRecordTableCursorContext } from '../types/RecordTableCursorTypes';
export declare const RecordTableCursorContext: import("react").Context<IRecordTableCursorContext>;
