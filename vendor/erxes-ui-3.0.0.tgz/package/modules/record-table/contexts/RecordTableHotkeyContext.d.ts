import React from 'react';
interface IRecordTableHotkeyContext {
    activeRow: string | null;
    activeCell: [number, number];
    setActiveRow: (rowId: string | null) => void;
    setActiveCell: (cell: [number, number]) => void;
    scope: string;
}
export declare const RecordTableHotkeyProvider: ({ children, columnLength, rowLength, scope, }: {
    children: React.ReactNode;
    columnLength: number;
    rowLength: number;
    scope: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const useRecordTableHotkey: () => IRecordTableHotkeyContext;
export {};
