import { IRecordTableTreeContext } from '../types/RecordTableTreeTypes';
export declare const RecordTableTreeContext: import("react").Context<IRecordTableTreeContext>;
