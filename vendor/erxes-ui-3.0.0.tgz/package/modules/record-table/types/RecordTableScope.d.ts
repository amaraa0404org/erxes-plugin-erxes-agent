export declare enum RecordTableScope {
    InlineCellEdit = "InlineCellEdit"
}
