import { useRecordTable } from './components/RecordTableProvider';
import { RecordTableRow } from './components/RecordTableRow';
export declare const RecordTable: import("react").ForwardRefExoticComponent<import("react").HTMLAttributes<HTMLTableElement> & import("react").RefAttributes<HTMLTableElement>> & {
    Provider: import("react").ForwardRefExoticComponent<import("./components/RecordTableProvider").RecordTableProviderProps & import("react").RefAttributes<HTMLDivElement>>;
    Header: ({ showColumnSelector, }: {
        showColumnSelector?: boolean;
    }) => import("react/jsx-runtime").JSX.Element;
    Head: ({ header, children, className, ...props }: React.ComponentProps<"th"> & {
        header: import("@tanstack/table-core").Header<any, unknown>;
    }) => import("react/jsx-runtime").JSX.Element;
    InlineHead: (props: {
        icon?: import("@tabler/icons-react").Icon;
        label: string;
    }) => import("react/jsx-runtime").JSX.Element;
    RowList: ({ handleRowViewChange, Row, }: {
        handleRowViewChange?: (id: string, inView: boolean) => void;
        Row?: React.ComponentType<React.ComponentProps<typeof RecordTableRow>>;
    }) => import("react/jsx-runtime").JSX.Element[];
    Body: import("react").ForwardRefExoticComponent<import("react").HTMLAttributes<HTMLTableSectionElement> & import("react").RefAttributes<HTMLTableSectionElement>>;
    Cell: import("react").ForwardRefExoticComponent<import("react").HTMLAttributes<HTMLTableCellElement> & {
        cell: import("@tanstack/table-core").Cell<any, unknown>;
    } & import("react").RefAttributes<HTMLTableCellElement>>;
    useRecordTable: typeof useRecordTable;
    RowSkeleton: ({ rows, handleInView, backward, root, }: {
        rows?: number;
        handleInView?: () => void;
        backward?: boolean;
        root?: Element | null;
    }) => import("react/jsx-runtime").JSX.Element;
    MoreButton: import("react").ForwardRefExoticComponent<import("erxes-ui/components").ButtonProps & import("react").RefAttributes<HTMLButtonElement>>;
    checkboxColumn: import("@tanstack/table-core").ColumnDef<any>;
    Scroll: import("react").ForwardRefExoticComponent<Omit<Omit<import("@radix-ui/react-scroll-area").ScrollAreaProps & import("react").RefAttributes<HTMLDivElement>, "ref"> & {
        scrollBarClassName?: string;
        viewportClassName?: string;
    } & import("react").RefAttributes<HTMLDivElement>, "ref"> & import("react").RefAttributes<HTMLDivElement>>;
    CursorProvider: ({ children, hasPreviousPage, loading, dataLength, hasNextPage, sessionKey, offset, }: {
        children: React.ReactNode;
        hasPreviousPage?: boolean;
        hasNextPage?: boolean;
        loading?: boolean;
        dataLength?: number;
        sessionKey?: string;
        offset?: number;
    }) => import("react/jsx-runtime").JSX.Element;
    CursorBackwardSkeleton: ({ handleFetchMore, }: {
        handleFetchMore: (params: {
            direction: import("./types/RecordTableCursorTypes").EnumCursorDirection;
        }) => void;
    }) => import("react/jsx-runtime").JSX.Element | null;
    CursorForwardSkeleton: ({ handleFetchMore, }: {
        handleFetchMore: (params: {
            direction: import("./types/RecordTableCursorTypes").EnumCursorDirection;
        }) => void;
    }) => import("react/jsx-runtime").JSX.Element | null;
    Row: import("react").ForwardRefExoticComponent<import("react").HTMLAttributes<HTMLTableRowElement> & {
        handleRowViewChange?: (inView: boolean) => void;
        original?: import("@tanstack/table-core").Row<any>["original"];
    } & import("react").RefAttributes<HTMLTableRowElement>>;
    ColumnSelector: ({ children, align, }: {
        children?: React.ReactElement;
        align?: "start" | "center" | "end";
    }) => import("react/jsx-runtime").JSX.Element | null;
};
export * from './types/RecordTableCursorTypes';
export * from './hooks/useRecordTableCursor';
export * from './utils/cursorUtils';
export * from './components/RecordTableCellInline';
export * from './components/RecordTableTree';
export * from './contexts/RecordTableHotkeyContext';
export * from './components/RecordTableHotkeyCell';
export * from './states/RecordTableCursorState';
