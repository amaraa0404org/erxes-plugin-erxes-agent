import { ButtonProps } from 'erxes-ui/components';
import React from 'react';
export interface INumberFieldContainerProps {
    placeholder?: string;
    value: number;
    field: string;
    fieldId?: string;
    _id: string;
    scope?: string;
}
export declare const NumberField: React.ForwardRefExoticComponent<ButtonProps & {
    placeholder?: string;
    value: number;
    scope: string;
    onValueChange?: (value: number) => void;
    onSave?: (value: number) => void;
    formatValue?: (value: number) => string;
} & React.RefAttributes<HTMLButtonElement>>;
