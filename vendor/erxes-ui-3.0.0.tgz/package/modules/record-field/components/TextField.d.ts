import { ButtonProps } from 'erxes-ui/components';
import React from 'react';
export interface ITextFieldContainerProps {
    placeholder?: string;
    value: string;
    field: string;
    fieldId?: string;
    _id: string;
    scope?: string;
}
export declare const TextField: React.ForwardRefExoticComponent<ButtonProps & {
    placeholder?: string;
    value: string;
    scope?: string;
    onValueChange?: (value: string) => void;
    onSave?: (value: string) => void;
} & React.RefAttributes<HTMLButtonElement>>;
