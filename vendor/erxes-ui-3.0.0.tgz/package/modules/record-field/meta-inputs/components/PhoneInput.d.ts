import React from 'react';
import { CountryCode } from 'libphonenumber-js';
interface PhoneInputProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'value' | 'onChange'> {
    value?: string;
    onChange?: (value: string, defaultCountryCode: CountryCode) => void;
    className?: string;
    defaultCountry?: CountryCode;
    placeholder?: string;
    onEnter?: (phone: string) => void;
    onValidationChange?: (isValid: boolean, error?: string) => void;
}
export declare const PhoneInput: React.ForwardRefExoticComponent<PhoneInputProps & React.RefAttributes<HTMLInputElement>>;
export {};
