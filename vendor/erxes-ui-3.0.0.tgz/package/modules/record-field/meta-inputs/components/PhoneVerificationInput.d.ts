interface PhoneVerificationInputProps {
    value: string | null;
    className?: string;
    onChange: (value: string) => void;
    inputValue: string;
}
export declare const PhoneVerificationInput: ({ value, onChange, className, inputValue, }: PhoneVerificationInputProps) => import("react/jsx-runtime").JSX.Element;
export default PhoneVerificationInput;
