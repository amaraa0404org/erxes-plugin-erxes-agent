import * as React from 'react';
export declare const TextFieldInput: React.ForwardRefExoticComponent<React.InputHTMLAttributes<HTMLInputElement> & {
    variant?: "default" | "secondary" | null | undefined;
} & React.RefAttributes<HTMLInputElement>>;
