interface EmailVerificationInputProps {
    value: string | null;
    className?: string;
    onChange: (value: string) => void;
    inputValue: string;
}
export declare const EmailVerificationInput: ({ value, onChange, className, inputValue, }: EmailVerificationInputProps) => import("react/jsx-runtime").JSX.Element;
export default EmailVerificationInput;
