import { BoardContextProps } from '../types/boardTypes';
export declare const BoardContext: import("react").Context<BoardContextProps>;
