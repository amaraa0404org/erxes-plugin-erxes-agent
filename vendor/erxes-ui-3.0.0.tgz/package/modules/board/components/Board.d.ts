import { BoardCardProps, BoardColumnProps, BoardHeaderProps, BoardItemProps, BoardProps, BoardProviderProps } from '../types/boardTypes';
import { type HTMLAttributes } from 'react';
export type { DragEndEvent } from '@dnd-kit/core';
export declare const BoardHeader: ({ className, ...props }: BoardHeaderProps) => import("react/jsx-runtime").JSX.Element;
export declare const BoardRoot: ({ id, children, className, sortBy, isSorted, }: BoardProps & {
    sortBy?: string;
    isSorted?: boolean;
}) => import("react/jsx-runtime").JSX.Element;
export declare const Board: (({ id, children, className, sortBy, isSorted, }: BoardProps & {
    sortBy?: string;
    isSorted?: boolean;
}) => import("react/jsx-runtime").JSX.Element) & {
    Provider: <T extends BoardItemProps = BoardItemProps, C extends BoardColumnProps = BoardColumnProps>({ children, onDragStart, onDragEnd, onDragOver, className, columns, data, onDataChange, boardId, emptyUrl, fallbackComponent, ...props }: BoardProviderProps<T, C>) => string | number | true | Iterable<import("react").ReactNode> | import("react/jsx-runtime").JSX.Element | null;
    Header: ({ className, ...props }: BoardHeaderProps) => import("react/jsx-runtime").JSX.Element;
    Cards: ({ id, children, className, items, ...props }: HTMLAttributes<HTMLDivElement> & {
        id: string;
        children: React.ReactNode;
        className?: string;
        items: string[];
    }) => import("react/jsx-runtime").JSX.Element;
    Card: <T extends BoardItemProps = BoardItemProps>({ id, children, className, }: BoardCardProps<T>) => import("react/jsx-runtime").JSX.Element;
};
