export declare const activeCardIdState: import("jotai/vanilla/utils/atomFamily").AtomFamily<unknown, import("jotai").PrimitiveAtom<string | null> & {
    init: string | null;
}>;
export declare const dragOverBoardColumnIdState: import("jotai/vanilla/utils/atomFamily").AtomFamily<unknown, import("jotai").PrimitiveAtom<string | null> & {
    init: string | null;
}>;
