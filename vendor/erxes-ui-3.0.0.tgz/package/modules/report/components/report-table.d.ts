import * as React from 'react';
declare function ReportTableRoot({ className, ...props }: React.ComponentProps<'table'>): import("react/jsx-runtime").JSX.Element;
declare function ReportTableHeader({ className, ...props }: React.ComponentProps<'thead'>): import("react/jsx-runtime").JSX.Element;
declare function ReportTableBody({ className, ...props }: React.ComponentProps<'tbody'>): import("react/jsx-runtime").JSX.Element;
declare function ReportTableFooter({ className, ...props }: React.ComponentProps<'tfoot'>): import("react/jsx-runtime").JSX.Element;
declare function ReportTableRow({ className, ...props }: React.ComponentProps<'tr'>): import("react/jsx-runtime").JSX.Element;
declare function ReportTableHead({ className, ...props }: React.ComponentProps<'th'>): import("react/jsx-runtime").JSX.Element;
declare function ReportTableCell({ className, ...props }: React.ComponentProps<'td'>): import("react/jsx-runtime").JSX.Element;
declare function ReportTableCaption({ className, ...props }: React.ComponentProps<'caption'>): import("react/jsx-runtime").JSX.Element;
export declare const ReportTable: typeof ReportTableRoot & {
    Header: typeof ReportTableHeader;
    Body: typeof ReportTableBody;
    Footer: typeof ReportTableFooter;
    Head: typeof ReportTableHead;
    Row: typeof ReportTableRow;
    Cell: typeof ReportTableCell;
    Caption: typeof ReportTableCaption;
};
export {};
