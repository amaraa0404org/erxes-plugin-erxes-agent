export declare const ReportPageContainer: ({ children, }: {
    children: React.ReactNode;
}) => import("react/jsx-runtime").JSX.Element;
export declare const ReportStyle: () => import("react/jsx-runtime").JSX.Element;
