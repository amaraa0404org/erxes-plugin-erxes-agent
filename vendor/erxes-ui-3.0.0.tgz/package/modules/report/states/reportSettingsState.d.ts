export declare const printSettingsAtom: import("jotai").WritableAtom<{
    showTableLayoutOnEveryPage: boolean;
    printsize: number;
}, [typeof import("jotai/utils").RESET | {
    showTableLayoutOnEveryPage: boolean;
    printsize: number;
} | ((prev: {
    showTableLayoutOnEveryPage: boolean;
    printsize: number;
}) => typeof import("jotai/utils").RESET | {
    showTableLayoutOnEveryPage: boolean;
    printsize: number;
})], void>;
