import { ISelectTreeContext } from 'erxes-ui/modules/select-tree/types/selectTreeTypes';
export declare const SelectTreeContext: import("react").Context<ISelectTreeContext | null>;
export declare const useSelectTreeContext: () => ISelectTreeContext;
