export interface ISelectTreeContext {
    id: string;
    ordered?: boolean;
}
export interface ISelectTreeItem {
    _id: string;
    name: string;
    order: string;
    hasChildren: boolean;
    selected?: boolean;
}
