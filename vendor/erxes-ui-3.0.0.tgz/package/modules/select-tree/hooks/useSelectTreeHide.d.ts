export declare function useSelectTreeHide(order?: string): {
    readonly hideChildren: string[];
    readonly toggleHideChildren: (order: string) => void;
    readonly isHidden: boolean;
    readonly isHiddenByParent: boolean;
};
