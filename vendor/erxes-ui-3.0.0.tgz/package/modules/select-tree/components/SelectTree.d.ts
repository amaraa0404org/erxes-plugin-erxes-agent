import React from 'react';
import { ButtonProps } from 'erxes-ui/components';
import { ISelectTreeItem } from '../types/selectTreeTypes';
export declare const SelectTreeRoot: ({ id, children, open, onOpenChange, length, }: {
    id: string;
    children: React.ReactNode;
    open?: boolean;
    onOpenChange?: (open: boolean) => void;
    length?: number;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectTreeProvider: ({ id, children, length, ordered, }: {
    id: string;
    children: React.ReactNode;
    length?: number;
    ordered?: boolean;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectTreeArrow: React.ForwardRefExoticComponent<ButtonProps & {
    order: string;
    hasChildren: boolean;
} & React.RefAttributes<HTMLButtonElement>>;
export declare const SelectTreeIndentation: ({ order }: {
    order: string;
}) => import("react/jsx-runtime").JSX.Element | null;
export declare const SelectTreeCommandItem: React.ForwardRefExoticComponent<Omit<Omit<{
    children?: React.ReactNode;
} & Omit<Pick<Pick<React.DetailedHTMLProps<React.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "key" | keyof React.HTMLAttributes<HTMLDivElement>> & {
    ref?: React.Ref<HTMLDivElement>;
} & {
    asChild?: boolean;
}, "key" | keyof React.HTMLAttributes<HTMLDivElement> | "asChild">, "onSelect" | "disabled" | "value"> & {
    disabled?: boolean;
    onSelect?: (value: string) => void;
    value?: string;
    keywords?: string[];
    forceMount?: boolean;
} & React.RefAttributes<HTMLDivElement>, "ref"> & React.RefAttributes<HTMLDivElement>, "ref"> & ISelectTreeItem & React.RefAttributes<HTMLDivElement>>;
export declare const SelectTree: (({ id, children, open, onOpenChange, length, }: {
    id: string;
    children: React.ReactNode;
    open?: boolean;
    onOpenChange?: (open: boolean) => void;
    length?: number;
}) => import("react/jsx-runtime").JSX.Element) & {
    Item: React.ForwardRefExoticComponent<Omit<Omit<{
        children?: React.ReactNode;
    } & Omit<Pick<Pick<React.DetailedHTMLProps<React.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "key" | keyof React.HTMLAttributes<HTMLDivElement>> & {
        ref?: React.Ref<HTMLDivElement>;
    } & {
        asChild?: boolean;
    }, "key" | keyof React.HTMLAttributes<HTMLDivElement> | "asChild">, "onSelect" | "disabled" | "value"> & {
        disabled?: boolean;
        onSelect?: (value: string) => void;
        value?: string;
        keywords?: string[];
        forceMount?: boolean;
    } & React.RefAttributes<HTMLDivElement>, "ref"> & React.RefAttributes<HTMLDivElement>, "ref"> & ISelectTreeItem & React.RefAttributes<HTMLDivElement>>;
    Provider: ({ id, children, length, ordered, }: {
        id: string;
        children: React.ReactNode;
        length?: number;
        ordered?: boolean;
    }) => import("react/jsx-runtime").JSX.Element;
};
