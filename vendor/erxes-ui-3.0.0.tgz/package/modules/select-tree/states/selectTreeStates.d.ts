export declare const hideChildrenAtomFamily: import("jotai/vanilla/utils/atomFamily").AtomFamily<string, import("jotai").PrimitiveAtom<string[]> & {
    init: string[];
}>;
