type IconsProviderProps = {
    children: JSX.Element;
};
export declare const IconsProvider: ({ children }: IconsProviderProps) => JSX.Element;
export {};
