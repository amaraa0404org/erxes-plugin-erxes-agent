export declare const IconPicker: import("react").ForwardRefExoticComponent<Omit<Omit<import("erxes-ui/components").ButtonProps & import("react").RefAttributes<HTMLButtonElement>, "ref"> & {
    hideChevron?: boolean;
} & import("react").RefAttributes<HTMLButtonElement> & {
    value?: string;
    onValueChange?: (value: string | null) => void;
}, "ref"> & import("react").RefAttributes<HTMLButtonElement>>;
