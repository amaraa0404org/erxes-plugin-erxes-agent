import React from 'react';
import { TablerIcon } from '@tabler/icons-react';
export declare const IconComponent: React.ForwardRefExoticComponent<Omit<Omit<import("@tabler/icons-react").IconProps, "ref"> & React.RefAttributes<import("@tabler/icons-react").Icon>, "ref"> & {
    name?: string;
} & React.RefAttributes<TablerIcon>>;
