export declare const useIcons: () => {
    getIcons: () => Record<string, import("@tabler/icons-react").TablerIcon>;
    getIcon: (iconKey?: string | null) => import("react").ForwardRefExoticComponent<import("@tabler/icons-react").IconProps & import("react").RefAttributes<import("@tabler/icons-react").Icon>>;
};
