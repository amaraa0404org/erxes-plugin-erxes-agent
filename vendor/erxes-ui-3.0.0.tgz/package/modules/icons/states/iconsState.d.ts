import { TablerIcon } from '@tabler/icons-react';
export declare const iconsState: import("jotai").PrimitiveAtom<Record<string, TablerIcon>> & {
    init: Record<string, TablerIcon>;
};
