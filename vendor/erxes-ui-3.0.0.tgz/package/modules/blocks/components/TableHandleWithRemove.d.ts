import { TableHandleProps } from '@blocknote/react';
export declare const TableHandleWithRemove: (props: TableHandleProps) => import("react/jsx-runtime").JSX.Element;
