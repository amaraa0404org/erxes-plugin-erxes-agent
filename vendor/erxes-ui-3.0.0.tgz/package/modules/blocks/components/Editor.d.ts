import { BlockEditorProps, IEditorProps } from '../types';
export declare const Editor: ({ onChange, initialContent, scope, className, isHTML, uploadFile, ...props }: Omit<BlockEditorProps, "editor" | "onChange"> & IEditorProps) => import("react/jsx-runtime").JSX.Element;
