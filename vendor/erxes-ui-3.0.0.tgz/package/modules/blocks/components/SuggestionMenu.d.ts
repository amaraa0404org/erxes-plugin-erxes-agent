import React from 'react';
export declare const SuggestionMenu: React.ForwardRefExoticComponent<React.HTMLAttributes<HTMLDivElement> & {
    children: React.ReactNode;
} & React.RefAttributes<HTMLDivElement>>;
export declare const SuggestionMenuItem: React.ForwardRefExoticComponent<React.HTMLAttributes<HTMLDivElement> & {
    isSelected: boolean;
} & React.RefAttributes<HTMLDivElement>>;
