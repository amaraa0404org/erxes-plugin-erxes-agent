import { BlockEditorProps } from '../types';
export declare const BlockEditor: ({ editor, onFocus, onBlur, onPaste, onChange, readonly, children, className, style, disabled, variant, sideMenu, linkToolbar, slashMenuOnTop, additionalSlashMenuItems, }: BlockEditorProps) => import("react/jsx-runtime").JSX.Element;
export declare const Mention: {
    config: {
        type: string;
        propSchema: {
            fullName: {
                default: string;
            };
            _id: {
                default: string;
            };
        };
        content: "none";
    };
    implementation: {
        node: import("@tiptap/core").Node;
    };
};
export declare const Attribute: {
    config: {
        type: string;
        propSchema: {
            name: {
                default: string;
            };
            value: {
                default: string;
            };
            width: {
                default: number;
            };
            height: {
                default: number;
            };
        };
        content: "none";
    };
    implementation: {
        node: import("@tiptap/core").Node;
    };
};
