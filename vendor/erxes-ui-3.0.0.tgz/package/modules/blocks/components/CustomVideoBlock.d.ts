import { DefaultInlineContentSchema, DefaultStyleSchema, videoBlockConfig } from '@blocknote/core';
import { ReactCustomBlockRenderProps } from '@blocknote/react';
import { FC } from 'react';
type VideoRenderProps = ReactCustomBlockRenderProps<typeof videoBlockConfig, DefaultInlineContentSchema, DefaultStyleSchema>;
export declare const CustomVideoBlockContent: FC<VideoRenderProps>;
export declare const customVideoBlock: {
    config: {
        type: "video";
        propSchema: {
            textAlignment: {
                default: "left";
                values: readonly ["left", "center", "right", "justify"];
            };
            backgroundColor: {
                default: "default";
            };
            name: {
                default: "";
            };
            url: {
                default: "";
            };
            caption: {
                default: "";
            };
            showPreview: {
                default: true;
            };
            previewWidth: {
                default: undefined;
                type: "number";
            };
        };
        content: "none";
        isFileBlock: true;
        fileBlockAccept: string[];
    };
    implementation: import("@blocknote/core").TiptapBlockImplementation<{
        type: "video";
        propSchema: {
            textAlignment: {
                default: "left";
                values: readonly ["left", "center", "right", "justify"];
            };
            backgroundColor: {
                default: "default";
            };
            name: {
                default: "";
            };
            url: {
                default: "";
            };
            caption: {
                default: "";
            };
            showPreview: {
                default: true;
            };
            previewWidth: {
                default: undefined;
                type: "number";
            };
        };
        content: "none";
        isFileBlock: true;
        fileBlockAccept: string[];
    }, any, import("@blocknote/core").InlineContentSchema, import("@blocknote/core").StyleSchema>;
};
export {};
