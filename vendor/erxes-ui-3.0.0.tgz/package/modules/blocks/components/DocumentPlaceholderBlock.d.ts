export declare const documentPlaceholderBlock: {
    config: {
        type: "documentPlaceholder";
        propSchema: {
            documentId: {
                default: string;
            };
            documentName: {
                default: string;
            };
            documentCode: {
                default: string;
            };
            documentPreview: {
                default: string;
            };
        };
        content: "none";
        isFileBlock: false;
    };
    implementation: import("@blocknote/core").TiptapBlockImplementation<{
        type: "documentPlaceholder";
        propSchema: {
            documentId: {
                default: string;
            };
            documentName: {
                default: string;
            };
            documentCode: {
                default: string;
            };
            documentPreview: {
                default: string;
            };
        };
        content: "none";
        isFileBlock: false;
    }, any, import("@blocknote/core").InlineContentSchema, import("@blocknote/core").StyleSchema>;
};
