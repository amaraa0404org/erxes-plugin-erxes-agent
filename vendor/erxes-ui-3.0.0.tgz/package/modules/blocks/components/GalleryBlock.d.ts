export interface GalleryImage {
    url: string;
    caption?: string;
}
export declare const galleryBlock: {
    config: {
        type: "gallery";
        propSchema: {
            images: {
                default: string;
            };
            columns: {
                default: string;
            };
        };
        content: "none";
    };
    implementation: import("@blocknote/core").TiptapBlockImplementation<{
        type: "gallery";
        propSchema: {
            images: {
                default: string;
            };
            columns: {
                default: string;
            };
        };
        content: "none";
    }, any, import("@blocknote/core").InlineContentSchema, import("@blocknote/core").StyleSchema>;
};
