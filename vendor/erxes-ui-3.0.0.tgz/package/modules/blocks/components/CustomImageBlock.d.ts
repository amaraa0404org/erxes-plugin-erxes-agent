declare const IMAGE_STYLES: readonly ["normal", "wide", "float-left", "float-right"];
export type ImageStyle = (typeof IMAGE_STYLES)[number];
export declare const IMAGE_STYLE_PRESETS: Record<ImageStyle, {
    previewWidth: number;
    maxWidth: number;
}>;
export declare const customImageBlock: {
    config: {
        propSchema: {
            imageStyle: {
                default: "normal";
                values: readonly ["normal", "wide", "float-left", "float-right"];
            };
            textAlignment: {
                default: "left";
                values: readonly ["left", "center", "right", "justify"];
            };
            backgroundColor: {
                default: "default";
            };
            name: {
                default: "";
            };
            url: {
                default: "";
            };
            caption: {
                default: "";
            };
            showPreview: {
                default: true;
            };
            previewWidth: {
                default: undefined;
                type: "number";
            };
        };
        type: "image";
        content: "none";
        isFileBlock: true;
        fileBlockAccept: string[];
    };
    implementation: import("@blocknote/core").TiptapBlockImplementation<{
        propSchema: {
            imageStyle: {
                default: "normal";
                values: readonly ["normal", "wide", "float-left", "float-right"];
            };
            textAlignment: {
                default: "left";
                values: readonly ["left", "center", "right", "justify"];
            };
            backgroundColor: {
                default: "default";
            };
            name: {
                default: "";
            };
            url: {
                default: "";
            };
            caption: {
                default: "";
            };
            showPreview: {
                default: true;
            };
            previewWidth: {
                default: undefined;
                type: "number";
            };
        };
        type: "image";
        content: "none";
        isFileBlock: true;
        fileBlockAccept: string[];
    }, any, import("@blocknote/core").InlineContentSchema, import("@blocknote/core").StyleSchema>;
};
export {};
