type BarcodeSize = Readonly<{
    width: number;
    height: number;
}>;
type BarcodeAttributeProps = Readonly<{
    editable: boolean;
    height: number;
    onResize: (size: BarcodeSize) => void;
    width: number;
}>;
export declare const BarcodeAttribute: ({ editable, height, onResize, width, }: BarcodeAttributeProps) => import("react/jsx-runtime").JSX.Element;
export {};
