export declare const ImageStyleButton: () => import("react/jsx-runtime").JSX.Element | null;
