import { DefaultReactSuggestionItem, SuggestionMenuProps } from '@blocknote/react';
export declare const SlashMenu: ({ items, selectedIndex, loadingState, onItemClick, }: SuggestionMenuProps<DefaultReactSuggestionItem>) => import("react/jsx-runtime").JSX.Element;
