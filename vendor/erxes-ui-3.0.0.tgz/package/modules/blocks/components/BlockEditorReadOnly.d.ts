import React from 'react';
export declare const BlockEditorReadOnly: React.ForwardRefExoticComponent<{
    content: string;
    className?: string;
} & React.RefAttributes<HTMLDivElement>>;
