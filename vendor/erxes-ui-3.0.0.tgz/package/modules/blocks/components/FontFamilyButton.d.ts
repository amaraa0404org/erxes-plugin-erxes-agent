export declare const FontFamilyButton: () => import("react/jsx-runtime").JSX.Element | null;
