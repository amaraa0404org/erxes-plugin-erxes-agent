import { BlockNoteSchema } from '@blocknote/core';
export declare const fontFamily: import("@blocknote/core").StyleSpec<{
    type: string;
    propSchema: "string";
}>;
export declare const BLOCK_SCHEMA: BlockNoteSchema<import("@blocknote/core").BlockSchemaFromSpecs<{
    image: {
        config: {
            propSchema: {
                imageStyle: {
                    default: "normal";
                    values: readonly ["normal", "wide", "float-left", "float-right"];
                };
                textAlignment: {
                    default: "left";
                    values: readonly ["left", "center", "right", "justify"];
                };
                backgroundColor: {
                    default: "default";
                };
                name: {
                    default: "";
                };
                url: {
                    default: "";
                };
                caption: {
                    default: "";
                };
                showPreview: {
                    default: true;
                };
                previewWidth: {
                    default: undefined;
                    type: "number";
                };
            };
            type: "image";
            content: "none";
            isFileBlock: true;
            fileBlockAccept: string[];
        };
        implementation: import("@blocknote/core").TiptapBlockImplementation<{
            propSchema: {
                imageStyle: {
                    default: "normal";
                    values: readonly ["normal", "wide", "float-left", "float-right"];
                };
                textAlignment: {
                    default: "left";
                    values: readonly ["left", "center", "right", "justify"];
                };
                backgroundColor: {
                    default: "default";
                };
                name: {
                    default: "";
                };
                url: {
                    default: "";
                };
                caption: {
                    default: "";
                };
                showPreview: {
                    default: true;
                };
                previewWidth: {
                    default: undefined;
                    type: "number";
                };
            };
            type: "image";
            content: "none";
            isFileBlock: true;
            fileBlockAccept: string[];
        }, any, import("@blocknote/core").InlineContentSchema, import("@blocknote/core").StyleSchema>;
    };
    video: {
        config: {
            type: "video";
            propSchema: {
                textAlignment: {
                    default: "left";
                    values: readonly ["left", "center", "right", "justify"];
                };
                backgroundColor: {
                    default: "default";
                };
                name: {
                    default: "";
                };
                url: {
                    default: "";
                };
                caption: {
                    default: "";
                };
                showPreview: {
                    default: true;
                };
                previewWidth: {
                    default: undefined;
                    type: "number";
                };
            };
            content: "none";
            isFileBlock: true;
            fileBlockAccept: string[];
        };
        implementation: import("@blocknote/core").TiptapBlockImplementation<{
            type: "video";
            propSchema: {
                textAlignment: {
                    default: "left";
                    values: readonly ["left", "center", "right", "justify"];
                };
                backgroundColor: {
                    default: "default";
                };
                name: {
                    default: "";
                };
                url: {
                    default: "";
                };
                caption: {
                    default: "";
                };
                showPreview: {
                    default: true;
                };
                previewWidth: {
                    default: undefined;
                    type: "number";
                };
            };
            content: "none";
            isFileBlock: true;
            fileBlockAccept: string[];
        }, any, import("@blocknote/core").InlineContentSchema, import("@blocknote/core").StyleSchema>;
    };
    file: {
        config: {
            type: "file";
            propSchema: {
                backgroundColor: {
                    default: "default";
                };
                name: {
                    default: "";
                };
                url: {
                    default: "";
                };
                caption: {
                    default: "";
                };
            };
            content: "none";
            isFileBlock: true;
        };
        implementation: import("@blocknote/core").TiptapBlockImplementation<{
            type: "file";
            propSchema: {
                backgroundColor: {
                    default: "default";
                };
                name: {
                    default: "";
                };
                url: {
                    default: "";
                };
                caption: {
                    default: "";
                };
            };
            content: "none";
            isFileBlock: true;
        }, any, import("@blocknote/core").InlineContentSchema, import("@blocknote/core").StyleSchema>;
    };
    gallery: {
        config: {
            type: "gallery";
            propSchema: {
                images: {
                    default: string;
                };
                columns: {
                    default: string;
                };
            };
            content: "none";
        };
        implementation: import("@blocknote/core").TiptapBlockImplementation<{
            type: "gallery";
            propSchema: {
                images: {
                    default: string;
                };
                columns: {
                    default: string;
                };
            };
            content: "none";
        }, any, import("@blocknote/core").InlineContentSchema, import("@blocknote/core").StyleSchema>;
    };
    documentPlaceholder: {
        config: {
            type: "documentPlaceholder";
            propSchema: {
                documentId: {
                    default: string;
                };
                documentName: {
                    default: string;
                };
                documentCode: {
                    default: string;
                };
                documentPreview: {
                    default: string;
                };
            };
            content: "none";
            isFileBlock: false;
        };
        implementation: import("@blocknote/core").TiptapBlockImplementation<{
            type: "documentPlaceholder";
            propSchema: {
                documentId: {
                    default: string;
                };
                documentName: {
                    default: string;
                };
                documentCode: {
                    default: string;
                };
                documentPreview: {
                    default: string;
                };
            };
            content: "none";
            isFileBlock: false;
        }, any, import("@blocknote/core").InlineContentSchema, import("@blocknote/core").StyleSchema>;
    };
    paragraph: {
        config: {
            type: "paragraph";
            content: "inline";
            propSchema: {
                backgroundColor: {
                    default: "default";
                };
                textColor: {
                    default: "default";
                };
                textAlignment: {
                    default: "left";
                    values: readonly ["left", "center", "right", "justify"];
                };
            };
        };
        implementation: import("@blocknote/core").TiptapBlockImplementation<{
            type: "paragraph";
            content: "inline";
            propSchema: {
                backgroundColor: {
                    default: "default";
                };
                textColor: {
                    default: "default";
                };
                textAlignment: {
                    default: "left";
                    values: readonly ["left", "center", "right", "justify"];
                };
            };
        }, any, import("@blocknote/core").InlineContentSchema, import("@blocknote/core").StyleSchema>;
    };
    heading: {
        config: {
            type: "heading";
            content: "inline";
            propSchema: {
                level: {
                    default: number;
                    values: readonly [1, 2, 3, 4, 5, 6];
                };
                isToggleable: {
                    default: false;
                };
                backgroundColor: {
                    default: "default";
                };
                textColor: {
                    default: "default";
                };
                textAlignment: {
                    default: "left";
                    values: readonly ["left", "center", "right", "justify"];
                };
            };
        };
        implementation: import("@blocknote/core").TiptapBlockImplementation<{
            type: "heading";
            content: "inline";
            propSchema: {
                level: {
                    default: number;
                    values: readonly [1, 2, 3, 4, 5, 6];
                };
                isToggleable: {
                    default: false;
                };
                backgroundColor: {
                    default: "default";
                };
                textColor: {
                    default: "default";
                };
                textAlignment: {
                    default: "left";
                    values: readonly ["left", "center", "right", "justify"];
                };
            };
        }, any, import("@blocknote/core").InlineContentSchema, import("@blocknote/core").StyleSchema>;
    };
    quote: {
        config: {
            type: "quote";
            content: "inline";
            propSchema: {
                backgroundColor: {
                    default: "default";
                };
                textColor: {
                    default: "default";
                };
                textAlignment: {
                    default: "left";
                    values: readonly ["left", "center", "right", "justify"];
                };
            };
        };
        implementation: import("@blocknote/core").TiptapBlockImplementation<{
            type: "quote";
            content: "inline";
            propSchema: {
                backgroundColor: {
                    default: "default";
                };
                textColor: {
                    default: "default";
                };
                textAlignment: {
                    default: "left";
                    values: readonly ["left", "center", "right", "justify"];
                };
            };
        }, any, import("@blocknote/core").InlineContentSchema, import("@blocknote/core").StyleSchema>;
    };
    codeBlock: {
        config: {
            type: "codeBlock";
            content: "inline";
            propSchema: {
                language: {
                    default: string;
                };
            };
        };
        implementation: import("@blocknote/core").TiptapBlockImplementation<{
            type: "codeBlock";
            content: "inline";
            propSchema: {
                language: {
                    default: string;
                };
            };
        }, any, import("@blocknote/core").InlineContentSchema, import("@blocknote/core").StyleSchema>;
    };
    toggleListItem: {
        config: {
            type: "toggleListItem";
            content: "inline";
            propSchema: {
                backgroundColor: {
                    default: "default";
                };
                textColor: {
                    default: "default";
                };
                textAlignment: {
                    default: "left";
                    values: readonly ["left", "center", "right", "justify"];
                };
            };
        };
        implementation: import("@blocknote/core").TiptapBlockImplementation<{
            type: "toggleListItem";
            content: "inline";
            propSchema: {
                backgroundColor: {
                    default: "default";
                };
                textColor: {
                    default: "default";
                };
                textAlignment: {
                    default: "left";
                    values: readonly ["left", "center", "right", "justify"];
                };
            };
        }, any, import("@blocknote/core").InlineContentSchema, import("@blocknote/core").StyleSchema>;
    };
    bulletListItem: {
        config: {
            type: "bulletListItem";
            content: "inline";
            propSchema: {
                backgroundColor: {
                    default: "default";
                };
                textColor: {
                    default: "default";
                };
                textAlignment: {
                    default: "left";
                    values: readonly ["left", "center", "right", "justify"];
                };
            };
        };
        implementation: import("@blocknote/core").TiptapBlockImplementation<{
            type: "bulletListItem";
            content: "inline";
            propSchema: {
                backgroundColor: {
                    default: "default";
                };
                textColor: {
                    default: "default";
                };
                textAlignment: {
                    default: "left";
                    values: readonly ["left", "center", "right", "justify"];
                };
            };
        }, any, import("@blocknote/core").InlineContentSchema, import("@blocknote/core").StyleSchema>;
    };
    numberedListItem: {
        config: {
            type: "numberedListItem";
            content: "inline";
            propSchema: {
                start: {
                    default: undefined;
                    type: "number";
                };
                backgroundColor: {
                    default: "default";
                };
                textColor: {
                    default: "default";
                };
                textAlignment: {
                    default: "left";
                    values: readonly ["left", "center", "right", "justify"];
                };
            };
        };
        implementation: import("@blocknote/core").TiptapBlockImplementation<{
            type: "numberedListItem";
            content: "inline";
            propSchema: {
                start: {
                    default: undefined;
                    type: "number";
                };
                backgroundColor: {
                    default: "default";
                };
                textColor: {
                    default: "default";
                };
                textAlignment: {
                    default: "left";
                    values: readonly ["left", "center", "right", "justify"];
                };
            };
        }, any, import("@blocknote/core").InlineContentSchema, import("@blocknote/core").StyleSchema>;
    };
    checkListItem: {
        config: {
            type: "checkListItem";
            content: "inline";
            propSchema: {
                checked: {
                    default: false;
                };
                backgroundColor: {
                    default: "default";
                };
                textColor: {
                    default: "default";
                };
                textAlignment: {
                    default: "left";
                    values: readonly ["left", "center", "right", "justify"];
                };
            };
        };
        implementation: import("@blocknote/core").TiptapBlockImplementation<{
            type: "checkListItem";
            content: "inline";
            propSchema: {
                checked: {
                    default: false;
                };
                backgroundColor: {
                    default: "default";
                };
                textColor: {
                    default: "default";
                };
                textAlignment: {
                    default: "left";
                    values: readonly ["left", "center", "right", "justify"];
                };
            };
        }, any, import("@blocknote/core").InlineContentSchema, import("@blocknote/core").StyleSchema>;
    };
    table: {
        config: {
            type: "table";
            content: "table";
            propSchema: {
                textColor: {
                    default: "default";
                };
            };
        };
        implementation: import("@blocknote/core").TiptapBlockImplementation<{
            type: "table";
            content: "table";
            propSchema: {
                textColor: {
                    default: "default";
                };
            };
        }, any, import("@blocknote/core").InlineContentSchema, import("@blocknote/core").StyleSchema>;
    };
    audio: {
        config: {
            type: "audio";
            propSchema: {
                backgroundColor: {
                    default: "default";
                };
                name: {
                    default: "";
                };
                url: {
                    default: "";
                };
                caption: {
                    default: "";
                };
                showPreview: {
                    default: true;
                };
            };
            content: "none";
            isFileBlock: true;
            fileBlockAccept: string[];
        };
        implementation: import("@blocknote/core").TiptapBlockImplementation<{
            type: "audio";
            propSchema: {
                backgroundColor: {
                    default: "default";
                };
                name: {
                    default: "";
                };
                url: {
                    default: "";
                };
                caption: {
                    default: "";
                };
                showPreview: {
                    default: true;
                };
            };
            content: "none";
            isFileBlock: true;
            fileBlockAccept: string[];
        }, any, import("@blocknote/core").InlineContentSchema, import("@blocknote/core").StyleSchema>;
    };
}>, import("@blocknote/core").InlineContentSchemaFromSpecs<{
    mention: {
        config: {
            type: string;
            propSchema: {
                fullName: {
                    default: string;
                };
                _id: {
                    default: string;
                };
            };
            content: "none";
        };
        implementation: {
            node: import("@tiptap/core").Node;
        };
    };
    attribute: {
        config: {
            type: string;
            propSchema: {
                name: {
                    default: string;
                };
                value: {
                    default: string;
                };
                width: {
                    default: number;
                };
                height: {
                    default: number;
                };
            };
            content: "none";
        };
        implementation: {
            node: import("@tiptap/core").Node;
        };
    };
    text: {
        config: "text";
        implementation: any;
    };
    link: {
        config: "link";
        implementation: any;
    };
}>, import("@blocknote/core").StyleSchemaFromSpecs<{
    fontFamily: import("@blocknote/core").StyleSpec<{
        type: string;
        propSchema: "string";
    }>;
    bold: {
        config: {
            type: string;
            propSchema: "boolean";
        };
        implementation: import("@blocknote/core").StyleImplementation;
    };
    italic: {
        config: {
            type: string;
            propSchema: "boolean";
        };
        implementation: import("@blocknote/core").StyleImplementation;
    };
    underline: {
        config: {
            type: string;
            propSchema: "boolean";
        };
        implementation: import("@blocknote/core").StyleImplementation;
    };
    strike: {
        config: {
            type: string;
            propSchema: "boolean";
        };
        implementation: import("@blocknote/core").StyleImplementation;
    };
    code: {
        config: {
            type: string;
            propSchema: "boolean";
        };
        implementation: import("@blocknote/core").StyleImplementation;
    };
    textColor: {
        config: {
            type: string;
            propSchema: "string";
        };
        implementation: import("@blocknote/core").StyleImplementation;
    };
    backgroundColor: {
        config: {
            type: string;
            propSchema: "string";
        };
        implementation: import("@blocknote/core").StyleImplementation;
    };
}>>;
export declare const TABLE_SCHEMA: {
    splitCells: boolean;
    cellBackgroundColor: boolean;
    cellTextColor: boolean;
    headers: boolean;
};
