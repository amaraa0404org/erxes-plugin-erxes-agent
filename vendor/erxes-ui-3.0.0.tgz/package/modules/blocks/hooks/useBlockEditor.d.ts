import { Block } from '@blocknote/core';
import type { IBlockEditor } from '../types';
export declare const useBlockEditor: (args?: {
    initialContent?: Block[];
    placeholder?: string;
    uploadFile?: (file: File) => Promise<string>;
}) => IBlockEditor;
