type BlockLike = {
    type: string;
    props?: Record<string, any>;
};
export type BlockAttachment = {
    url: string;
    name: string;
    type: string;
    size: number;
};
export declare const getBlockAttachments: (blocks: BlockLike[]) => BlockAttachment[];
export {};
