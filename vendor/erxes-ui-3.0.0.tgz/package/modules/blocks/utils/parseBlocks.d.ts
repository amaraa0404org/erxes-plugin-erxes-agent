import { Block } from '@blocknote/core';
export declare const parseBlocks: (content: unknown) => false | Block[];
