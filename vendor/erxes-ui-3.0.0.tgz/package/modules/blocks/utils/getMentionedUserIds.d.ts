import type { Block } from '@blocknote/core';
export declare const getMentionedUserIds: (content: readonly Block[] | undefined) => string[];
