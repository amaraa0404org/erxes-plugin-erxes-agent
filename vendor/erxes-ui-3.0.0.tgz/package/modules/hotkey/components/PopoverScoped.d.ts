import { type PopoverProps } from 'erxes-ui/components';
import { UseHotkeysOptionsWithoutBuggyOptions } from 'erxes-ui/modules/hotkey/hooks/useScopedHotkeys';
export declare const PopoverScoped: ({ scope, onOpenChange, onEnter, closeOnEnter, dependencies, options, open, ...props }: Omit<PopoverProps, "onOpenChange"> & {
    onOpenChange?: (open: boolean, reason?: "enter" | "close") => void;
    scope?: string;
    onEnter?: () => void;
    closeOnEnter?: boolean;
    dependencies?: unknown[];
    options?: UseHotkeysOptionsWithoutBuggyOptions;
}) => import("react/jsx-runtime").JSX.Element;
