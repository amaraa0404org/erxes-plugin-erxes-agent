import { CustomHotkeyScopes } from '../types/CustomHotkeyScope';
export declare const DEFAULT_HOTKEYS_SCOPE_CUSTOM_SCOPES: CustomHotkeyScopes;
