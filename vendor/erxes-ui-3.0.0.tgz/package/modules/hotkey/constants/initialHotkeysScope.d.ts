import { HotkeyScope } from '../types/HotkeyScope';
export declare const INITIAL_HOTKEYS_SCOPE: HotkeyScope;
