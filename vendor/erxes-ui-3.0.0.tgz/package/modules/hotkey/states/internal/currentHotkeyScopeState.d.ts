import { HotkeyScope } from '../../types/HotkeyScope';
export declare const currentHotkeyScopeState: import("jotai").PrimitiveAtom<HotkeyScope> & {
    init: HotkeyScope;
};
