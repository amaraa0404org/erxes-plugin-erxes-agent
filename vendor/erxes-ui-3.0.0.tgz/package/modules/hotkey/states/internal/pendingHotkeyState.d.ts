import { Keys } from 'react-hotkeys-hook/dist/types';
export declare const pendingHotkeyState: import("jotai").PrimitiveAtom<Keys | null> & {
    init: Keys | null;
};
