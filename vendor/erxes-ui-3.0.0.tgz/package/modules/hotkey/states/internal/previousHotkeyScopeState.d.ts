import { HotkeyScope } from '../../types/HotkeyScope';
export declare const previousHotkeyScopeState: import("jotai").PrimitiveAtom<HotkeyScope | null> & {
    init: HotkeyScope | null;
};
