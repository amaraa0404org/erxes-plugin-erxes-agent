export declare const internalHotkeysEnabledScopesState: import("jotai").PrimitiveAtom<string[]> & {
    init: string[];
};
