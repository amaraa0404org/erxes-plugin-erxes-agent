import { CustomHotkeyScopes } from '../types/CustomHotkeyScope';
export declare const setHotkeyScopeState: import("jotai").WritableAtom<null, [newScope: {
    scope: string;
    customScopes?: CustomHotkeyScopes;
}], void> & {
    init: null;
};
