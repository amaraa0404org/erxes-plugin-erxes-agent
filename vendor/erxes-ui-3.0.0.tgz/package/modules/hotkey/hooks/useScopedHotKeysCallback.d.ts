import { Hotkey, OptionsOrDependencyArray } from 'react-hotkeys-hook/dist/types';
export declare const DEBUG_HOTKEY_SCOPE = true;
export declare const useScopedHotKeysCallback: (dependencies?: OptionsOrDependencyArray) => (args_0: {
    keyboardEvent: KeyboardEvent;
    hotkeysEvent: Hotkey;
    callback: (keyboardEvent: KeyboardEvent, hotkeysEvent: Hotkey) => void;
    scope: string;
    preventDefault?: boolean;
}) => void;
