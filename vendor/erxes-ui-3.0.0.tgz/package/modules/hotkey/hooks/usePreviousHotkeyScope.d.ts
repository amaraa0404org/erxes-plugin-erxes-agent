import { CustomHotkeyScopes } from '../types/CustomHotkeyScope';
export declare const usePreviousHotkeyScope: () => {
    goBackToPreviousHotkeyScope: () => void;
    setHotkeyScopeAndMemorizePreviousScope: (scope: string, customScopes?: CustomHotkeyScopes | undefined) => void;
};
