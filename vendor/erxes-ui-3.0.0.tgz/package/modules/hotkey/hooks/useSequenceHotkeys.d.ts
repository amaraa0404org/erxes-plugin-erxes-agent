import { Keys, Options } from 'react-hotkeys-hook/dist/types';
export declare const useSequenceHotkeys: (firstKey: Keys, secondKey: Keys, sequenceCallback: () => void, scope: string, options?: Options, deps?: any[]) => {
    goBackToPreviousHotkeyScope: () => void;
};
