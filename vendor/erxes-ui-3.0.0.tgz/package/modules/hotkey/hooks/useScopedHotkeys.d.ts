import { HotkeyCallback, Keys, Options } from 'react-hotkeys-hook/dist/types';
export type UseHotkeysOptionsWithoutBuggyOptions = Omit<Options, 'enabled'>;
export declare const useScopedHotkeys: (keys: Keys, callback: HotkeyCallback, scope: string, dependencies?: unknown[], options?: UseHotkeysOptionsWithoutBuggyOptions) => (instance: import("react-hotkeys-hook/dist/types").RefType<HTMLElement>) => void;
