import { CustomHotkeyScopes } from '../types/CustomHotkeyScope';
export declare const useSetHotkeyScope: () => (hotkeyScopeToSet: string, customScopes?: CustomHotkeyScopes) => void;
