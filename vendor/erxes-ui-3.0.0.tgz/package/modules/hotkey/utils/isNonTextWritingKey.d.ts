export declare const isNonTextWritingKey: (key: string) => boolean;
