import { Icon as TablerIcon } from '@tabler/icons-react';
import { Sheet, Sidebar } from 'erxes-ui/components';
import React from 'react';
export declare const useFocusSheet: () => {
    isSidebarOpen: boolean;
    setIsSidebarOpen: (isSidebarOpen: boolean) => void;
    activeSideTab?: string | null;
    setActiveSideTab?: (activeSideTab: string | null) => void;
    hasSidebar?: boolean;
    setHasSidebar?: (hasSidebar: boolean) => void;
};
export declare const FocusSheet: (({ ...props }: React.ComponentProps<typeof Sheet>) => import("react/jsx-runtime").JSX.Element) & {
    Header: {
        ({ className, children, title, description, ...props }: React.ComponentProps<typeof Sheet.Header> & {
            title?: string;
            description?: string;
        }): import("react/jsx-runtime").JSX.Element;
        displayName: string;
    };
    View: ({ className, loading, error, notFound, children, errorState, notFoundState, ...props }: React.ComponentProps<typeof Sheet.View> & {
        loading?: boolean;
        error?: boolean;
        notFound?: boolean;
        children?: React.ReactNode;
        errorState?: React.ReactNode;
        notFoundState?: React.ReactNode;
    }) => import("react/jsx-runtime").JSX.Element;
    Content: ({ className, ...props }: React.ComponentProps<typeof Sheet.Content>) => import("react/jsx-runtime").JSX.Element;
    SideBar: {
        ({ className, ...props }: React.ComponentProps<typeof Sidebar>): import("react/jsx-runtime").JSX.Element | null;
        displayName: string;
    };
    SidebarTrigger: () => import("react/jsx-runtime").JSX.Element;
    SideTabs: React.ForwardRefExoticComponent<Omit<import("@radix-ui/react-tabs").TabsProps & React.RefAttributes<HTMLDivElement>, "ref"> & React.RefAttributes<HTMLDivElement>>;
    SideContent: React.ForwardRefExoticComponent<Omit<Omit<import("@radix-ui/react-tabs").TabsContentProps & React.RefAttributes<HTMLDivElement>, "ref"> & React.RefAttributes<HTMLDivElement>, "ref"> & React.RefAttributes<HTMLDivElement>>;
    SideContentHeader: React.ForwardRefExoticComponent<Omit<React.ClassAttributes<HTMLDivElement> & React.HTMLAttributes<HTMLDivElement> & {
        Icon?: TablerIcon;
        label?: string;
        hideSeparator?: boolean;
    }, "ref"> & React.RefAttributes<HTMLDivElement>>;
    SideTabsList: React.ForwardRefExoticComponent<Omit<Omit<import("@radix-ui/react-tabs").TabsListProps & React.RefAttributes<HTMLDivElement>, "ref"> & import("class-variance-authority").VariantProps<(props?: ({
        variant?: "underline" | "segment" | null | undefined;
    } & import("class-variance-authority/types").ClassProp) | undefined) => string> & React.RefAttributes<HTMLDivElement>, "ref"> & React.RefAttributes<HTMLDivElement>>;
    SideTabsTrigger: React.ForwardRefExoticComponent<Omit<Omit<import("@radix-ui/react-tabs").TabsTriggerProps & React.RefAttributes<HTMLButtonElement>, "ref"> & import("class-variance-authority").VariantProps<(props?: ({
        variant?: "underline" | "segment" | null | undefined;
    } & import("class-variance-authority/types").ClassProp) | undefined) => string> & React.RefAttributes<HTMLButtonElement>, "ref"> & {
        label?: string;
        Icon?: TablerIcon;
        value: string;
    } & React.RefAttributes<HTMLButtonElement>>;
};
