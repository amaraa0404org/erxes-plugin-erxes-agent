import React from 'react';
export declare const PreviewToolbar: ({ path }: {
    path?: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const View: React.ForwardRefExoticComponent<Omit<{
    iframeSrc: string;
} & Omit<Omit<React.HTMLAttributes<keyof HTMLElementTagNameMap>, "id"> & {
    autoSaveId?: string | null | undefined;
    className?: string | undefined;
    direction: import("react-resizable-panels/dist/declarations/src/types").Direction;
    id?: string | null | undefined;
    keyboardResizeBy?: number | null | undefined;
    onLayout?: import("react-resizable-panels").PanelGroupOnLayout | null | undefined;
    storage?: import("react-resizable-panels").PanelGroupStorage | undefined;
    style?: React.CSSProperties | undefined;
    tagName?: keyof HTMLElementTagNameMap | undefined;
    dir?: "auto" | "ltr" | "rtl" | undefined;
} & {
    children?: import("react").ReactNode;
} & React.RefAttributes<import("react-resizable-panels").ImperativePanelGroupHandle>, "direction">, "ref"> & React.RefAttributes<import("react-resizable-panels").ImperativePanelGroupHandle>>;
export declare const Preview: (({ children }: {
    children: React.ReactNode;
}) => import("react/jsx-runtime").JSX.Element) & {
    Toolbar: ({ path }: {
        path?: string;
    }) => import("react/jsx-runtime").JSX.Element;
    View: React.ForwardRefExoticComponent<Omit<{
        iframeSrc: string;
    } & Omit<Omit<React.HTMLAttributes<keyof HTMLElementTagNameMap>, "id"> & {
        autoSaveId?: string | null | undefined;
        className?: string | undefined;
        direction: import("react-resizable-panels/dist/declarations/src/types").Direction;
        id?: string | null | undefined;
        keyboardResizeBy?: number | null | undefined;
        onLayout?: import("react-resizable-panels").PanelGroupOnLayout | null | undefined;
        storage?: import("react-resizable-panels").PanelGroupStorage | undefined;
        style?: React.CSSProperties | undefined;
        tagName?: keyof HTMLElementTagNameMap | undefined;
        dir?: "auto" | "ltr" | "rtl" | undefined;
    } & {
        children?: import("react").ReactNode;
    } & React.RefAttributes<import("react-resizable-panels").ImperativePanelGroupHandle>, "direction">, "ref"> & React.RefAttributes<import("react-resizable-panels").ImperativePanelGroupHandle>>;
};
