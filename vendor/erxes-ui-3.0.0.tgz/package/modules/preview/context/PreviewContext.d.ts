import { ImperativePanelHandle } from 'react-resizable-panels';
export interface IPreviewContext {
    resizablePanelRef: React.RefObject<ImperativePanelHandle> | null;
}
export declare const PreviewContext: import("react").Context<IPreviewContext | null>;
export declare const usePreviewContext: () => IPreviewContext;
