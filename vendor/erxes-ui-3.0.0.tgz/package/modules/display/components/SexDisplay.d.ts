import { SexCode } from 'erxes-ui/types';
export declare const SexDisplay: ({ value, }: {
    value: SexCode;
}) => string;
