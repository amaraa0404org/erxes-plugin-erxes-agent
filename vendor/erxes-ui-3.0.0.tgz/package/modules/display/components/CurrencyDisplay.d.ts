import React from 'react';
import { FieldCurrencyValue } from 'erxes-ui/types/Displays';
import { CurrencyCode } from 'erxes-ui/types';
type CurrencyFormatedDisplayProps = {
    currencyValue?: FieldCurrencyValue | null;
    kind?: 'short' | 'finance';
};
export declare const CurrencyFormatedDisplay: ({ currencyValue, kind }: CurrencyFormatedDisplayProps) => import("react/jsx-runtime").JSX.Element;
export interface CurrencyDisplayProps extends React.HTMLAttributes<HTMLDivElement> {
    /** Currency code to display */
    code?: CurrencyCode;
    variant?: 'icon' | 'label' | 'code';
}
export declare const CurrencyDisplay: React.ForwardRefExoticComponent<CurrencyDisplayProps & React.RefAttributes<HTMLDivElement>>;
export {};
