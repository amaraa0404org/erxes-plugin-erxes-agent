import { IEmailFieldProps } from 'erxes-ui/modules/inputs';
export declare const EmailDisplay: ({ primaryEmail, emails, emailValidationStatus, }: IEmailFieldProps) => import("react/jsx-runtime").JSX.Element;
