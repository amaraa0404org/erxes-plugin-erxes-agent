import { IPhoneFieldProps } from 'erxes-ui/modules/inputs';
export declare const PhoneDisplay: ({ primaryPhone, phones, phoneValidationStatus, }: IPhoneFieldProps) => import("react/jsx-runtime").JSX.Element;
