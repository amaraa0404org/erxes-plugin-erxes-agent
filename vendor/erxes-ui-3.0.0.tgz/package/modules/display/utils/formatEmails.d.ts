import { TEmails } from 'erxes-ui/modules/inputs';
import { ValidationStatus } from 'erxes-ui/types';
export declare function formatEmails(primaryEmail: string, emails: string[], emailValidationStatus: ValidationStatus): TEmails;
