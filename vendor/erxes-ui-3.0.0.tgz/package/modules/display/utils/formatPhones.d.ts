import { TPhones } from 'erxes-ui/modules/inputs';
import { ValidationStatus } from 'erxes-ui/types';
export declare function formatPhones(primaryPhone: string, phones: string[], phoneValidationStatus?: ValidationStatus): TPhones;
