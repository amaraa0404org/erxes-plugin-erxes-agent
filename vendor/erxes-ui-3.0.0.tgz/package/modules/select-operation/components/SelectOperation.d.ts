export declare enum SelectTriggerVariant {
    TABLE = "table",
    CARD = "card",
    DETAIL = "detail",
    FORM = "form",
    FILTER = "filter",
    ICON = "icon",
    DEFAULT = "default"
}
export declare const SelectTriggerOperation: ({ children, variant, }: {
    children: React.ReactNode;
    variant: `${SelectTriggerVariant}`;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectOperationContent: ({ variant, children, }: {
    variant: `${SelectTriggerVariant}`;
    children: React.ReactNode;
}) => import("react/jsx-runtime").JSX.Element;
