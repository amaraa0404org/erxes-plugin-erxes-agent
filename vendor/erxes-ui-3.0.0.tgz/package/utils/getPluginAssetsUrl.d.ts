export declare const getPluginAssetsUrl: (pluginName: string, url: string) => string;
