export declare const isAnObject: (obj: any) => obj is object;
