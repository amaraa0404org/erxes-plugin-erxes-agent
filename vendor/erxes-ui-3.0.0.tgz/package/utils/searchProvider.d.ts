import { ISearchProvider, TSearchPageInfo, TSearchPayload, TSearchProviderDefinition } from '../types/UIConfig';
export declare const readCursorList: <TNode>(payload: TSearchPayload, alias: string) => {
    nodes: TNode[];
    totalCount: number;
    pageInfo: TSearchPageInfo;
};
export declare const readArray: <TNode>(payload: TSearchPayload, alias: string) => TNode[];
export declare const readNumber: (payload: TSearchPayload, alias: string) => number;
export declare const defineSearchProvider: <TNode>(definition: TSearchProviderDefinition<TNode>) => ISearchProvider;
