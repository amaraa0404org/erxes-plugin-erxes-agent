export declare const isEnabled: (pluginName: string) => boolean;
