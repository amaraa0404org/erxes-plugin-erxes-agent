export declare const formatAmount: (amount: number, kind?: "short" | "finance") => string;
