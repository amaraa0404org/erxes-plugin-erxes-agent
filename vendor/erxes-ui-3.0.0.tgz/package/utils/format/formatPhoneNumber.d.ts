import { CountryCode } from 'libphonenumber-js';
export declare const formatPhoneNumber: ({ defaultCountry, value, }: {
    defaultCountry?: CountryCode;
    value: string;
}) => string;
