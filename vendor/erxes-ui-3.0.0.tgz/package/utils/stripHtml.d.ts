export declare const stripHtml: (value?: string | null) => string;
export declare const getPersonName: (person: {
    firstName?: string | null;
    lastName?: string | null;
} | null, fallback: string) => string;
