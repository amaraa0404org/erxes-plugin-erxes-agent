export declare const fixOrder: ({ order, name, }: {
    order?: string;
    name?: string;
}) => string | undefined;
