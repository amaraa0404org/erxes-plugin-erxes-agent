export type VideoEmbedProvider = 'youtube' | 'vimeo';
export type VideoEmbedInfo = {
    provider: VideoEmbedProvider;
    embedUrl: string;
    thumbnailUrl?: string;
};
/** Parses a YouTube or Vimeo URL into an embeddable iframe URL (and thumbnail, when derivable without a network call). */
export declare const parseVideoEmbedUrl: (url: string) => VideoEmbedInfo | null;
/**
 * Cloudflare Stream returns an HLS playback URL like
 * `https://customer-xxx.cloudflarestream.com/{uid}/manifest/video.m3u8`.
 * Extract the base so we can build a thumbnail (`/thumbnails/thumbnail.jpg`).
 */
export declare const getCloudflareStreamBase: (url: string) => string | null;
