export declare const isUndefinedOrNull: (value: any) => value is null | undefined;
