export declare const isValidURL: (url: string) => boolean;
export declare const urlify: (text: string) => string;
declare const _default: {
    isValidURL: (url: string) => boolean;
    extractHostname: (url: string) => string;
    extractRootDomain: (url: string) => string;
};
export default _default;
