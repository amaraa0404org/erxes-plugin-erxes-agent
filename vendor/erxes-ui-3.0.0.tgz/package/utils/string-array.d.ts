import { type ClipboardEvent } from 'react';
export declare const handleStringArrayPaste: ({ event, value, onValueChange, }: {
    event: ClipboardEvent<HTMLInputElement>;
    value: string[];
    onValueChange: (value: string[]) => void;
}) => void;
