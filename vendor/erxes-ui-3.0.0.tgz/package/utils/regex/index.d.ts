export * from './passwordRegex';
