import Cookies from 'js-cookie';
declare class CookieStorage {
    private keys;
    getItem(key: string): string | undefined;
    setItem(key: string, value: string, attributes?: Cookies.CookieAttributes): void;
    removeItem(key: string): void;
    clear(): void;
}
export declare const cookieStorage: CookieStorage;
export {};
