export declare const isDeeplyEqual: <T>(a: T, b: T, options?: {
    strict: boolean;
}) => boolean;
