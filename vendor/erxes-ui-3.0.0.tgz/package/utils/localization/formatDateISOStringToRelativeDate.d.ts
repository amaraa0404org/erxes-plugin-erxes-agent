export declare const formatDateISOStringToRelativeDate: (isoDate: string, isDayMaximumPrecision?: boolean) => string;
export declare const formatDateISOStringToRelativeDateShort: (isoDate: string) => string;
