/**
 * Detects the user's time zone.
 * @returns a IANA time zone
 */
export declare const detectTimeZone: () => string;
