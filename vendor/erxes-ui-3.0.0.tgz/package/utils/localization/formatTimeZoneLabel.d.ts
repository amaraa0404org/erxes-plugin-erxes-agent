/**
 * Formats a IANA time zone to a select option label.
 * @param ianaTimeZone IANA time zone
 * @returns Formatted label
 * @example 'Europe/Paris' => '(GMT+01:00) Central European Time - Paris'
 */
export declare const formatTimeZoneLabel: (ianaTimeZone: string) => string;
