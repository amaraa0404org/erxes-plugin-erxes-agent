export declare const highlightMatch: (text: string, searchValue: string) => React.ReactNode;
