declare global {
    interface Window {
        env?: Record<string, string>;
        __APOLLO_CLIENT__?: any;
    }
}
declare const NODE_ENV: string;
declare const REACT_APP_API_URL: string;
declare const REACT_APP_IMAGE_CDN_URL: string | undefined;
declare const REACT_APP_GOOGLE_MAP_API_KEY: string | undefined;
declare const REACT_APP_HIDE_CORE_MODULES: string | undefined;
declare const REACT_APP_SENTRY_DSN: string | undefined;
declare const REACT_APP_SENTRY_ENVIRONMENT: string | undefined;
export { NODE_ENV, REACT_APP_API_URL, REACT_APP_IMAGE_CDN_URL, REACT_APP_GOOGLE_MAP_API_KEY, REACT_APP_HIDE_CORE_MODULES, REACT_APP_SENTRY_DSN, REACT_APP_SENTRY_ENVIRONMENT, };
