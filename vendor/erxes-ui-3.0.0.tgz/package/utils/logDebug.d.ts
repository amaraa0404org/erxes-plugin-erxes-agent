export declare const logDebug: (message: any, ...optionalParams: any[]) => void;
