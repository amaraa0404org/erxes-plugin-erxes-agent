export interface OKLCHColor {
    lightness: number;
    chroma: number;
    hue: number;
}
export declare const stringToHslColor: (str: string, saturation: number, lightness: number) => string;
export declare const hexToOklch: (hex: string, onlyValue?: boolean) => string;
