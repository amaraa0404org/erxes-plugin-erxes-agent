export declare const readImage: (value?: string, width?: number, inline?: boolean, format?: string, quality?: number) => string;
export declare const renderFullName: (data: any) => any;
