import { QueryHookOptions } from "@apollo/client";
import { IBoard } from "../types/boards";
export declare const useBoards: (options?: QueryHookOptions<{
    salesBoards: IBoard[];
}>) => {
    boards: IBoard[] | undefined;
    loading: boolean;
    error: import("@apollo/client").ApolloError | undefined;
};
export declare const useBoardDetail: (options?: QueryHookOptions<{
    salesBoardDetail: IBoard;
}>) => {
    boardDetail: IBoard | undefined;
    loading: boolean;
    error: import("@apollo/client").ApolloError | undefined;
};
