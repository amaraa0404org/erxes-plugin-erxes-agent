declare const GET_BOARDS: import("@apollo/client").DocumentNode;
declare const GET_BOARD_DETAIL: import("@apollo/client").DocumentNode;
export { GET_BOARDS, GET_BOARD_DETAIL, };
