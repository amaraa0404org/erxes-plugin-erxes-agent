declare const GET_PIPELINE_DETAIL: import("@apollo/client").DocumentNode;
declare const GET_PIPELINES: import("@apollo/client").DocumentNode;
export { GET_PIPELINE_DETAIL, GET_PIPELINES };
