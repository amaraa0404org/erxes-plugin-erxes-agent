import { ISelectBoardsContext, ISelectPipelinesContext, ISelectStagesContext } from '../types';
export declare const SelectBoardsContext: import("react").Context<ISelectBoardsContext | null>;
export declare const useSelectBoardsContext: () => ISelectBoardsContext;
export declare const SelectPipelinesContext: import("react").Context<ISelectPipelinesContext | null>;
export declare const useSelectPipelinesContext: () => ISelectPipelinesContext;
export declare const SelectStagesContext: import("react").Context<ISelectStagesContext | null>;
export declare const useSelectStagesContext: () => ISelectStagesContext;
