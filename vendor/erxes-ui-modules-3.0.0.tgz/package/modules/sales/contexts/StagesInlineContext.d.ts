import { IStage } from '../types';
export interface IStagesInlineContext {
    stages: IStage[];
    loading: boolean;
    stageIds?: string[];
    placeholder: string;
    updateStages?: (stages: IStage[]) => void;
}
export declare const StagesInlineContext: import("react").Context<IStagesInlineContext | null>;
export declare const useStagesInlineContext: () => IStagesInlineContext;
