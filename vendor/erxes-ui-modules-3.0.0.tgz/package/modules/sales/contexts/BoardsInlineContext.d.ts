import { IBoard } from '../types';
export interface IBoardsInlineContext {
    boards: IBoard[];
    loading: boolean;
    boardIds?: string[];
    placeholder: string;
    updateBoards?: (boards: IBoard[]) => void;
}
export declare const BoardsInlineContext: import("react").Context<IBoardsInlineContext | null>;
export declare const useBoardsInlineContext: () => IBoardsInlineContext;
