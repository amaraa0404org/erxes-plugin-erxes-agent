import { IPipeline } from '../types';
export interface IPipelinesInlineContext {
    pipelines: IPipeline[];
    loading: boolean;
    pipelineIds?: string[];
    placeholder: string;
    updatePipelines?: (pipelines: IPipeline[]) => void;
}
export declare const PipelinesInlineContext: import("react").Context<IPipelinesInlineContext | null>;
export declare const usePipelinesInlineContext: () => IPipelinesInlineContext;
