interface boardType {
    boardId: string;
}
interface pipelineType {
    pipelineId: string;
}
interface stageType {
    stageId: string;
}
export declare const dealBoardState: import("jotai").PrimitiveAtom<boardType | null> & {
    init: boardType | null;
};
export declare const dealPipelineState: import("jotai").PrimitiveAtom<pipelineType | null> & {
    init: pipelineType | null;
};
export declare const dealStageState: import("jotai").PrimitiveAtom<stageType | null> & {
    init: stageType | null;
};
export {};
