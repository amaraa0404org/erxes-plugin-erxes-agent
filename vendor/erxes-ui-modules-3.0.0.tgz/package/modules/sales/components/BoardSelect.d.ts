export declare const BoardSelect: ({ boardId, className, onChange, }: {
    boardId?: string;
    className?: string;
    onChange?: (boardId: string | string[], callback?: () => void) => void;
}) => import("react/jsx-runtime").JSX.Element;
