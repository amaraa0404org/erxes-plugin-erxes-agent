import { IStage } from 'ui-modules/index';
import React from 'react';
export declare const SelectStageProvider: ({ children, mode, value, onValueChange, stages, pipelineId, autoSelectFirst, }: {
    children: React.ReactNode;
    mode?: "single" | "multiple";
    value?: string[] | string;
    onValueChange?: (value: string[] | string, isAutoSelection?: boolean) => void;
    stages?: IStage[];
    pipelineId?: string;
    autoSelectFirst?: boolean;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectStageFilterItem: () => import("react/jsx-runtime").JSX.Element;
export declare const SelectStageFilterView: ({ onValueChange, queryKey, mode, pipelineId, }: {
    onValueChange?: (value: string[] | string) => void;
    queryKey?: string;
    mode?: "single" | "multiple";
    pipelineId?: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectStageFilterBar: ({ iconOnly, onValueChange, queryKey, mode, pipelineId, }: {
    iconOnly?: boolean;
    onValueChange?: (value: string[] | string) => void;
    queryKey?: string;
    mode?: "single" | "multiple";
    pipelineId?: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectStageInlineCell: ({ onValueChange, pipelineId, className, ...props }: Omit<React.ComponentProps<typeof SelectStageProvider>, "children"> & {
    scope?: string;
    className?: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectStageFormItem: {
    ({ onValueChange, className, placeholder, pipelineId, ...props }: Omit<React.ComponentProps<typeof SelectStageProvider>, "children"> & {
        className?: string;
        placeholder?: string;
        pipelineId?: string;
    }): import("react/jsx-runtime").JSX.Element;
    displayName: string;
};
export declare const SelectStage: React.ForwardRefExoticComponent<Omit<Omit<{
    children: React.ReactNode;
    mode?: "single" | "multiple";
    value?: string[] | string;
    onValueChange?: (value: string[] | string, isAutoSelection?: boolean) => void;
    stages?: IStage[];
    pipelineId?: string;
    autoSelectFirst?: boolean;
}, "children"> & Omit<import("erxes-ui").ButtonProps & React.RefAttributes<HTMLButtonElement>, "ref"> & {
    hideChevron?: boolean;
} & React.RefAttributes<HTMLButtonElement> & {
    placeholder?: string;
    pipelineId?: string;
}, "ref"> & React.RefAttributes<HTMLButtonElement>> & {
    Provider: ({ children, mode, value, onValueChange, stages, pipelineId, autoSelectFirst, }: {
        children: React.ReactNode;
        mode?: "single" | "multiple";
        value?: string[] | string;
        onValueChange?: (value: string[] | string, isAutoSelection?: boolean) => void;
        stages?: IStage[];
        pipelineId?: string;
        autoSelectFirst?: boolean;
    }) => import("react/jsx-runtime").JSX.Element;
    Value: ({ placeholder }: {
        placeholder?: string;
    }) => import("react/jsx-runtime").JSX.Element;
    Content: () => import("react/jsx-runtime").JSX.Element;
    FilterItem: () => import("react/jsx-runtime").JSX.Element;
    FilterView: ({ onValueChange, queryKey, mode, pipelineId, }: {
        onValueChange?: (value: string[] | string) => void;
        queryKey?: string;
        mode?: "single" | "multiple";
        pipelineId?: string;
    }) => import("react/jsx-runtime").JSX.Element;
    FilterBar: ({ iconOnly, onValueChange, queryKey, mode, pipelineId, }: {
        iconOnly?: boolean;
        onValueChange?: (value: string[] | string) => void;
        queryKey?: string;
        mode?: "single" | "multiple";
        pipelineId?: string;
    }) => import("react/jsx-runtime").JSX.Element;
    InlineCell: ({ onValueChange, pipelineId, className, ...props }: Omit<React.ComponentProps<typeof SelectStageProvider>, "children"> & {
        scope?: string;
        className?: string;
    }) => import("react/jsx-runtime").JSX.Element;
    FormItem: {
        ({ onValueChange, className, placeholder, pipelineId, ...props }: Omit<React.ComponentProps<typeof SelectStageProvider>, "children"> & {
            className?: string;
            placeholder?: string;
            pipelineId?: string;
        }): import("react/jsx-runtime").JSX.Element;
        displayName: string;
    };
};
