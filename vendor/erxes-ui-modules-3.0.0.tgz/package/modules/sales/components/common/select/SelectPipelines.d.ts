import React from 'react';
import { IPipeline } from 'ui-modules/index';
export declare const SelectPipelineProvider: ({ children, mode, value, onValueChange, pipelines, boardId, }: {
    children: React.ReactNode;
    mode?: "single" | "multiple";
    value?: string[] | string;
    onValueChange?: (value: string[] | string) => void;
    pipelines?: IPipeline[];
    boardId?: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectPipelineFilterItem: () => import("react/jsx-runtime").JSX.Element;
export declare const SelectPipelineFilterView: ({ onValueChange, queryKey, mode, boardId, }: {
    onValueChange?: (value: string[] | string) => void;
    queryKey?: string;
    mode?: "single" | "multiple";
    boardId?: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectPipelineFilterBar: ({ iconOnly, onValueChange, queryKey, mode, boardId, }: {
    iconOnly?: boolean;
    onValueChange?: (value: string[] | string) => void;
    queryKey?: string;
    mode?: "single" | "multiple";
    boardId?: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectPipelineInlineCell: ({ onValueChange, boardId, className, ...props }: Omit<React.ComponentProps<typeof SelectPipelineProvider>, "children"> & {
    scope?: string;
    className?: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectPipelineFormItem: {
    ({ onValueChange, className, placeholder, boardId, ...props }: Omit<React.ComponentProps<typeof SelectPipelineProvider>, "children"> & {
        className?: string;
        placeholder?: string;
        boardId?: string;
    }): import("react/jsx-runtime").JSX.Element;
    displayName: string;
};
export declare const SelectPipeline: React.ForwardRefExoticComponent<Omit<Omit<{
    children: React.ReactNode;
    mode?: "single" | "multiple";
    value?: string[] | string;
    onValueChange?: (value: string[] | string) => void;
    pipelines?: IPipeline[];
    boardId?: string;
}, "children"> & Omit<import("erxes-ui").ButtonProps & React.RefAttributes<HTMLButtonElement>, "ref"> & {
    hideChevron?: boolean;
} & React.RefAttributes<HTMLButtonElement> & {
    placeholder?: string;
    boardId?: string;
}, "ref"> & React.RefAttributes<HTMLButtonElement>> & {
    Provider: ({ children, mode, value, onValueChange, pipelines, boardId, }: {
        children: React.ReactNode;
        mode?: "single" | "multiple";
        value?: string[] | string;
        onValueChange?: (value: string[] | string) => void;
        pipelines?: IPipeline[];
        boardId?: string;
    }) => import("react/jsx-runtime").JSX.Element;
    Value: ({ placeholder }: {
        placeholder?: string;
    }) => import("react/jsx-runtime").JSX.Element;
    Content: () => import("react/jsx-runtime").JSX.Element;
    FilterItem: () => import("react/jsx-runtime").JSX.Element;
    FilterView: ({ onValueChange, queryKey, mode, boardId, }: {
        onValueChange?: (value: string[] | string) => void;
        queryKey?: string;
        mode?: "single" | "multiple";
        boardId?: string;
    }) => import("react/jsx-runtime").JSX.Element;
    FilterBar: ({ iconOnly, onValueChange, queryKey, mode, boardId, }: {
        iconOnly?: boolean;
        onValueChange?: (value: string[] | string) => void;
        queryKey?: string;
        mode?: "single" | "multiple";
        boardId?: string;
    }) => import("react/jsx-runtime").JSX.Element;
    InlineCell: ({ onValueChange, boardId, className, ...props }: Omit<React.ComponentProps<typeof SelectPipelineProvider>, "children"> & {
        scope?: string;
        className?: string;
    }) => import("react/jsx-runtime").JSX.Element;
    FormItem: {
        ({ onValueChange, className, placeholder, boardId, ...props }: Omit<React.ComponentProps<typeof SelectPipelineProvider>, "children"> & {
            className?: string;
            placeholder?: string;
            boardId?: string;
        }): import("react/jsx-runtime").JSX.Element;
        displayName: string;
    };
};
