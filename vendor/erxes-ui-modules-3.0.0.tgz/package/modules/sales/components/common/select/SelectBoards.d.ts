import React from 'react';
import { IBoard } from 'ui-modules/modules/sales/types';
export declare const SelectBoardProvider: ({ children, mode, value, onValueChange, boards, }: {
    children: React.ReactNode;
    mode?: "single" | "multiple";
    value?: string[] | string;
    onValueChange?: (value: string[] | string) => void;
    boards?: IBoard[];
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectBoardFilterItem: () => import("react/jsx-runtime").JSX.Element;
export declare const SelectBoardFilterView: ({ onValueChange, queryKey, mode, }: {
    onValueChange?: (value: string[] | string) => void;
    queryKey?: string;
    mode?: "single" | "multiple";
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectBoardFilterBar: ({ iconOnly, onValueChange, queryKey, mode, }: {
    iconOnly?: boolean;
    onValueChange?: (value: string[] | string) => void;
    queryKey?: string;
    mode?: "single" | "multiple";
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectBoardInlineCell: ({ onValueChange, className, ...props }: Omit<React.ComponentProps<typeof SelectBoardProvider>, "children"> & {
    className?: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectBoardFormItem: {
    ({ onValueChange, className, placeholder, ...props }: Omit<React.ComponentProps<typeof SelectBoardProvider>, "children"> & {
        className?: string;
        placeholder?: string;
    }): import("react/jsx-runtime").JSX.Element;
    displayName: string;
};
export declare const SelectBoard: React.ForwardRefExoticComponent<Omit<Omit<{
    children: React.ReactNode;
    mode?: "single" | "multiple";
    value?: string[] | string;
    onValueChange?: (value: string[] | string) => void;
    boards?: IBoard[];
}, "children"> & Omit<import("erxes-ui").ButtonProps & React.RefAttributes<HTMLButtonElement>, "ref"> & {
    hideChevron?: boolean;
} & React.RefAttributes<HTMLButtonElement> & {
    placeholder?: string;
}, "ref"> & React.RefAttributes<HTMLButtonElement>> & {
    Provider: ({ children, mode, value, onValueChange, boards, }: {
        children: React.ReactNode;
        mode?: "single" | "multiple";
        value?: string[] | string;
        onValueChange?: (value: string[] | string) => void;
        boards?: IBoard[];
    }) => import("react/jsx-runtime").JSX.Element;
    Value: ({ placeholder }: {
        placeholder?: string;
    }) => import("react/jsx-runtime").JSX.Element;
    Content: () => import("react/jsx-runtime").JSX.Element;
    FilterItem: () => import("react/jsx-runtime").JSX.Element;
    FilterView: ({ onValueChange, queryKey, mode, }: {
        onValueChange?: (value: string[] | string) => void;
        queryKey?: string;
        mode?: "single" | "multiple";
    }) => import("react/jsx-runtime").JSX.Element;
    FilterBar: ({ iconOnly, onValueChange, queryKey, mode, }: {
        iconOnly?: boolean;
        onValueChange?: (value: string[] | string) => void;
        queryKey?: string;
        mode?: "single" | "multiple";
    }) => import("react/jsx-runtime").JSX.Element;
    InlineCell: ({ onValueChange, className, ...props }: Omit<React.ComponentProps<typeof SelectBoardProvider>, "children"> & {
        className?: string;
    }) => import("react/jsx-runtime").JSX.Element;
    FormItem: {
        ({ onValueChange, className, placeholder, ...props }: Omit<React.ComponentProps<typeof SelectBoardProvider>, "children"> & {
            className?: string;
            placeholder?: string;
        }): import("react/jsx-runtime").JSX.Element;
        displayName: string;
    };
};
