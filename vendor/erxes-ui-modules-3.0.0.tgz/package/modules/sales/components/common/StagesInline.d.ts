import { IStage } from '../../types';
export interface StagesInlineProps {
    stageIds?: string[];
    stages?: IStage[];
    placeholder?: string;
    updateStages?: (stages: IStage[]) => void;
}
export declare const StagesInline: ((props: StagesInlineProps) => import("react/jsx-runtime").JSX.Element) & {
    Provider: ({ children, stageIds, stages, placeholder, updateStages, }: StagesInlineProps & {
        children?: React.ReactNode;
    }) => import("react/jsx-runtime").JSX.Element;
    Title: () => import("react/jsx-runtime").JSX.Element;
};
