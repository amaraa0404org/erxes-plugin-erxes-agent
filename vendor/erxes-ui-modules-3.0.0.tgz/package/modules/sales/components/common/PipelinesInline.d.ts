import { IPipeline } from '../../types';
export interface PipelinesInlineProps {
    pipelineIds?: string[];
    pipelines?: IPipeline[];
    placeholder?: string;
    updatePipelines?: (pipelines: IPipeline[]) => void;
}
export declare const PipelinesInline: ((props: PipelinesInlineProps) => import("react/jsx-runtime").JSX.Element) & {
    Provider: ({ children, pipelineIds, pipelines, placeholder, updatePipelines, }: PipelinesInlineProps & {
        children?: React.ReactNode;
    }) => import("react/jsx-runtime").JSX.Element;
    Title: () => import("react/jsx-runtime").JSX.Element;
};
