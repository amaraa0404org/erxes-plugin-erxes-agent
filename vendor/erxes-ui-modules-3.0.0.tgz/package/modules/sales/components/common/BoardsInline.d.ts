import { BoardsInlineProps } from '../../types/boards';
export declare const BoardsInline: ((props: BoardsInlineProps) => import("react/jsx-runtime").JSX.Element) & {
    Provider: ({ children, boardIds, boards, placeholder, updateBoards, }: BoardsInlineProps & {
        children?: React.ReactNode;
    }) => import("react/jsx-runtime").JSX.Element;
    Title: () => import("react/jsx-runtime").JSX.Element;
};
