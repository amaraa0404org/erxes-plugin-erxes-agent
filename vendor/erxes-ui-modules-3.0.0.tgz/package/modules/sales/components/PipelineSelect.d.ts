export declare const PipelineSelect: ({ pipelineId, className, onChange, }: {
    pipelineId?: string;
    className?: string;
    onChange?: (pipelineId: string | string[], callback?: () => void) => void;
}) => import("react/jsx-runtime").JSX.Element;
