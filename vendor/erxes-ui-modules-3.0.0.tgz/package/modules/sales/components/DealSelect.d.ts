import { DealSelectProps } from '../types';
export declare const DealSelect: ({ boardId: initialBoardId, pipelineId: initialPipelineId, stageId: initialStageId, onMove, moveLoading, }: DealSelectProps) => import("react/jsx-runtime").JSX.Element;
