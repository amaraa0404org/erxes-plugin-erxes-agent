export declare const StageSelect: ({ stageId, pipelineId: dealPipelineId, className, onChange, }: {
    stageId?: string;
    pipelineId?: string;
    className?: string;
    onChange?: (stageId: string | string[], callback?: () => void) => void;
}) => import("react/jsx-runtime").JSX.Element;
