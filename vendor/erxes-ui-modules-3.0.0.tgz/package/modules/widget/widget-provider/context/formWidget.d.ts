import { Icon } from '@tabler/icons-react';
import { FieldValues, UseFormReturn } from 'react-hook-form';
export interface IFormWidgetForm {
    setValue: (field: string, value: unknown, options?: {
        shouldDirty?: boolean;
    }) => void;
    watch: (field: string) => unknown;
}
export interface IFormWidgetProps {
    pluginName: string;
    contentType: string;
    contentId?: string;
    form: IFormWidgetForm;
}
export interface IFormWidgetModule {
    name: string;
    pluginName: string;
    contentType: string;
    icon?: Icon;
}
export declare const toFormWidgetForm: <T extends FieldValues>(form: UseFormReturn<T>) => IFormWidgetForm;
