import { IRelationInput } from 'erxes-ui';
export declare const useCreateRelation: () => {
    createRelation: (relation: IRelationInput) => void;
    loading: boolean;
    error: import("@apollo/client").ApolloError | undefined;
};
