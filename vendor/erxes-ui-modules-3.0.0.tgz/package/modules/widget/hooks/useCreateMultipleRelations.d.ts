import { IRelationInput } from 'erxes-ui';
export declare const useCreateMultipleRelations: () => {
    createMultipleRelations: (relations: IRelationInput[]) => void;
    loading: boolean;
    error: import("@apollo/client").ApolloError | undefined;
};
