import { WidgetAccessProp } from '../widget-provider/context/widgetContext';
export declare const RelationWidgetSideTabs: ({ contentId, contentType, access, hookOptions, customerId, companyId, }: {
    contentId: string;
    contentType: string;
    access?: WidgetAccessProp;
    hookOptions?: {
        hiddenPlugins?: string[];
        hiddenModules?: string[];
        hideCoreRelations?: boolean;
    };
    customerId?: string;
    companyId?: string;
}) => import("react/jsx-runtime").JSX.Element;
