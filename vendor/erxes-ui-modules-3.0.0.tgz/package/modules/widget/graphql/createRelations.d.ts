export declare const CREATE_RELATIONS: import("@apollo/client").DocumentNode;
export declare const CREATE_MULTIPLE_RELATIONS: import("@apollo/client").DocumentNode;
