export declare const MANAGE_RELATIONS: import("@apollo/client").DocumentNode;
