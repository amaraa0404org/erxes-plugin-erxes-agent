export declare const GET_RELATIONS_BY_ENTITY: import("@apollo/client").DocumentNode;
