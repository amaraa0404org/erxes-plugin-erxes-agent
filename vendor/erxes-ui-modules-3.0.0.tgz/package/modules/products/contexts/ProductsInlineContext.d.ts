import { IProduct } from '../types';
export interface IProductsInlineContext {
    products: IProduct[];
    loading: boolean;
    productIds?: string[];
    placeholder: string;
    updateProducts?: (products: IProduct[]) => void;
}
export declare const ProductsInlineContext: import("react").Context<IProductsInlineContext | null>;
export declare const useProductsInlineContext: () => IProductsInlineContext;
