import { IProduct } from '../types/Product';
export type ISelectProductContext = {
    productIds: string[];
    onSelect: (product: IProduct) => void;
    products: IProduct[];
    setProducts: (products: IProduct[]) => void;
    loading: boolean;
    error: string | null;
    defaultSearchValue?: string;
    selectedProducts?: IProduct[];
    mode?: 'single' | 'multiple';
    removeId?: (id: string) => void;
};
export declare const SelectProductContext: import("react").Context<ISelectProductContext | null>;
export declare const useSelectProductContext: () => ISelectProductContext;
