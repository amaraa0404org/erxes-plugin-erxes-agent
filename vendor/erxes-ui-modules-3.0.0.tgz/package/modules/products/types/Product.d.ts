import { CurrencyCode } from 'erxes-ui';
import { PRODUCT_FORM_SCHEMA } from '../constants/addProductFormSchema';
import { z } from 'zod';
import { IProductCategory } from '../categories/types/category';
export interface IProduct {
    _id: string;
    name: string;
    unitPrice: number;
    weight?: number;
    code: string;
    categoryId: string;
    category?: IProductCategory;
    tagIds: string[];
    branchId?: string;
    departmentId?: string;
    uom: string;
    type: 'product' | 'service' | 'unique' | 'subscription';
    duration?: number;
    durationType?: 'minute' | 'hour' | 'day' | 'week' | 'month' | 'quarter' | 'year';
    currency: CurrencyCode;
    remainder: any;
    status?: 'active' | 'deleted';
}
export interface IBundleRuleItem {
    code: string;
    quantity: number;
    productIds: string[];
    products: IProduct[];
    priceValue: number;
    percent: number;
    priceType: 'thisProductPricePercent' | 'price' | 'mainPricePercent';
    priceAdjustType: string;
    priceAdjustFactor: number;
    allowSkip: boolean;
}
export interface IDiscountValue {
    bonusName: string;
    discount: number;
    potentialBonus: number;
    sumDiscount: number;
    type: string;
    voucherCampaignId: string;
    voucherId: string;
    voucherName: string;
}
export interface IDealBundleItem {
    bundleCode: string;
    count: number;
    total: number;
    selectedProductId?: string;
    selectedProduct?: IProduct;
    bundleSnapshot?: IBundleRuleItem;
}
export interface IProductData {
    _id: string;
    productId?: string;
    product?: IProduct;
    uom?: string;
    currency?: string;
    quantity: number;
    unitPrice: number;
    globalUnitPrice: number;
    unitPricePercent: number;
    taxPercent: number;
    tax: number;
    vatPercent: number;
    discountPercent: number;
    discount: number;
    amount: number;
    tickUsed?: boolean;
    isVatApplied?: boolean;
    assignUserId?: string;
    maxQuantity: number;
    branchId?: string;
    departmentId?: string;
    assignedUserId?: string;
    conditions?: IDealBundleItem[];
}
export interface IUom {
    _id: string;
    name: string;
    code: string;
    productCount: number;
}
export interface IProductDetail extends IProduct {
    shortName: string;
    description: string;
    barcodeDescription: string;
    barcodes: string[];
    vendorId: string;
}
export interface IProductType {
    label: string;
    value: string;
}
export type IProductFormValues = z.infer<typeof PRODUCT_FORM_SCHEMA>;
