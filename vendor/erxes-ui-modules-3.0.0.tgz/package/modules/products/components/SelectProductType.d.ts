export declare const SelectProductType: ({ value, onValueChange, inForm, }: {
    value: string;
    onValueChange: (value: string) => void;
    inForm?: boolean;
}) => import("react/jsx-runtime").JSX.Element;
