import { MutationHookOptions } from '@apollo/client';
import { UseFormReturn } from 'react-hook-form';
import { IProductFormValues } from '../types';
export declare function AddProductForm({ embed, onOpenChange, showMoreInfo: controlledShowMoreInfo, onShowMoreInfoChange, options, form, }: Readonly<{
    embed?: boolean;
    onOpenChange: (open: boolean) => void;
    showMoreInfo?: boolean;
    onShowMoreInfoChange?: (showMoreInfo: boolean) => void;
    options?: MutationHookOptions<{
        productsAdd: {
            _id: string;
        };
    }>;
    form: UseFormReturn<IProductFormValues>;
}>): import("react/jsx-runtime").JSX.Element;
