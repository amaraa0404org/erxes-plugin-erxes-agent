import { MutationHookOptions } from '@apollo/client';
export declare const AddProduct: ({ children, options, }: {
    children?: React.ReactNode;
    options?: MutationHookOptions<{
        productsAdd: {
            _id: string;
        };
    }>;
}) => import("react/jsx-runtime").JSX.Element;
