export type SubUomItem = {
    _id?: string;
    uom: string;
    ratio: number | string;
};
interface SubUomRowProps {
    subUom: SubUomItem;
    index: number;
    onUpdate: (index: number, fieldName: keyof SubUomItem, value: string | number) => void;
    onRemove: (index: number) => void;
    t: (key: string) => string;
}
export declare function SubUomRow({ subUom, index, onUpdate, onRemove, t, }: SubUomRowProps): import("react/jsx-runtime").JSX.Element;
export {};
