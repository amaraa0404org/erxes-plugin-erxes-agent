export type ProductAttachmentItem = {
    name: string;
    url: string;
    type: string;
    size: number;
};
export declare const PRODUCT_SECONDARY_IMAGE_LIMIT = 10;
export declare const toProductAttachmentItem: (file: Partial<ProductAttachmentItem> | null | undefined) => ProductAttachmentItem | null;
export declare const toProductAttachmentList: (value: unknown) => ProductAttachmentItem[];
export declare function ProductPrimaryImageUpload({ value, onChange, }: {
    value?: ProductAttachmentItem | null;
    onChange: (value: ProductAttachmentItem | null) => void;
}): import("react/jsx-runtime").JSX.Element;
export declare function ProductSecondaryImagesUpload({ value, onChange, maxImages, }: {
    value?: ProductAttachmentItem[];
    onChange: (value: ProductAttachmentItem[]) => void;
    maxImages?: number;
}): import("react/jsx-runtime").JSX.Element;
