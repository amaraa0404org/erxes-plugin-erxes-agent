import { UseFormReturn } from 'react-hook-form';
import { IProductFormValues } from '../types';
export declare function BarcodeManager({ form, }: Readonly<{
    form: UseFormReturn<IProductFormValues>;
}>): import("react/jsx-runtime").JSX.Element;
export declare function SubUomManager({ form, }: Readonly<{
    form: UseFormReturn<IProductFormValues>;
}>): import("react/jsx-runtime").JSX.Element;
