import { UseFormReturn } from 'react-hook-form';
import { IProductFormValues } from '../types';
export declare function AddProductFormAttachmentsAndExtra({ form, }: Readonly<{
    form: UseFormReturn<IProductFormValues>;
}>): import("react/jsx-runtime").JSX.Element;
