import { IProduct } from '../types/Product';
interface SelectProductsProps {
    onSelect: (productIds: string[], products?: IProduct[]) => void | Promise<void>;
    children?: React.ReactNode;
    productIds?: string[];
    initialProducts?: IProduct[];
    open?: boolean;
    onOpenChange?: (open: boolean) => void;
    selectionLimit?: number;
    title?: React.ReactNode;
    description?: React.ReactNode;
    submitLabel?: React.ReactNode;
    cancelLabel?: React.ReactNode;
    selectedLabel?: React.ReactNode;
    isSelectionValid?: (productIds: string[], products: IProduct[]) => boolean;
}
export declare const SelectProductsBulk: ({ onSelect, children, productIds, initialProducts, open, onOpenChange, selectionLimit, title, description, submitLabel, cancelLabel, selectedLabel, isSelectionValid, }: SelectProductsProps) => import("react/jsx-runtime").JSX.Element;
export {};
