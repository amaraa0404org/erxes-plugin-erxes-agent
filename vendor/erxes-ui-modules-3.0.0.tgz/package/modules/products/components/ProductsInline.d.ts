import { IProduct } from '../types/Product';
export declare const ProductsInlineProvider: ({ children, productIds, products, placeholder, updateProducts, }: {
    children?: React.ReactNode;
    productIds?: string[];
    products?: IProduct[];
    placeholder?: string;
    updateProducts?: (products: IProduct[]) => void;
}) => import("react/jsx-runtime").JSX.Element;
export declare const ProductsInlineTitle: ({ className }: {
    className?: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const ProductsInlineRoot: ({ productIds, products, placeholder, updateProducts, className, }: {
    products?: IProduct[];
    productIds?: string[];
    placeholder?: string;
    updateProducts?: (products: IProduct[]) => void;
    className?: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const ProductsInline: (({ productIds, products, placeholder, updateProducts, className, }: {
    products?: IProduct[];
    productIds?: string[];
    placeholder?: string;
    updateProducts?: (products: IProduct[]) => void;
    className?: string;
}) => import("react/jsx-runtime").JSX.Element) & {
    Provider: ({ children, productIds, products, placeholder, updateProducts, }: {
        children?: React.ReactNode;
        productIds?: string[];
        products?: IProduct[];
        placeholder?: string;
        updateProducts?: (products: IProduct[]) => void;
    }) => import("react/jsx-runtime").JSX.Element;
    Title: ({ className }: {
        className?: string;
    }) => import("react/jsx-runtime").JSX.Element;
};
