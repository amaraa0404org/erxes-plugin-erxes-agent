import type { ProductAttachmentItem } from './ProductImageUploads';
export declare const PRODUCT_VIDEO_LIMIT = 5;
export declare function ProductVideosUpload({ value, onChange, maxVideos, }: Readonly<{
    value?: ProductAttachmentItem[];
    onChange: (value: ProductAttachmentItem[]) => void;
    maxVideos?: number;
}>): import("react/jsx-runtime").JSX.Element;
