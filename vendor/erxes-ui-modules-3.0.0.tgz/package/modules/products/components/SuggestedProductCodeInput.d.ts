import { InputProps } from 'erxes-ui';
type SuggestedProductCodeInputProps = InputProps & {
    suggestedCode?: string;
    onUseSuggestion: () => void;
};
export declare const SuggestedProductCodeInput: ({ suggestedCode, onUseSuggestion, disabled, ...props }: SuggestedProductCodeInputProps) => import("react/jsx-runtime").JSX.Element;
export {};
