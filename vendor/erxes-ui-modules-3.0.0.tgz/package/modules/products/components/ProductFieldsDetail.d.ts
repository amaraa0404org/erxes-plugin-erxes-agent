import { UseFormReturn } from 'react-hook-form';
import { IProductFormValues } from '../types';
export declare function AddProductFormFieldsDetail({ form, showExtended, }: Readonly<{
    form: UseFormReturn<IProductFormValues>;
    showExtended?: boolean;
}>): import("react/jsx-runtime").JSX.Element;
