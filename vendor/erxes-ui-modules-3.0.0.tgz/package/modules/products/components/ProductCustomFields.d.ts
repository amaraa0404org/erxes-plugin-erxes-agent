import { UseFormReturn } from 'react-hook-form';
import { IProductFormValues } from '../types';
export declare function AddProductFormCustomFields({ form, noTopPadding, }: Readonly<{
    form: UseFormReturn<IProductFormValues>;
    noTopPadding?: boolean;
}>): import("react/jsx-runtime").JSX.Element | null;
