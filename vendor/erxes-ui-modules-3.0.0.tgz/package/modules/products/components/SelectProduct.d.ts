import React from 'react';
import { IProduct } from '../types/Product';
interface SelectProductProviderProps {
    children: React.ReactNode;
    value?: string[] | string;
    onValueChange?: (value: string[] | string) => void;
    mode?: 'single' | 'multiple';
    defaultSearchValue?: string;
}
declare const SelectProductProvider: ({ children, value, onValueChange, mode, defaultSearchValue, }: SelectProductProviderProps) => import("react/jsx-runtime").JSX.Element;
export declare const SelectProductFilterItem: ({ value, label, }: {
    value: string;
    label: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectProductFilterView: ({ onValueChange, filterKey, mode, }: {
    onValueChange?: (value: string[] | string) => void;
    filterKey: string;
    mode?: "single" | "multiple";
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectProductFilterBar: ({ iconOnly, onValueChange, filterKey, label, mode, }: {
    iconOnly?: boolean;
    filterKey: string;
    label: string;
    onValueChange?: (value: string[] | string) => void;
    mode?: "single" | "multiple";
}) => import("react/jsx-runtime").JSX.Element | null;
export declare const SelectProductFormItem: ({ onValueChange, className, placeholder, ...props }: Omit<React.ComponentProps<typeof SelectProductProvider>, "children"> & {
    className?: string;
    placeholder?: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectProduct: React.ForwardRefExoticComponent<Omit<Omit<SelectProductProviderProps, "children"> & Omit<import("erxes-ui").ButtonProps & React.RefAttributes<HTMLButtonElement>, "ref"> & {
    hideChevron?: boolean;
} & React.RefAttributes<HTMLButtonElement> & {
    placeholder?: string;
    scope?: string;
}, "ref"> & React.RefAttributes<HTMLButtonElement>> & {
    Provider: ({ children, value, onValueChange, mode, defaultSearchValue, }: SelectProductProviderProps) => import("react/jsx-runtime").JSX.Element;
    Content: () => import("react/jsx-runtime").JSX.Element;
    Item: ({ product }: {
        product: IProduct;
    }) => import("react/jsx-runtime").JSX.Element;
    InlineCell: ({ onValueChange, placeholder, scope, ...props }: Omit<React.ComponentProps<typeof SelectProductProvider>, "children"> & {
        placeholder?: string;
        scope?: string;
    }) => import("react/jsx-runtime").JSX.Element;
    Value: ({ placeholder }: {
        placeholder?: string;
    }) => import("react/jsx-runtime").JSX.Element;
    FilterItem: ({ value, label, }: {
        value: string;
        label: string;
    }) => import("react/jsx-runtime").JSX.Element;
    FilterView: ({ onValueChange, filterKey, mode, }: {
        onValueChange?: (value: string[] | string) => void;
        filterKey: string;
        mode?: "single" | "multiple";
    }) => import("react/jsx-runtime").JSX.Element;
    FilterBar: ({ iconOnly, onValueChange, filterKey, label, mode, }: {
        iconOnly?: boolean;
        filterKey: string;
        label: string;
        onValueChange?: (value: string[] | string) => void;
        mode?: "single" | "multiple";
    }) => import("react/jsx-runtime").JSX.Element | null;
    FormItem: ({ onValueChange, className, placeholder, ...props }: Omit<React.ComponentProps<typeof SelectProductProvider>, "children"> & {
        className?: string;
        placeholder?: string;
    }) => import("react/jsx-runtime").JSX.Element;
};
export {};
