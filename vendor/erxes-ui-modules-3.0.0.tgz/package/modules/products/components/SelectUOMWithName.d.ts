interface SelectUOMWithNameProps {
    value: string;
    onValueChange: (value: string) => void;
    inForm?: boolean;
    disabledUoms?: string[];
}
export declare const SelectUOMWithName: ({ value, onValueChange, inForm, disabledUoms, }: SelectUOMWithNameProps) => import("react/jsx-runtime").JSX.Element;
export {};
