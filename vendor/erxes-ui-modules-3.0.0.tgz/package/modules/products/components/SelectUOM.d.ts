export declare const SelectUOM: ({ value, onValueChange, inForm, disabledUoms, }: {
    value: string;
    onValueChange: (value: string) => void;
    inForm?: boolean;
    disabledUoms?: string[];
}) => import("react/jsx-runtime").JSX.Element;
