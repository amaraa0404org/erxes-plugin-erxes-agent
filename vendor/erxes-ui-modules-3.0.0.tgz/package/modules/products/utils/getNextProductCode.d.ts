export declare const getNextProductCode: (code?: string | null) => string;
