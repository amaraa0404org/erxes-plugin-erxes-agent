import { IUom } from '../types';
/**
 * `product.uom` (and `subUoms[].uom`) is stored canonically as the UOM **code**.
 * The Select widgets, however, work in terms of the UOM `_id`. These helpers
 * convert between the stored value and the widget value, while tolerating
 * legacy data that may hold a name or an `_id` instead of a code.
 */
export declare const findUom: (uoms: IUom[], value?: string) => IUom | undefined;
/** Select/widget value (an `_id`) or any representation -> canonical stored code. */
export declare const uomToCode: (uoms: IUom[], value?: string) => string;
/** Stored value (code, or legacy name/`_id`) -> the `_id` the Select expects. */
export declare const uomToId: (uoms: IUom[], value?: string) => string;
/** Stored value -> human readable name for display. */
export declare const uomToName: (uoms: IUom[], value?: string) => string;
