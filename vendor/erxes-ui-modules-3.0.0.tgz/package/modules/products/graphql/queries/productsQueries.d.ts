export declare const GET_PRODUCTS: import("@apollo/client").DocumentNode;
export declare const GET_ASSIGNED_PRODUCTS: import("@apollo/client").DocumentNode;
export declare const GET_PRODUCT_INLINE: import("@apollo/client").DocumentNode;
export declare const GET_PRODUCT_LAST_CODE_BY_CATEGORY: import("@apollo/client").DocumentNode;
export declare const UOM_QUERY: import("@apollo/client").DocumentNode;
