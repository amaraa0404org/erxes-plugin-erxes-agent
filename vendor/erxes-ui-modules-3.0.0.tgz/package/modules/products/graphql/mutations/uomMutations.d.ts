export declare const UOMS_ADD: import("@apollo/client").DocumentNode;
