export declare const PRODUCTS_ADD: import("@apollo/client").DocumentNode;
export declare const PRODUCTS_EDIT: import("@apollo/client").DocumentNode;
export declare const PRODUCTS_CATEGORY_REMOVE: import("@apollo/client").DocumentNode;
export declare const PRODUCTS_CATEGORY_EDIT: import("@apollo/client").DocumentNode;
