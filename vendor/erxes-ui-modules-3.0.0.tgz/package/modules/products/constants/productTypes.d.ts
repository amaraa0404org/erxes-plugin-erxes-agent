export declare const PRODUCT_TYPES: {
    label: string;
    value: string;
}[];
export declare const PRODUCT_DURATION_TYPES: readonly [{
    readonly label: "Minute";
    readonly value: "minute";
}, {
    readonly label: "Hour";
    readonly value: "hour";
}, {
    readonly label: "Day";
    readonly value: "day";
}, {
    readonly label: "Week";
    readonly value: "week";
}, {
    readonly label: "Month";
    readonly value: "month";
}, {
    readonly label: "Quarter";
    readonly value: "quarter";
}, {
    readonly label: "Year";
    readonly value: "year";
}];
export declare const PRODUCT_DURATION_TYPE_VALUES: readonly ["minute", "hour", "day", "week", "month", "quarter", "year"];
