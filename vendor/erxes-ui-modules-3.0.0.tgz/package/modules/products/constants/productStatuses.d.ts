export declare const PRODUCT_STATUSES: string[];
