export declare const PRODUCTS_PER_PAGE = 30;
