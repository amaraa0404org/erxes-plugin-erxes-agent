import { OperationVariables } from '@apollo/client';
import { UseProductCategoriesResult } from '../types/category';
export declare const useProductCategories: (options?: OperationVariables) => UseProductCategoriesResult;
