export declare const productCategories: import("@apollo/client").DocumentNode;
