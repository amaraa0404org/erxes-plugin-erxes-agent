import React from 'react';
import { IProductCategory } from '../types/category';
interface SelectCategoryProviderProps {
    children: React.ReactNode;
    value?: string[] | string;
    selected?: string[] | string;
    onValueChange?: (value: string[] | string) => void;
    onSelect?: (value: string[] | string) => void;
    mode?: 'single' | 'multiple';
}
declare const SelectCategoryProvider: ({ children, value, selected, onValueChange, onSelect, mode, }: SelectCategoryProviderProps) => import("react/jsx-runtime").JSX.Element;
export declare const SelectCategory: React.ForwardRefExoticComponent<Omit<SelectCategoryProviderProps, "children"> & Omit<Omit<Omit<import("erxes-ui").ButtonProps & React.RefAttributes<HTMLButtonElement>, "ref"> & {
    hideChevron?: boolean;
} & React.RefAttributes<HTMLButtonElement>, "ref">, "children"> & {
    placeholder?: string;
    scope?: string;
} & React.RefAttributes<HTMLButtonElement>> & {
    Provider: ({ children, value, selected, onValueChange, onSelect, mode, }: SelectCategoryProviderProps) => import("react/jsx-runtime").JSX.Element;
    CommandbarItem: ({ onValueChange, onSelect, ...props }: Omit<React.ComponentProps<typeof SelectCategoryProvider>, "children">) => import("react/jsx-runtime").JSX.Element;
    Content: () => import("react/jsx-runtime").JSX.Element;
    Command: () => import("react/jsx-runtime").JSX.Element;
    GroupsCommand: () => import("react/jsx-runtime").JSX.Element;
    Item: ({ category, }: {
        category: IProductCategory & {
            hasChildren?: boolean;
        };
    }) => import("react/jsx-runtime").JSX.Element;
    Value: ({ placeholder }: {
        placeholder?: string;
    }) => import("react/jsx-runtime").JSX.Element;
    List: ({ placeholder, renderAsPlainText, }: {
        placeholder?: string;
        renderAsPlainText?: boolean;
    }) => import("react/jsx-runtime").JSX.Element;
    InlineCell: ({ onValueChange, onSelect, placeholder, scope, ...props }: Omit<React.ComponentProps<typeof SelectCategoryProvider>, "children"> & {
        placeholder?: string;
        scope?: string;
    }) => import("react/jsx-runtime").JSX.Element;
    Detail: ({ onValueChange, onSelect, className, scope, ...props }: Omit<React.ComponentProps<typeof SelectCategoryProvider>, "children"> & {
        className?: string;
        scope?: string;
    }) => import("react/jsx-runtime").JSX.Element;
    ConversationDetail: ({ onValueChange, onSelect, className, scope, ...props }: Omit<React.ComponentProps<typeof SelectCategoryProvider>, "children"> & {
        className?: string;
        scope?: string;
    }) => import("react/jsx-runtime").JSX.Element;
    FormItem: {
        ({ onValueChange, onSelect, className, placeholder, scope, ...props }: Omit<React.ComponentProps<typeof SelectCategoryProvider>, "children"> & {
            className?: string;
            placeholder?: string;
            scope?: string;
        }): import("react/jsx-runtime").JSX.Element;
        displayName: string;
    };
    FilterItem: ({ value, label, }: {
        value?: string;
        label?: string;
    }) => import("react/jsx-runtime").JSX.Element;
    FilterView: ({ onValueChange, queryKey, filterKey, mode, }: {
        onValueChange?: (value: string[] | string) => void;
        queryKey?: string;
        filterKey?: string;
        mode?: "single" | "multiple";
    }) => import("react/jsx-runtime").JSX.Element;
    FilterBar: ({ onValueChange, queryKey, filterKey, label, mode, }: {
        onValueChange?: (value: string[] | string) => void;
        queryKey?: string;
        filterKey?: string;
        label?: string;
        mode?: "single" | "multiple";
    }) => import("react/jsx-runtime").JSX.Element | null;
};
export {};
