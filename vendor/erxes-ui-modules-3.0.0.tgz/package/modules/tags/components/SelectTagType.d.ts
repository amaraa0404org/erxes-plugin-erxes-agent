import React from 'react';
import { ButtonProps } from 'erxes-ui';
interface SelectTagTypeProps extends Omit<ButtonProps, 'onChange'> {
    value: string;
    onValueChange: (value: string) => void;
    forceMount?: boolean;
}
export declare const SelectTagType: React.ForwardRefExoticComponent<SelectTagTypeProps & React.RefAttributes<HTMLButtonElement>>;
export declare const SelectTagTypeCommand: ({ currentValue, handleSelectType, forceMount, }: {
    currentValue: string;
    handleSelectType: (contentType: string) => void;
    forceMount?: boolean;
}) => import("react/jsx-runtime").JSX.Element;
export {};
