import { Cell, ColumnDef } from '@tanstack/table-core';
import React from 'react';
import { ITag } from 'ui-modules/modules/tags/types/Tag';
import { TFunction } from 'i18next';
interface TagMoreColumnCellProps {
    cell: Cell<ITag, unknown>;
    tagType: string;
}
export declare const TagMoreColumnCell: React.FC<TagMoreColumnCellProps>;
export declare const createTagsColumns: (tagType: string, t: TFunction) => ColumnDef<ITag>[];
export {};
