export declare const TagsSettingFilter: () => import("react/jsx-runtime").JSX.Element;
