import { ITag } from 'ui-modules/index';
import React from 'react';
export declare const TagBadge: React.ForwardRefExoticComponent<Omit<import("erxes-ui").BadgeProps & React.RefAttributes<HTMLDivElement>, "ref"> & {
    tag?: ITag;
    tagId?: string;
    renderClose?: (tag: ITag) => React.ReactNode;
    onCompleted?: (tags: ITag) => void;
    renderAsPlainText?: boolean;
} & React.RefAttributes<HTMLDivElement>>;
