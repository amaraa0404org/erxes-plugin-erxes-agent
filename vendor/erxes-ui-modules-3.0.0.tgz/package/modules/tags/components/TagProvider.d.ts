interface ITagContext {
    mode: 'idle' | 'adding-tag' | 'adding-group' | 'adding-tag-to-group';
    targetGroupId: string | null;
    setMode: (mode: ITagContext['mode']) => void;
    startAddingTag: () => void;
    startAddingGroup: () => void;
    startAddingTagToGroup: (groupId: string) => void;
    cancel: () => void;
}
export declare const TagContext: import("react").Context<ITagContext>;
export declare const TagProvider: ({ children }: {
    children: React.ReactNode;
}) => import("react/jsx-runtime").JSX.Element;
export declare const useTagContext: () => ITagContext;
export {};
