import React from 'react';
interface TagsRecordTableProps {
    tagType: string;
}
export declare const TagsRecordTable: React.FC<TagsRecordTableProps>;
export {};
