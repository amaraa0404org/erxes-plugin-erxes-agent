export declare const CreateTagForm: () => import("react/jsx-runtime").JSX.Element;
export declare function SelectTagCreateContainer({ children, }: {
    children: React.ReactNode;
}): import("react/jsx-runtime").JSX.Element;
