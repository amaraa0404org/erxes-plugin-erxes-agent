export declare const TagsFilterView: ({ tagType }: {
    tagType?: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const TagsFilter: (() => import("react/jsx-runtime").JSX.Element) & {
    Bar: ({ tagType }: {
        tagType?: string;
    }) => import("react/jsx-runtime").JSX.Element | null;
    View: ({ tagType }: {
        tagType?: string;
    }) => import("react/jsx-runtime").JSX.Element;
};
