import { SelectTriggerVariant } from 'erxes-ui';
import React from 'react';
import { ISelectTagsProviderProps, ITag } from 'ui-modules/modules';
import { TagBadge } from './TagBadge';
export declare const SelectTagsProvider: ({ children, tagType, value, onValueChange, targetIds, options, mode, }: ISelectTagsProviderProps) => import("react/jsx-runtime").JSX.Element;
export declare const SelectTagGroupsCommand: ({ disableCreateOption, }: {
    disableCreateOption?: boolean;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectTagsCommand: ({ disableCreateOption, }: {
    disableCreateOption?: boolean;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectTagsCreate: ({ search, show, }: {
    search: string;
    show: boolean;
}) => import("react/jsx-runtime").JSX.Element | null;
export declare const SelectTagsItem: ({ tag, }: {
    tag: ITag & {
        hasChildren: boolean;
    };
}) => import("react/jsx-runtime").JSX.Element;
export declare const TagList: ({ placeholder, renderAsPlainText, ...props }: Omit<React.ComponentProps<typeof TagBadge>, "onClose"> & {
    placeholder?: string;
    renderAsPlainText?: boolean;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectTagsValue: ({ placeholder }: {
    placeholder?: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectTagsContent: () => import("react/jsx-runtime").JSX.Element;
export declare const SelectTagsInlineCell: ({ onValueChange, scope, ...props }: Omit<React.ComponentProps<typeof SelectTagsProvider>, "children"> & {
    scope?: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectTagsDetail: React.ForwardRefExoticComponent<Omit<ISelectTagsProviderProps, "children"> & Omit<Omit<Omit<import("erxes-ui").ButtonProps & React.RefAttributes<HTMLButtonElement>, "ref"> & {
    hideChevron?: boolean;
} & React.RefAttributes<HTMLButtonElement>, "ref">, "children"> & {
    scope?: string;
} & React.RefAttributes<HTMLButtonElement>>;
export declare const ConversationTagList: ({ renderAsPlainText, ...props }: Omit<React.ComponentProps<typeof TagBadge>, "onClose"> & {
    placeholder?: string;
    renderAsPlainText?: boolean;
}) => import("react/jsx-runtime").JSX.Element | null;
export declare const SelectTagsConversationDetail: React.ForwardRefExoticComponent<Omit<ISelectTagsProviderProps, "children"> & Omit<Omit<Omit<import("erxes-ui").ButtonProps & React.RefAttributes<HTMLButtonElement>, "ref"> & {
    hideChevron?: boolean;
} & React.RefAttributes<HTMLButtonElement>, "ref">, "children"> & {
    scope?: string;
} & React.RefAttributes<HTMLButtonElement>>;
export declare const SelectTagsFormItem: ({ onValueChange, scope, tagType, value, mode, }: {
    tagType?: string;
    scope?: string;
    onValueChange: (value: string | string[]) => void;
    value?: string | string[];
    mode?: "single" | "multiple";
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectTagsCommandbarItem: ({ onValueChange, ...props }: Omit<React.ComponentProps<typeof SelectTagsProvider>, "children">) => import("react/jsx-runtime").JSX.Element;
export declare const SelectTagsRoot: React.ForwardRefExoticComponent<Omit<ISelectTagsProviderProps, "children"> & Omit<Omit<Omit<import("erxes-ui").ButtonProps & React.RefAttributes<HTMLButtonElement>, "ref"> & {
    hideChevron?: boolean;
} & React.RefAttributes<HTMLButtonElement>, "ref">, "children"> & {
    scope?: string;
} & React.RefAttributes<HTMLButtonElement>>;
export declare const SelectTagsFilterItem: ({ value, label, }: {
    value: string;
    label: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectTagsFilterView: ({ mode, filterKey, tagType, }: {
    mode: "single" | "multiple";
    filterKey: string;
    tagType?: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectTagsFilterBar: ({ mode, filterKey, label, variant, scope, initialValue, onValueChange, tagType, }: {
    mode: "single" | "multiple";
    filterKey: string;
    label: string;
    variant?: `${SelectTriggerVariant}`;
    scope?: string;
    initialValue?: string[];
    tagType?: string;
    onValueChange?: (value: string[] | string) => void;
}) => import("react/jsx-runtime").JSX.Element | null;
export declare const SelectTags: React.ForwardRefExoticComponent<Omit<ISelectTagsProviderProps, "children"> & Omit<Omit<Omit<import("erxes-ui").ButtonProps & React.RefAttributes<HTMLButtonElement>, "ref"> & {
    hideChevron?: boolean;
} & React.RefAttributes<HTMLButtonElement>, "ref">, "children"> & {
    scope?: string;
} & React.RefAttributes<HTMLButtonElement>> & {
    Provider: ({ children, tagType, value, onValueChange, targetIds, options, mode, }: ISelectTagsProviderProps) => import("react/jsx-runtime").JSX.Element;
    CommandbarItem: ({ onValueChange, ...props }: Omit<React.ComponentProps<typeof SelectTagsProvider>, "children">) => import("react/jsx-runtime").JSX.Element;
    Content: () => import("react/jsx-runtime").JSX.Element;
    Command: ({ disableCreateOption, }: {
        disableCreateOption?: boolean;
    }) => import("react/jsx-runtime").JSX.Element;
    GroupsCommand: ({ disableCreateOption, }: {
        disableCreateOption?: boolean;
    }) => import("react/jsx-runtime").JSX.Element;
    Item: ({ tag, }: {
        tag: ITag & {
            hasChildren: boolean;
        };
    }) => import("react/jsx-runtime").JSX.Element;
    Value: ({ placeholder }: {
        placeholder?: string;
    }) => import("react/jsx-runtime").JSX.Element;
    List: ({ placeholder, renderAsPlainText, ...props }: Omit<React.ComponentProps<typeof TagBadge>, "onClose"> & {
        placeholder?: string;
        renderAsPlainText?: boolean;
    }) => import("react/jsx-runtime").JSX.Element;
    InlineCell: ({ onValueChange, scope, ...props }: Omit<React.ComponentProps<typeof SelectTagsProvider>, "children"> & {
        scope?: string;
    }) => import("react/jsx-runtime").JSX.Element;
    Detail: React.ForwardRefExoticComponent<Omit<ISelectTagsProviderProps, "children"> & Omit<Omit<Omit<import("erxes-ui").ButtonProps & React.RefAttributes<HTMLButtonElement>, "ref"> & {
        hideChevron?: boolean;
    } & React.RefAttributes<HTMLButtonElement>, "ref">, "children"> & {
        scope?: string;
    } & React.RefAttributes<HTMLButtonElement>>;
    ConversationDetail: React.ForwardRefExoticComponent<Omit<ISelectTagsProviderProps, "children"> & Omit<Omit<Omit<import("erxes-ui").ButtonProps & React.RefAttributes<HTMLButtonElement>, "ref"> & {
        hideChevron?: boolean;
    } & React.RefAttributes<HTMLButtonElement>, "ref">, "children"> & {
        scope?: string;
    } & React.RefAttributes<HTMLButtonElement>>;
    FormItem: ({ onValueChange, scope, tagType, value, mode, }: {
        tagType?: string;
        scope?: string;
        onValueChange: (value: string | string[]) => void;
        value?: string | string[];
        mode?: "single" | "multiple";
    }) => import("react/jsx-runtime").JSX.Element;
    FilterItem: ({ value, label, }: {
        value: string;
        label: string;
    }) => import("react/jsx-runtime").JSX.Element;
    FilterView: ({ mode, filterKey, tagType, }: {
        mode: "single" | "multiple";
        filterKey: string;
        tagType?: string;
    }) => import("react/jsx-runtime").JSX.Element;
    FilterBar: ({ mode, filterKey, label, variant, scope, initialValue, onValueChange, tagType, }: {
        mode: "single" | "multiple";
        filterKey: string;
        label: string;
        variant?: `${SelectTriggerVariant}`;
        scope?: string;
        initialValue?: string[];
        tagType?: string;
        onValueChange?: (value: string[] | string) => void;
    }) => import("react/jsx-runtime").JSX.Element | null;
};
