export declare const ADD_TAG: import("@apollo/client").DocumentNode;
export declare const GIVE_TAGS: import("@apollo/client").DocumentNode;
