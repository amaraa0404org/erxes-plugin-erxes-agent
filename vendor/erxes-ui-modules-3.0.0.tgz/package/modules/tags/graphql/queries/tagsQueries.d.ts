export declare const TAGS_QUERY: import("@apollo/client").DocumentNode;
export declare const TAG_BADGE_QUERY: import("@apollo/client").DocumentNode;
export declare const TAGS_TYPES: import("@apollo/client").DocumentNode;
