import { ISelectTagsContext } from '../types/Tag';
export declare const SelectTagsContext: import("react").Context<ISelectTagsContext | null>;
