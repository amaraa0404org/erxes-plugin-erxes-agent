export declare const ATTRIBUTE_QUERY: import("graphql").DocumentNode;
export declare const PROCESS_DOCUMENT: import("graphql").DocumentNode;
export declare const DOCUMENT_DETAIL: import("graphql").DocumentNode;
export declare const DOCUMENTS_QUERY: import("graphql").DocumentNode;
