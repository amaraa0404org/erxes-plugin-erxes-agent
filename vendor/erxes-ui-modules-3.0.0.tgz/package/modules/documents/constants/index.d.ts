export declare const PAPER_TYPES: {
    readonly SHEET: "sheet";
    readonly ROLL: "roll";
};
export type PaperType = (typeof PAPER_TYPES)[keyof typeof PAPER_TYPES];
export declare const PAPER_SIZES: Record<string, {
    width: number;
    height: number;
    label: string;
    margin: number;
    type: PaperType;
}>;
export declare const PX_PER_MM: number;
