export interface IDocumentsInlineContext {
    documents: any[];
    loading: boolean;
    documentIds?: string[];
    placeholder: string;
    updateDocuments?: (documents: any[]) => void;
}
export declare const DocumentsInlineContext: import("react").Context<IDocumentsInlineContext | null>;
export declare const useDocumentsInlineContext: () => IDocumentsInlineContext;
