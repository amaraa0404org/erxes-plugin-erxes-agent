export type ISelectDocumentContext = {
    documentIds: string[];
    documents: any[];
    contentType?: string;
    setDocuments: (documents: any[]) => void;
    onSelect: (document: any) => void;
    loading: boolean;
    error: string | null;
};
export declare const SelectDocumentContext: import("react").Context<ISelectDocumentContext | null>;
export declare const useSelectDocumentContext: () => ISelectDocumentContext;
