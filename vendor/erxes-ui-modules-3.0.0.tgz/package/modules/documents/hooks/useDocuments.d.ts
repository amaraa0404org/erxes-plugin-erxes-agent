import { QueryHookOptions } from '@apollo/client';
import { ICursorListResponse } from 'erxes-ui';
export declare const useDocuments: (options?: QueryHookOptions<ICursorListResponse<any>>) => {
    documents: any[] | undefined;
    loading: boolean;
    error: import("@apollo/client").ApolloError | undefined;
    handleFetchMore: () => void;
    totalCount: number | undefined;
};
