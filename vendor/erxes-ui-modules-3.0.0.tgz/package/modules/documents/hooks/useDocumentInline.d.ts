import { QueryHookOptions } from '@apollo/client';
export interface IDocumentInline {
    _id: string;
    name: string;
}
export interface IDocumentInlineQuery {
    documentsDetail: IDocumentInline;
}
export declare const useDocumentInline: (options?: QueryHookOptions<IDocumentInlineQuery>) => {
    document: IDocumentInline | undefined;
    loading: boolean;
    error: import("@apollo/client").ApolloError | undefined;
};
