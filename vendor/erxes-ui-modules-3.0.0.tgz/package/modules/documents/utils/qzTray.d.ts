export declare const isQzActive: () => boolean;
export declare const connectQz: () => Promise<void>;
export declare const ensureQzConnected: () => Promise<boolean>;
export declare const findQzPrinters: () => Promise<string[]>;
export declare const printPagesToQz: ({ printer, pages, }: {
    printer: string;
    pages: string[];
}) => Promise<void>;
export declare const QZ_NOT_RUNNING_MESSAGE = "QZ Tray is not running. Falling back to the browser print dialog.";
