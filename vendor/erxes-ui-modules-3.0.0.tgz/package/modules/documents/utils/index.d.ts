export declare const PAGE_STYLE_ID = "erxes-page-size";
export declare const paper: (size: string, orientation: "portrait" | "landscape") => {
    width: number;
    height: number;
} | {
    width: number;
    height: number;
};
export declare const resolveSize: (config: any) => {
    type: import("ui-modules/modules/documents/constants").PaperType;
    width: number;
    height: number;
    isContinuous: boolean;
};
export declare const buildLayoutHtml: (document: string, config: any) => string;
export declare const syncPageHeight: (iframe: HTMLIFrameElement, config: any) => number;
export declare const waitForImages: (iframe: HTMLIFrameElement) => Promise<void>;
export declare const transformLabels: (iframe: HTMLIFrameElement, config: any) => void;
export declare const buildLabelPages: (iframe: HTMLIFrameElement, config: any) => string[];
export declare const layout: (document: string, config: any, iframe: HTMLIFrameElement) => void;
