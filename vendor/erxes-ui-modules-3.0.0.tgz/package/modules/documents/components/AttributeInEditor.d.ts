import { IBlockEditor } from 'erxes-ui';
interface Attribute {
    label?: string;
    name: string;
    value?: any;
    groupDetail?: {
        name: string;
    };
}
interface AttributeInEditorProps {
    editor: IBlockEditor;
    attributes?: Attribute[];
    loading?: boolean;
}
interface AttributeMenuWrapperProps extends AttributeInEditorProps {
    contentType?: string;
}
declare const AttributeMenuWrapper: (props: AttributeMenuWrapperProps) => import("react/jsx-runtime").JSX.Element;
export { AttributeMenuWrapper as AttributeInEditor };
