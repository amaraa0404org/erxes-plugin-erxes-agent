import { Sheet } from 'erxes-ui';
import { ReactNode } from 'react';
import { PrintItem } from 'ui-modules/modules/documents/types/print';
export declare const PrintSheet: ({ children, trigger, ...props }: React.ComponentProps<typeof Sheet> & {
    children?: ReactNode;
    trigger?: ReactNode | null;
}) => import("react/jsx-runtime").JSX.Element;
export declare const PrintDocument: ({ items, contentType, document, open, onOpenChange, trigger, }: {
    items: PrintItem[];
    contentType: string;
    document?: {
        _id: string;
        name?: string;
    };
    open?: boolean;
    onOpenChange?: (open: boolean) => void;
    trigger?: ReactNode | null;
}) => import("react/jsx-runtime").JSX.Element;
