import { RefObject } from 'react';
export declare const PrintPreview: ({ iframeRef, }: {
    iframeRef: RefObject<HTMLIFrameElement>;
}) => import("react/jsx-runtime").JSX.Element;
