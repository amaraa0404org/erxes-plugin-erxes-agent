export declare const PrintSettings: ({ contentType, initialDocumentName, }: {
    contentType: string;
    initialDocumentName?: string;
}) => import("react/jsx-runtime").JSX.Element;
