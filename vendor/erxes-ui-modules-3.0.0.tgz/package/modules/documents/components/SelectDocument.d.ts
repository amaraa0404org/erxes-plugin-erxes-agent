import React from 'react';
export declare const SelectDocumentProvider: ({ children, mode, value, onValueChange, documents, contentType, }: {
    children: React.ReactNode;
    mode?: "single" | "multiple";
    value?: string[] | string;
    onValueChange: (value: string[] | string, meta: any) => void;
    documents?: any[];
    contentType?: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectDocumentFilterItem: () => import("react/jsx-runtime").JSX.Element;
export declare const SelectDocumentFilterView: ({ onValueChange, queryKey, mode, contentType, }: {
    onValueChange?: (value: string[] | string) => void;
    queryKey?: string;
    mode?: "single" | "multiple";
    contentType: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectDocumentFilterBar: ({ iconOnly, onValueChange, queryKey, mode, contentType, }: {
    iconOnly?: boolean;
    onValueChange?: (value: string[] | string) => void;
    queryKey?: string;
    mode?: "single" | "multiple";
    contentType: string;
}) => import("react/jsx-runtime").JSX.Element | null;
export declare const SelectDocumentInlineCell: ({ onValueChange, scope, ...props }: Omit<React.ComponentProps<typeof SelectDocumentProvider>, "children"> & {
    scope?: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectDocumentFormItem: {
    ({ onValueChange, className, placeholder, ...props }: Omit<React.ComponentProps<typeof SelectDocumentProvider>, "children"> & {
        className?: string;
        placeholder?: string;
    }): import("react/jsx-runtime").JSX.Element;
    displayName: string;
};
export declare const SelectDocument: React.ForwardRefExoticComponent<Omit<Omit<{
    children: React.ReactNode;
    mode?: "single" | "multiple";
    value?: string[] | string;
    onValueChange: (value: string[] | string, meta: any) => void;
    documents?: any[];
    contentType?: string;
}, "children"> & Omit<import("erxes-ui").ButtonProps & React.RefAttributes<HTMLButtonElement>, "ref"> & {
    hideChevron?: boolean;
} & React.RefAttributes<HTMLButtonElement> & {
    placeholder?: string;
}, "ref"> & React.RefAttributes<HTMLButtonElement>> & {
    Provider: ({ children, mode, value, onValueChange, documents, contentType, }: {
        children: React.ReactNode;
        mode?: "single" | "multiple";
        value?: string[] | string;
        onValueChange: (value: string[] | string, meta: any) => void;
        documents?: any[];
        contentType?: string;
    }) => import("react/jsx-runtime").JSX.Element;
    Value: ({ placeholder }: {
        placeholder?: string;
    }) => import("react/jsx-runtime").JSX.Element;
    Content: () => import("react/jsx-runtime").JSX.Element;
    FilterItem: () => import("react/jsx-runtime").JSX.Element;
    FilterView: ({ onValueChange, queryKey, mode, contentType, }: {
        onValueChange?: (value: string[] | string) => void;
        queryKey?: string;
        mode?: "single" | "multiple";
        contentType: string;
    }) => import("react/jsx-runtime").JSX.Element;
    FilterBar: ({ iconOnly, onValueChange, queryKey, mode, contentType, }: {
        iconOnly?: boolean;
        onValueChange?: (value: string[] | string) => void;
        queryKey?: string;
        mode?: "single" | "multiple";
        contentType: string;
    }) => import("react/jsx-runtime").JSX.Element | null;
    InlineCell: ({ onValueChange, scope, ...props }: Omit<React.ComponentProps<typeof SelectDocumentProvider>, "children"> & {
        scope?: string;
    }) => import("react/jsx-runtime").JSX.Element;
    FormItem: {
        ({ onValueChange, className, placeholder, ...props }: Omit<React.ComponentProps<typeof SelectDocumentProvider>, "children"> & {
            className?: string;
            placeholder?: string;
        }): import("react/jsx-runtime").JSX.Element;
        displayName: string;
    };
};
