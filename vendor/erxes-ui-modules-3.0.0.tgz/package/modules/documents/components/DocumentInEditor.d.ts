import { IBlockEditor } from 'erxes-ui';
interface DocumentInEditorProps {
    editor: IBlockEditor;
    documents?: any;
    loading?: boolean;
    handleFetchMore?: () => void;
}
interface DocumentMenuWrapperProps extends DocumentInEditorProps {
    contentType?: string;
}
declare const DocumentMenuWrapper: (props: DocumentMenuWrapperProps) => import("react/jsx-runtime").JSX.Element;
export { DocumentMenuWrapper as DocumentInEditor };
