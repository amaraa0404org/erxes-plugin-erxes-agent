import { ReactNode } from 'react';
export type Document = {
    _id: string;
    name: string;
};
interface DocumentsInlineProviderProps {
    children?: ReactNode;
    documentIds?: string[];
    documents?: Document[];
    placeholder?: string;
    updateDocuments?: (documents: Document[]) => void;
}
export declare const DocumentsInline: ((props: DocumentsInlineProviderProps) => import("react/jsx-runtime").JSX.Element) & {
    Provider: ({ children, documentIds, documents, placeholder, updateDocuments, }: DocumentsInlineProviderProps) => import("react/jsx-runtime").JSX.Element;
    Title: () => import("react/jsx-runtime").JSX.Element;
};
export {};
