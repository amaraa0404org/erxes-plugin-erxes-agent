export type CardDetailBadgeItem = {
    _id?: string;
    name: string;
    colorCode?: string;
};
type CardDetailBadgesProps = {
    items: CardDetailBadgeItem[];
    color: string;
    maxVisibleItems: number;
    onOverflowClick?: () => void;
};
export declare const CardDetailBadges: ({ items, color, maxVisibleItems, onOverflowClick, }: CardDetailBadgesProps) => import("react/jsx-runtime").JSX.Element | null;
export {};
