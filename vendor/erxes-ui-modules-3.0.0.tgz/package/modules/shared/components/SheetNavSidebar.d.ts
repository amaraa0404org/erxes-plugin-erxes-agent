export declare function SheetNavSidebar({ tabs, groupLabel, labels, }: {
    tabs: string[];
    groupLabel: string;
    labels?: Record<string, string>;
}): import("react/jsx-runtime").JSX.Element;
