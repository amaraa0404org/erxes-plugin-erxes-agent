export declare const GET_CUSTOMERS: import("@apollo/client").DocumentNode;
