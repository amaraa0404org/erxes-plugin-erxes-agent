export declare const CUSTOMER_DETAIL: import("@apollo/client").DocumentNode;
export declare const CUSTOMER_INLINE: import("@apollo/client").DocumentNode;
