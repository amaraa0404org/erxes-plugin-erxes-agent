export declare const EBARIMT_GET_COMPANY: import("@apollo/client").DocumentNode;
