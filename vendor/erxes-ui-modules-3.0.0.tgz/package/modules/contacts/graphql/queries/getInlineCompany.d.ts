export declare const COMPANY_INLINE: import("@apollo/client").DocumentNode;
