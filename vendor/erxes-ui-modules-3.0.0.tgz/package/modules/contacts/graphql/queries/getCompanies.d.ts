export declare const GET_COMPANIES: import("@apollo/client").DocumentNode;
export declare const GET_ASSIGNED_COMPANIES: import("@apollo/client").DocumentNode;
