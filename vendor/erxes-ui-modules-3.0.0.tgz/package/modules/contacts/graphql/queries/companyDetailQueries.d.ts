export declare const COMPANY_DETAIL: import("@apollo/client").DocumentNode;
export declare const COMPANY_INLINE: import("@apollo/client").DocumentNode;
