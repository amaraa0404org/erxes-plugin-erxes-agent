export declare const CUSTOMERS_ADD: import("@apollo/client").DocumentNode;
