export declare const EDIT_COMPANIES: import("@apollo/client").DocumentNode;
