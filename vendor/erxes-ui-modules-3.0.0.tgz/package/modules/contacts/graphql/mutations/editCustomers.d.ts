export declare const EDIT_CUSTOMERS: import("@apollo/client").DocumentNode;
