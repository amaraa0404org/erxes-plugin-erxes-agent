export declare const COMPANIES_ADD: import("@apollo/client").DocumentNode;
