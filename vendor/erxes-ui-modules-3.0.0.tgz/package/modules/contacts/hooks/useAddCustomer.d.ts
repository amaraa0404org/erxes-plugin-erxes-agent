import { MutationHookOptions } from '@apollo/client';
export declare function useAddCustomer(options?: MutationHookOptions<{
    customersAdd: {
        _id: string;
    };
}>): {
    customersAdd: (options?: import("@apollo/client").MutationFunctionOptions<{
        customersAdd: {
            _id: string;
        };
    }, import("@apollo/client").OperationVariables, import("@apollo/client").DefaultContext, import("@apollo/client").ApolloCache<any>> | undefined) => Promise<import("@apollo/client").FetchResult<{
        customersAdd: {
            _id: string;
        };
    }>>;
    loading: boolean;
    error: import("@apollo/client").ApolloError | undefined;
};
