import { QueryHookOptions } from '@apollo/client';
import { ICompany } from '../types';
export declare const useCompanyDetail: (options: QueryHookOptions<{
    companyDetail: ICompany;
}>, inline?: boolean) => {
    loading: boolean;
    companyDetail: ICompany | undefined;
    error: import("@apollo/client").ApolloError | undefined;
};
