import { OperationVariables } from '@apollo/client';
import { ICompany } from '../types';
export declare const useCompanies: (options?: OperationVariables) => {
    companies: ICompany[];
    loading: boolean;
    handleFetchMore: () => void;
    totalCount: number;
    error: import("@apollo/client").ApolloError | undefined;
};
export declare const useCompaniesInline: (options?: OperationVariables) => {
    companies: ICompany[];
    loading: boolean;
    error: import("@apollo/client").ApolloError | undefined;
};
