export declare const isLookupableRegister: (value?: string) => boolean;
export declare const useCompanyNameByRegister: (register?: string) => {
    companyName: string | undefined;
    loading: boolean;
};
