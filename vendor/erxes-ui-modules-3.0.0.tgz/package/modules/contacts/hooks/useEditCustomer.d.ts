import { MutationHookOptions } from '@apollo/client';
import { ICustomer } from '../types';
export declare const useCustomerEdit: () => {
    customerEdit: ({ variables, onError, ...options }: MutationHookOptions<{
        customersEdit: {
            _id: string;
        };
    }, Partial<ICustomer>>) => void;
    loading: boolean;
};
