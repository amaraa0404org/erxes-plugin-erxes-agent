import { QueryHookOptions } from '@apollo/client';
import { ICompany } from '../types';
export declare const useCompanyInline: (options: QueryHookOptions<{
    companyDetail: ICompany;
}, {
    _id: string;
}>) => {
    loading: boolean;
    companyDetail: ICompany | undefined;
};
