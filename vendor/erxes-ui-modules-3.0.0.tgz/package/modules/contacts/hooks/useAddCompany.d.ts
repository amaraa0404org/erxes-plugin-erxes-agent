import { MutationHookOptions } from '@apollo/client';
import { ICompany } from '../types';
type AddCompanyResult = {
    companiesAdd: ICompany;
};
export declare function useAddCompany(options?: MutationHookOptions<AddCompanyResult>): {
    companiesAdd: (options?: import("@apollo/client").MutationFunctionOptions<AddCompanyResult, import("@apollo/client").OperationVariables, import("@apollo/client").DefaultContext, import("@apollo/client").ApolloCache<any>> | undefined) => Promise<import("@apollo/client").FetchResult<AddCompanyResult>>;
    loading: boolean;
    error: import("@apollo/client").ApolloError | undefined;
};
export {};
