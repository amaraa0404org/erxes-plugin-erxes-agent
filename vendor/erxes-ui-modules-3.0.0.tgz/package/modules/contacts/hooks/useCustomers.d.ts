import { QueryHookOptions } from '@apollo/client';
import { ICustomer } from '../types';
import { ICursorListResponse } from 'erxes-ui';
export declare const useCustomers: (options?: QueryHookOptions<ICursorListResponse<ICustomer>>) => {
    customers: ICustomer[];
    loading: boolean;
    handleFetchMore: () => void;
    totalCount: number;
    error: import("@apollo/client").ApolloError | undefined;
};
export declare const useCustomerInline: (options?: QueryHookOptions<{
    customerDetail: ICustomer;
}>) => {
    customer: ICustomer | undefined;
    loading: boolean;
    error: import("@apollo/client").ApolloError | undefined;
};
