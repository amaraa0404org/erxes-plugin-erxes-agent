import { QueryHookOptions } from '@apollo/client';
import { ICustomerDetail } from '../types';
export declare const useCustomerDetail: (options: QueryHookOptions<{
    customerDetail: ICustomerDetail;
}>, inline?: boolean) => {
    loading: boolean;
    customerDetail: ICustomerDetail | undefined;
    error: import("@apollo/client").ApolloError | undefined;
};
