import { MutationHookOptions } from '@apollo/client';
import { ICompany } from '../types';
export declare const useCompaniesEdit: () => {
    companiesEdit: ({ variables, onError, ...options }: MutationHookOptions<{
        companiesEdit: ICompany;
    }, ICompany>) => Promise<import("@apollo/client").FetchResult<any>>;
    loading: boolean;
};
