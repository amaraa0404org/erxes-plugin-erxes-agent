import { ICompany } from '../types';
interface CompaniesInlineContextType {
    companies: ICompany[];
    loading: boolean;
    placeholder?: string;
    updateCompanies?: (companies: ICompany[]) => void;
    companyIds?: string[];
    hideAvatar?: boolean;
}
export declare const CompaniesInlineContext: import("react").Context<CompaniesInlineContextType | null>;
export declare const useCompaniesInlineContext: () => CompaniesInlineContextType;
export {};
