import { ICompany } from '../types';
export type ISelectCompanyContext = {
    companyIds: string[];
    onSelect: (company: ICompany) => void;
    companies: ICompany[];
    setCompanies: (companies: ICompany[]) => void;
    loading: boolean;
    error: string | null;
    hideAvatar?: boolean;
    mode: 'single' | 'multiple';
    openCreate: () => void;
};
export declare const SelectCompanyContext: import("react").Context<ISelectCompanyContext | null>;
export declare const useSelectCompanyContext: () => ISelectCompanyContext;
