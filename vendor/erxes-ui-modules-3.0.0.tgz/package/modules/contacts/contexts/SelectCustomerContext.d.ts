import { ICustomer } from '../types';
export type ISelectCustomerContext = {
    customerIds: string[];
    onSelect: (customer: ICustomer) => void;
    customers: ICustomer[];
    setCustomers: (customers: ICustomer[]) => void;
    loading: boolean;
    error: string | null;
    hideAvatar?: boolean;
    mode: 'single' | 'multiple';
    openCreate: () => void;
};
export declare const SelectCustomerContext: import("react").Context<ISelectCustomerContext | null>;
