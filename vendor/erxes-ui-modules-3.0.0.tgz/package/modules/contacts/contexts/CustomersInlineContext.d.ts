import { ICustomer } from '../types';
export interface ICustomersInlineContext {
    customers?: ICustomer[];
    loading: boolean;
    customerIds?: string[];
    placeholder: string;
    updateCustomers?: (customers: ICustomer[]) => void;
    getCustomerTitle: (customer?: ICustomer) => string;
    hideAvatar?: boolean;
}
export declare const CustomersInlineContext: import("react").Context<ICustomersInlineContext | null>;
export declare const useCustomersInlineContext: () => ICustomersInlineContext;
