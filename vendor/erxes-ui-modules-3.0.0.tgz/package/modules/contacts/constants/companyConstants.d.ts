export declare const COMPANY_BUSINESS_TYPES: string[];
export declare const DEFAULT_COMPANY_INDUSTRY_TYPES: string[];
