export declare const AddCustomer: ({ children, state, onSuccess, open, onOpenChange, }: {
    children?: React.ReactNode;
    state?: "lead" | "customer";
    onSuccess?: (id: string) => void;
    open?: boolean;
    onOpenChange?: (open: boolean) => void;
}) => import("react/jsx-runtime").JSX.Element;
