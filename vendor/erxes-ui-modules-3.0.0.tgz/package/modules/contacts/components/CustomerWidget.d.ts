import { IRelationWidgetProps } from 'ui-modules/modules/widget';
export declare const CustomerWidget: ({ customerIds, scope, onManageCustomers, access, }: {
    customerIds: string[];
    scope: string;
    onManageCustomers?: (customerIds: string[]) => void;
    access: IRelationWidgetProps["access"];
}) => import("react/jsx-runtime").JSX.Element;
export declare const CustomerWidgetTrigger: () => import("react/jsx-runtime").JSX.Element;
