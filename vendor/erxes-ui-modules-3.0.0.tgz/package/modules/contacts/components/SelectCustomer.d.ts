import { SelectTriggerVariant } from 'erxes-ui';
import { ICustomer } from '../types';
interface SelectCustomerProviderProps {
    children: React.ReactNode;
    value?: string[] | string;
    onValueChange?: (value: string[] | string) => void;
    mode?: 'single' | 'multiple';
    hideAvatar?: boolean;
    loadSelectedCustomers?: boolean;
}
declare const SelectCustomerProvider: ({ children, value, onValueChange, mode, hideAvatar, loadSelectedCustomers, }: SelectCustomerProviderProps) => import("react/jsx-runtime").JSX.Element;
export declare const SelectCustomerFilterItem: ({ value, label, }: {
    value: string;
    label: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectCustomerFilterView: ({ mode, filterKey, }: {
    mode?: "single" | "multiple";
    filterKey: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectCustomerFilterBar: ({ mode, filterKey, label, variant, scope, initialValue, value, onValueChange, hideAvatar, }: {
    mode?: "single" | "multiple";
    filterKey: string;
    label: string;
    variant?: `${SelectTriggerVariant}`;
    scope?: string;
    initialValue?: string[];
    value?: string[];
    hideAvatar?: boolean;
    onValueChange?: (value: string[] | string) => void;
}) => import("react/jsx-runtime").JSX.Element | null;
export declare const SelectCustomer: (({ onValueChange, className, mode, ...props }: Omit<React.ComponentProps<typeof SelectCustomerProvider>, "children"> & {
    className?: string;
}) => import("react/jsx-runtime").JSX.Element) & {
    Provider: ({ children, value, onValueChange, mode, hideAvatar, loadSelectedCustomers, }: SelectCustomerProviderProps) => import("react/jsx-runtime").JSX.Element;
    Content: () => import("react/jsx-runtime").JSX.Element;
    Item: ({ customer }: {
        customer: ICustomer;
    }) => import("react/jsx-runtime").JSX.Element;
    InlineCell: ({ onValueChange, scope, ...props }: Omit<React.ComponentProps<typeof SelectCustomerProvider>, "children"> & {
        scope?: string;
    }) => import("react/jsx-runtime").JSX.Element;
    Value: ({ placeholder }: {
        placeholder?: string;
    }) => import("react/jsx-runtime").JSX.Element;
    FormItem: ({ onValueChange, className, ...props }: Omit<React.ComponentProps<typeof SelectCustomerProvider>, "children"> & {
        className?: string;
    }) => import("react/jsx-runtime").JSX.Element;
    FilterItem: ({ value, label, }: {
        value: string;
        label: string;
    }) => import("react/jsx-runtime").JSX.Element;
    FilterView: ({ mode, filterKey, }: {
        mode?: "single" | "multiple";
        filterKey: string;
    }) => import("react/jsx-runtime").JSX.Element;
    FilterBar: ({ mode, filterKey, label, variant, scope, initialValue, value, onValueChange, hideAvatar, }: {
        mode?: "single" | "multiple";
        filterKey: string;
        label: string;
        variant?: `${SelectTriggerVariant}`;
        scope?: string;
        initialValue?: string[];
        value?: string[];
        hideAvatar?: boolean;
        onValueChange?: (value: string[] | string) => void;
    }) => import("react/jsx-runtime").JSX.Element | null;
};
export {};
