import { type ValidationStatus } from 'erxes-ui';
interface CustomerPhonesProps {
    _id: string;
    primaryPhone: string;
    phones: string[];
    phoneValidationStatus?: `${ValidationStatus}`;
    scope?: string;
    Trigger: React.ComponentType<{
        children: React.ReactNode;
    }>;
}
export declare function CustomerPhones({ _id, primaryPhone, phones: _phones, phoneValidationStatus, scope, Trigger, }: CustomerPhonesProps): import("react/jsx-runtime").JSX.Element;
export {};
