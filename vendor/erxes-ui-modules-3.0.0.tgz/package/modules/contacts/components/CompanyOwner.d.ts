export declare const CompanyOwner: ({ _id, ownerId, scope, inTable, }: {
    _id: string;
    ownerId?: string;
    scope?: string;
    inTable?: boolean;
}) => import("react/jsx-runtime").JSX.Element;
