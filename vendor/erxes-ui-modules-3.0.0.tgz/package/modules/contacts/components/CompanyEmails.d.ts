import { ValidationStatus } from 'erxes-ui';
export declare const CompanyEmails: ({ primaryEmail, _id, emails, emailValidationStatus, scope, Trigger, }: {
    primaryEmail: string;
    _id: string;
    emails: string[];
    emailValidationStatus?: ValidationStatus;
    scope?: string;
    Trigger: React.ComponentType<{
        children: React.ReactNode;
    }>;
}) => import("react/jsx-runtime").JSX.Element;
