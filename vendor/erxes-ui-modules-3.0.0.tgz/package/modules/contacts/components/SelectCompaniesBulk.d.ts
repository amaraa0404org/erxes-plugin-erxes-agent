import { ICompany } from '../types/Company';
interface SelectCompaniesProps {
    onSelect: (companyIds: string[], companies?: ICompany[]) => void;
    children: React.ReactNode;
    companyIds?: string[];
}
export declare const SelectCompaniesBulk: ({ onSelect, children, companyIds, }: SelectCompaniesProps) => import("react/jsx-runtime").JSX.Element;
export {};
