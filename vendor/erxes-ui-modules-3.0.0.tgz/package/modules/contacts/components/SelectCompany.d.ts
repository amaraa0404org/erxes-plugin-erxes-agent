import { SelectTriggerVariant } from 'erxes-ui';
import { ICompany } from '../types';
interface SelectCompanyProviderProps {
    children: React.ReactNode;
    value?: string[] | string;
    onValueChange?: (value: string[] | string) => void;
    mode?: 'single' | 'multiple';
    hideAvatar?: boolean;
}
declare const SelectCompanyProvider: ({ children, value, onValueChange, mode, hideAvatar, }: SelectCompanyProviderProps) => import("react/jsx-runtime").JSX.Element;
export declare const SelectCompanyFilterItem: ({ value, label, }: {
    value: string;
    label: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectCompanyFilterView: ({ mode, filterKey, }: {
    mode: "single" | "multiple";
    filterKey: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectCompanyFilterBar: ({ mode, filterKey, label, variant, scope, targetId, initialValue, value, onValueChange, hideAvatar, cursorKey, }: {
    mode?: "single" | "multiple";
    filterKey: string;
    label: string;
    variant?: `${SelectTriggerVariant}`;
    scope?: string;
    targetId?: string;
    initialValue?: string[];
    value?: string[];
    hideAvatar?: boolean;
    onValueChange?: (value: string[] | string) => void;
    cursorKey?: string;
}) => import("react/jsx-runtime").JSX.Element | null;
export declare const SelectCompany: (({ onValueChange, className, mode, ...props }: Omit<React.ComponentProps<typeof SelectCompanyProvider>, "children"> & {
    className?: string;
}) => import("react/jsx-runtime").JSX.Element) & {
    Provider: ({ children, value, onValueChange, mode, hideAvatar, }: SelectCompanyProviderProps) => import("react/jsx-runtime").JSX.Element;
    Content: () => import("react/jsx-runtime").JSX.Element;
    Item: ({ company }: {
        company: ICompany;
    }) => import("react/jsx-runtime").JSX.Element;
    InlineCell: ({ onValueChange, scope, ...props }: Omit<React.ComponentProps<typeof SelectCompanyProvider>, "children"> & {
        scope?: string;
    }) => import("react/jsx-runtime").JSX.Element;
    Value: ({ placeholder }: {
        placeholder?: string;
    }) => import("react/jsx-runtime").JSX.Element;
    Badges: () => import("react/jsx-runtime").JSX.Element;
    Detail: ({ onValueChange, className, mode, ...props }: Omit<React.ComponentProps<typeof SelectCompanyProvider>, "children"> & {
        className?: string;
    }) => import("react/jsx-runtime").JSX.Element;
    FilterItem: ({ value, label, }: {
        value: string;
        label: string;
    }) => import("react/jsx-runtime").JSX.Element;
    FilterView: ({ mode, filterKey, }: {
        mode: "single" | "multiple";
        filterKey: string;
    }) => import("react/jsx-runtime").JSX.Element;
    FilterBar: ({ mode, filterKey, label, variant, scope, targetId, initialValue, value, onValueChange, hideAvatar, cursorKey, }: {
        mode?: "single" | "multiple";
        filterKey: string;
        label: string;
        variant?: `${SelectTriggerVariant}`;
        scope?: string;
        targetId?: string;
        initialValue?: string[];
        value?: string[];
        hideAvatar?: boolean;
        onValueChange?: (value: string[] | string) => void;
        cursorKey?: string;
    }) => import("react/jsx-runtime").JSX.Element | null;
};
export {};
