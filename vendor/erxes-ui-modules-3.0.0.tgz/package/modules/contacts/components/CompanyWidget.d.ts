interface CompanyWidgetProps {
    companyIds: string[];
    scope: string;
    onManageCompanies?: (companyIds: string[]) => void;
}
export declare const CompanyWidget: ({ companyIds, scope, onManageCompanies, }: CompanyWidgetProps) => import("react/jsx-runtime").JSX.Element;
export declare const CompanyWidgetTrigger: () => import("react/jsx-runtime").JSX.Element;
export {};
