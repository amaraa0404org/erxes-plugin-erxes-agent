export declare function AddCustomerForm({ onOpenChange, state, onSuccess, }: Readonly<{
    onOpenChange: (open: boolean) => void;
    state?: 'lead' | 'customer';
    onSuccess?: (id: string) => void;
}>): import("react/jsx-runtime").JSX.Element;
