import { type ValidationStatus } from 'erxes-ui';
interface CompanyPhonesProps {
    _id: string;
    primaryPhone: string;
    phones: string[];
    phoneValidationStatus?: ValidationStatus;
    scope?: string;
    Trigger: React.ComponentType<{
        children: React.ReactNode;
    }>;
}
export declare function CompanyPhones({ _id, primaryPhone, phones: _phones, phoneValidationStatus, scope, Trigger, }: CompanyPhonesProps): import("react/jsx-runtime").JSX.Element;
export {};
