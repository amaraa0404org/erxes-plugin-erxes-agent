export declare const CompanyName: ({ _id, primaryName, displayName, scope, children, }: {
    _id: string;
    primaryName: string;
    displayName?: string;
    scope?: string;
    children?: React.ReactNode;
}) => import("react/jsx-runtime").JSX.Element;
