import { ICompany } from '../types';
export declare const AddCompany: ({ children, onSuccess, open, onOpenChange, }: {
    children?: React.ReactNode;
    onSuccess?: (id: string, company?: ICompany) => void;
    open?: boolean;
    onOpenChange?: (open: boolean) => void;
}) => import("react/jsx-runtime").JSX.Element;
