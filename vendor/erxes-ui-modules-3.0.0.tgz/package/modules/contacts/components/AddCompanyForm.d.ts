import { ICompany } from '../types';
export declare function AddCompanyForm({ onOpenChange, onSuccess, }: Readonly<{
    onOpenChange: (open: boolean) => void;
    onSuccess?: (id: string, company?: ICompany) => void;
}>): import("react/jsx-runtime").JSX.Element;
