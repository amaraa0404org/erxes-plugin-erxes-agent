export declare const CustomerName: ({ _id, firstName, lastName, scope, children, }: {
    _id?: string;
    firstName?: string;
    lastName?: string;
    scope: string;
    children?: React.ReactNode;
}) => import("react/jsx-runtime").JSX.Element;
