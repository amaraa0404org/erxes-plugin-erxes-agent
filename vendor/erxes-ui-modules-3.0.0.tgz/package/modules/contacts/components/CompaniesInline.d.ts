import { AvatarProps } from 'erxes-ui';
import { ICompany } from '../types';
interface CompaniesInlineProviderProps {
    children: React.ReactNode;
    companyIds?: string[];
    companies?: ICompany[];
    placeholder?: string;
    hideAvatar?: boolean;
    updateCompanies?: (companies: ICompany[]) => void;
}
export declare const CompaniesInline: (({ companyIds, companies, placeholder, updateCompanies, hideAvatar, }: Omit<CompaniesInlineProviderProps, "children">) => import("react/jsx-runtime").JSX.Element) & {
    Provider: ({ children, placeholder, companyIds, companies, hideAvatar, updateCompanies, }: CompaniesInlineProviderProps) => import("react/jsx-runtime").JSX.Element;
    Avatar: {
        ({ className, ...props }: AvatarProps): import("react/jsx-runtime").JSX.Element | null;
        displayName: string;
    };
    Title: {
        (): import("react/jsx-runtime").JSX.Element;
        displayName: string;
    };
    Badges: {
        ({ companyIds, companies, placeholder, updateCompanies, badgeClassName, badgeVariant, }: Omit<CompaniesInlineProviderProps, "children"> & {
            badgeClassName?: string;
            badgeVariant?: "default" | "destructive" | "secondary" | "success" | "warning";
        }): import("react/jsx-runtime").JSX.Element;
        displayName: string;
    };
    WithoutAvatar: {
        ({ companyIds, companies, placeholder, updateCompanies, }: Omit<CompaniesInlineProviderProps, "children">): import("react/jsx-runtime").JSX.Element;
        displayName: string;
    };
};
export {};
