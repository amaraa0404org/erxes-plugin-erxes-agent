import { AvatarProps } from 'erxes-ui';
import React from 'react';
import { ICustomer } from '../types';
interface CustomersInlineProviderProps {
    children: React.ReactNode;
    customerIds?: string[];
    customers?: ICustomer[];
    placeholder?: string;
    updateCustomers?: (customers: ICustomer[]) => void;
    hideAvatar?: boolean;
}
export declare const CustomersInline: React.ForwardRefExoticComponent<Omit<Omit<React.DetailedHTMLProps<React.HTMLAttributes<HTMLSpanElement>, HTMLSpanElement>, "ref">, "children"> & Omit<CustomersInlineProviderProps, "children"> & React.RefAttributes<HTMLSpanElement>> & {
    Provider: ({ children, placeholder, customerIds, customers, updateCustomers, hideAvatar, }: CustomersInlineProviderProps) => import("react/jsx-runtime").JSX.Element;
    Avatar: ({ className, ...props }: AvatarProps) => import("react/jsx-runtime").JSX.Element | null;
    Title: ({ className }: {
        className?: string;
    }) => import("react/jsx-runtime").JSX.Element;
};
export {};
