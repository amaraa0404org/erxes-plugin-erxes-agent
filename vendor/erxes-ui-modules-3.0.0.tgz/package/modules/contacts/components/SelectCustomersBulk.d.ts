import { ICustomer } from '../types/Customer';
interface SelectCustomersProps {
    onSelect: (customerIds: string[], customers?: ICustomer[]) => void;
    children: React.ReactNode;
    customerIds?: string[];
}
export declare const SelectCustomersBulk: ({ onSelect, children, customerIds, }: SelectCustomersProps) => import("react/jsx-runtime").JSX.Element;
export {};
