import { ValidationStatus } from 'erxes-ui';
interface CustomerEmailsProps {
    primaryEmail: string;
    _id: string;
    emailValidationStatus?: `${ValidationStatus}`;
    emails: string[];
    scope?: string;
    Trigger: React.ComponentType<{
        children: React.ReactNode;
    }>;
}
export declare function CustomerEmails({ primaryEmail, _id, emailValidationStatus, emails, scope, Trigger, }: CustomerEmailsProps): import("react/jsx-runtime").JSX.Element;
export {};
