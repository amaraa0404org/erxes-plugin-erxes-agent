export declare const CustomerOwner: ({ _id, ownerId, inTable, scope, }: {
    _id: string;
    ownerId?: string;
    inTable?: boolean;
    scope?: string;
}) => import("react/jsx-runtime").JSX.Element;
