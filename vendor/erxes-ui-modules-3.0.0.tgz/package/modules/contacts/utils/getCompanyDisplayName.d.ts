import { ICompany } from '../types';
type CompanyDisplayFields = Pick<ICompany, 'primaryName' | 'code' | 'primaryEmail' | 'primaryPhone'>;
export declare const getCompanyDisplayName: (company?: CompanyDisplayFields | null) => string | undefined;
export {};
