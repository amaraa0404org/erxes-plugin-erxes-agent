export declare const ApprovalLockReleaseButton: ({ canRelease, loading, onRelease, }: {
    canRelease: boolean;
    loading: boolean;
    onRelease: () => void;
}) => import("react/jsx-runtime").JSX.Element;
