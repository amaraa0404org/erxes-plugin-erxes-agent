import { ApprovalLockFormController } from '../hooks/useApprovalLockForm';
export declare const ApprovalLockForm: ({ form, }: {
    form: ApprovalLockFormController;
}) => import("react/jsx-runtime").JSX.Element;
