import { ApprovalRequest } from '../types';
type ApprovalRequestAccessButtonProps = {
    contentType: string;
    contentId: string;
    pendingRequest?: ApprovalRequest;
    disabled?: boolean;
    onCompleted?: () => void;
};
export declare const ApprovalRequestAccessButton: ({ contentType, contentId, pendingRequest, disabled, onCompleted, }: ApprovalRequestAccessButtonProps) => import("react/jsx-runtime").JSX.Element;
export {};
