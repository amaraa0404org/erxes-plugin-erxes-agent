import { ApprovalLockState } from '../types';
type ApprovalLockedBadgeProps = {
    state?: ApprovalLockState;
};
export declare const ApprovalLockedBadge: ({ state }: ApprovalLockedBadgeProps) => import("react/jsx-runtime").JSX.Element | null;
export {};
