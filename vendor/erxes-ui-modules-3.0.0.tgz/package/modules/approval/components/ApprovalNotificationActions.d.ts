import { ApprovalRequest } from '../types';
type ApprovalNotificationActionsProps = {
    request: ApprovalRequest;
    onCompleted?: () => void;
};
export declare const ApprovalNotificationActions: ({ request, onCompleted, }: ApprovalNotificationActionsProps) => import("react/jsx-runtime").JSX.Element;
export {};
