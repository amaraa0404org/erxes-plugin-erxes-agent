import { ReactNode } from 'react';
import { ApprovalLockFormController } from '../hooks/useApprovalLockForm';
export declare const ApprovalLockDialog: ({ form, loading, onCreate, onOpenChange, open, trigger, }: {
    form: ApprovalLockFormController;
    loading: boolean;
    onCreate: () => void;
    onOpenChange: (open: boolean) => void;
    open: boolean;
    trigger?: ReactNode;
}) => import("react/jsx-runtime").JSX.Element;
