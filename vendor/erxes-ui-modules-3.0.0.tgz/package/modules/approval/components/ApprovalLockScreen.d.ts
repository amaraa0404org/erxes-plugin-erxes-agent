import { ApprovalLockState } from '../types';
type ApprovalLockScreenProps = {
    state: ApprovalLockState;
    onRequestCompleted?: () => void;
};
export declare const ApprovalLockScreen: ({ state, onRequestCompleted, }: ApprovalLockScreenProps) => import("react/jsx-runtime").JSX.Element;
export {};
