import { ReactNode } from 'react';
import { UseApprovalLockProps } from '../hooks/useApprovalLock';
export type ApprovalLockUnlockedRenderProps = {
    loading: boolean;
};
export type ApprovalLockLockedRenderProps = {
    canRelease: boolean;
    loading: boolean;
    onRelease: () => void;
};
type ApprovalLockButtonProps = UseApprovalLockProps & {
    whenUnlocked?: (props: ApprovalLockUnlockedRenderProps) => ReactNode;
    whenLocked?: (props: ApprovalLockLockedRenderProps) => ReactNode;
};
export declare const ApprovalLockButton: ({ whenLocked, whenUnlocked, ...lockProps }: ApprovalLockButtonProps) => string | number | boolean | Iterable<ReactNode> | import("react/jsx-runtime").JSX.Element;
export {};
