import { ReactNode } from 'react';
import { ApprovalLockVariables } from '../types';
type ApprovalLockGuardProps = ApprovalLockVariables & {
    children: ReactNode;
    fallback?: ReactNode;
    loadingFallback?: ReactNode;
};
export declare const ApprovalLockGuard: ({ children, fallback, loadingFallback, ...variables }: ApprovalLockGuardProps) => string | number | boolean | Iterable<ReactNode> | import("react/jsx-runtime").JSX.Element | null | undefined;
export {};
