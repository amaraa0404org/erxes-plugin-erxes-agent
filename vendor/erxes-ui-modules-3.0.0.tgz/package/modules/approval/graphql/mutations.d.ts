export declare const APPROVAL_LOCK_CREATE: import("@apollo/client").DocumentNode;
export declare const APPROVAL_LOCK_RELEASE: import("@apollo/client").DocumentNode;
export declare const APPROVAL_REQUEST_CREATE: import("@apollo/client").DocumentNode;
export declare const APPROVAL_REQUEST_APPROVE: import("@apollo/client").DocumentNode;
export declare const APPROVAL_REQUEST_REJECT: import("@apollo/client").DocumentNode;
export declare const APPROVAL_REQUEST_CANCEL: import("@apollo/client").DocumentNode;
