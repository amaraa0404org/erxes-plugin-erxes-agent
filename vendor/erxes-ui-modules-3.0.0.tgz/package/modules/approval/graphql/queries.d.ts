export declare const APPROVAL_LOCK_FIELDS: import("@apollo/client").DocumentNode;
export declare const APPROVAL_REQUEST_FIELDS: import("@apollo/client").DocumentNode;
export declare const APPROVAL_LOCK_STATE_FIELDS: import("@apollo/client").DocumentNode;
export declare const APPROVAL_LOCK_STATE: import("@apollo/client").DocumentNode;
export declare const APPROVAL_LOCK_STATES: import("@apollo/client").DocumentNode;
export declare const APPROVAL_REQUEST_DETAIL: import("@apollo/client").DocumentNode;
export declare const APPROVAL_REQUESTS: import("@apollo/client").DocumentNode;
