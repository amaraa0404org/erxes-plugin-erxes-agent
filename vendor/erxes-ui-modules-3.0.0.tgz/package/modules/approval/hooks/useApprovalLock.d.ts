import { ApprovalLockState, ApprovalLockVariables } from '../types';
export type UseApprovalLockProps = ApprovalLockVariables & {
    state?: ApprovalLockState;
    onChanged?: () => void;
};
export declare const useApprovalLock: ({ state, onChanged, ...variables }: UseApprovalLockProps) => {
    open: boolean;
    setOpen: import("react").Dispatch<import("react").SetStateAction<boolean>>;
    isLocked: boolean;
    canRelease: boolean;
    loading: boolean;
    form: {
        allowedUserIds: string[];
        approverScope: import("../types").ApprovalApproverScope;
        approvalMode: import("../types").ApprovalMode;
        hasAllowedUsers: boolean;
        canSelectApprovalMode: boolean;
        handleAllowedUsersChange: (value: string | string[] | null) => void;
        handleApproverScopeChange: (value: string) => void;
        handleApprovalModeChange: (value: string) => void;
        getValues: () => import("./useApprovalLockForm").ApprovalLockFormValues;
    };
    onCreate: () => Promise<void>;
    onRelease: () => Promise<void>;
};
