import { QueryHookOptions } from '@apollo/client';
import { ApprovalLockState, ApprovalLockVariables } from '../types';
type ApprovalLockStateResponse = {
    approvalLockState: ApprovalLockState;
};
export declare const useApprovalLockState: (variables: ApprovalLockVariables, options?: QueryHookOptions<ApprovalLockStateResponse>) => {
    state: ApprovalLockState | undefined;
    loading: boolean;
    error: import("@apollo/client").ApolloError | undefined;
    refetch: (variables?: Partial<import("@apollo/client").OperationVariables> | undefined) => Promise<import("@apollo/client").ApolloQueryResult<ApprovalLockStateResponse>>;
};
export {};
