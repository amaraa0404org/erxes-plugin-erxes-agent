import { ApprovalApproverScope, ApprovalChange, ApprovalLock, ApprovalMode, ApprovalRequest } from '../types';
type LockCreateInput = {
    contentType: string;
    contentTypeId: string;
    ownerId: string;
    allowedUserIds?: string[];
    scope?: ApprovalApproverScope;
    mode?: ApprovalMode;
};
type RequestCreateInput = {
    contentType: string;
    contentId: string;
    reason?: string;
    /** Naming a change makes this a change request rather than an access one. */
    change?: ApprovalChange;
    approverIds?: string[];
};
export declare const useApprovalLockActions: () => {
    createLock: (input: LockCreateInput) => Promise<import("@apollo/client").FetchResult<{
        approvalLockCreate: ApprovalLock;
    }>>;
    releaseLock: (id: string) => Promise<import("@apollo/client").FetchResult<{
        approvalLockRelease: ApprovalLock;
    }>>;
    createRequest: (input: RequestCreateInput) => Promise<import("@apollo/client").FetchResult<{
        approvalRequestCreate: ApprovalRequest;
    }>>;
    approveRequest: (id: string) => Promise<import("@apollo/client").FetchResult<{
        approvalRequestApprove: ApprovalRequest;
    }>>;
    rejectRequest: (id: string, reason?: string) => Promise<import("@apollo/client").FetchResult<{
        approvalRequestReject: ApprovalRequest;
    }>>;
    cancelRequest: (id: string) => Promise<import("@apollo/client").FetchResult<{
        approvalRequestCancel: ApprovalRequest;
    }>>;
    loading: boolean;
};
export {};
