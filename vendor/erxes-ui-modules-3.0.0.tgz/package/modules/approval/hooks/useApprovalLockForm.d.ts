import { ApprovalApproverScope, ApprovalMode } from '../types';
export type ApprovalLockFormValues = {
    allowedUserIds: string[];
    scope: ApprovalApproverScope;
    mode: ApprovalMode;
};
export declare const useApprovalLockForm: () => {
    allowedUserIds: string[];
    approverScope: ApprovalApproverScope;
    approvalMode: ApprovalMode;
    hasAllowedUsers: boolean;
    canSelectApprovalMode: boolean;
    handleAllowedUsersChange: (value: string | string[] | null) => void;
    handleApproverScopeChange: (value: string) => void;
    handleApprovalModeChange: (value: string) => void;
    getValues: () => ApprovalLockFormValues;
};
export type ApprovalLockFormController = ReturnType<typeof useApprovalLockForm>;
