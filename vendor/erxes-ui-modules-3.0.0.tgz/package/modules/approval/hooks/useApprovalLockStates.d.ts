import { QueryHookOptions } from '@apollo/client';
import { ApprovalLockState } from '../types';
type ApprovalLockStatesResponse = {
    approvalLockStates: ApprovalLockState[];
};
type ApprovalLockStatesVariables = {
    contentType: string;
    contentIds: string[];
    ownerIdsByContentId?: Record<string, string>;
    action?: string;
};
export declare const useApprovalLockStates: (variables: ApprovalLockStatesVariables, options?: QueryHookOptions<ApprovalLockStatesResponse>) => {
    states: ApprovalLockState[];
    statesByContentId: Record<string, ApprovalLockState>;
    loading: boolean;
    error: import("@apollo/client").ApolloError | undefined;
    refetch: (variables?: Partial<import("@apollo/client").OperationVariables> | undefined) => Promise<import("@apollo/client").ApolloQueryResult<ApprovalLockStatesResponse>>;
};
export {};
