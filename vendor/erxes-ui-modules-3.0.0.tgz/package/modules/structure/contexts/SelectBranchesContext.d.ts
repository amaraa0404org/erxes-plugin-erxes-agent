import { ISelectBranchesContext } from '../types/Branch';
export declare const SelectBranchesContext: import("react").Context<ISelectBranchesContext | null>;
