import { ISelectPositionsContext } from '../types/Position';
export declare const SelectPositionsContext: import("react").Context<ISelectPositionsContext | null>;
