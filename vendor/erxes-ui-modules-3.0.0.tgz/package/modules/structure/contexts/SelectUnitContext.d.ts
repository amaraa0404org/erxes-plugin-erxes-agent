import { ISelectUnitContext } from '../types/Unit';
export declare const SelectUnitContext: import("react").Context<ISelectUnitContext | null>;
