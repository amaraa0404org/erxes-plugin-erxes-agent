import { ISelectDepartmentsContext } from '../types/Department';
export declare const SelectDepartmentsContext: import("react").Context<ISelectDepartmentsContext | null>;
