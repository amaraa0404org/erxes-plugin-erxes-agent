export declare const CreatePositionForm: () => import("react/jsx-runtime").JSX.Element;
export declare function SelectPositionCreateContainer({ children, }: Readonly<{
    children: React.ReactNode;
}>): import("react/jsx-runtime").JSX.Element;
