import React from 'react';
import { IPosition, ISelectPositionsProviderProps } from '../types/Position';
import { PositionBadge } from './PositionBadge';
export declare const SelectPositionsProvider: ({ children, value, onValueChange, mode, }: ISelectPositionsProviderProps) => import("react/jsx-runtime").JSX.Element;
export declare const SelectPositionsCommand: ({ disableCreateOption, }: {
    disableCreateOption?: boolean;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectPositionsCreate: ({ search, show, }: {
    search: string;
    show: boolean;
}) => import("react/jsx-runtime").JSX.Element | null;
export declare const SelectPositionsItem: ({ position, }: {
    position: IPosition & {
        hasChildren: boolean;
    };
}) => import("react/jsx-runtime").JSX.Element;
export declare const PositionsList: ({ placeholder, renderAsPlainText, ...props }: Omit<React.ComponentProps<typeof PositionBadge>, "onClose"> & {
    placeholder?: string;
    renderAsPlainText?: boolean;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectPositionsValue: () => import("react/jsx-runtime").JSX.Element;
export declare const SelectPositionsContent: () => import("react/jsx-runtime").JSX.Element;
export declare const SelectPositionsInlineCell: ({ onValueChange, scope, ...props }: Omit<React.ComponentProps<typeof SelectPositionsProvider>, "children"> & {
    scope?: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectPositionsDetail: React.ForwardRefExoticComponent<Omit<ISelectPositionsProviderProps, "children"> & Omit<Omit<Omit<import("erxes-ui").ButtonProps & React.RefAttributes<HTMLButtonElement>, "ref"> & {
    hideChevron?: boolean;
} & React.RefAttributes<HTMLButtonElement>, "ref">, "children"> & {
    scope?: string;
} & React.RefAttributes<HTMLButtonElement>>;
export declare const SelectPositionsCommandbarItem: ({ onValueChange, ...props }: Omit<React.ComponentProps<typeof SelectPositionsProvider>, "children">) => import("react/jsx-runtime").JSX.Element;
export declare const SelectPositionsFormItem: ({ onValueChange, className, ...props }: Omit<React.ComponentProps<typeof SelectPositionsProvider>, "children"> & {
    className?: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectPositionsFilterItem: ({ value, label, }: {
    value: string;
    label: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectPositionsFilterView: ({ mode, filterKey, }: {
    mode: "single" | "multiple";
    filterKey: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectPositionsFilterBar: ({ mode, filterKey, label, }: {
    mode: "single" | "multiple";
    filterKey: string;
    label: string;
}) => import("react/jsx-runtime").JSX.Element | null;
export declare const SelectPositions: (({ children, value, onValueChange, mode, }: ISelectPositionsProviderProps) => import("react/jsx-runtime").JSX.Element) & {
    Provider: ({ children, value, onValueChange, mode, }: ISelectPositionsProviderProps) => import("react/jsx-runtime").JSX.Element;
    CommandBarItem: ({ onValueChange, ...props }: Omit<React.ComponentProps<typeof SelectPositionsProvider>, "children">) => import("react/jsx-runtime").JSX.Element;
    Content: () => import("react/jsx-runtime").JSX.Element;
    Command: ({ disableCreateOption, }: {
        disableCreateOption?: boolean;
    }) => import("react/jsx-runtime").JSX.Element;
    Item: ({ position, }: {
        position: IPosition & {
            hasChildren: boolean;
        };
    }) => import("react/jsx-runtime").JSX.Element;
    Value: () => import("react/jsx-runtime").JSX.Element;
    List: ({ placeholder, renderAsPlainText, ...props }: Omit<React.ComponentProps<typeof PositionBadge>, "onClose"> & {
        placeholder?: string;
        renderAsPlainText?: boolean;
    }) => import("react/jsx-runtime").JSX.Element;
    InlineCell: ({ onValueChange, scope, ...props }: Omit<React.ComponentProps<typeof SelectPositionsProvider>, "children"> & {
        scope?: string;
    }) => import("react/jsx-runtime").JSX.Element;
    FormItem: ({ onValueChange, className, ...props }: Omit<React.ComponentProps<typeof SelectPositionsProvider>, "children"> & {
        className?: string;
    }) => import("react/jsx-runtime").JSX.Element;
    FilterItem: ({ value, label, }: {
        value: string;
        label: string;
    }) => import("react/jsx-runtime").JSX.Element;
    FilterView: ({ mode, filterKey, }: {
        mode: "single" | "multiple";
        filterKey: string;
    }) => import("react/jsx-runtime").JSX.Element;
    FilterBar: ({ mode, filterKey, label, }: {
        mode: "single" | "multiple";
        filterKey: string;
        label: string;
    }) => import("react/jsx-runtime").JSX.Element | null;
    Detail: React.ForwardRefExoticComponent<Omit<ISelectPositionsProviderProps, "children"> & Omit<Omit<Omit<import("erxes-ui").ButtonProps & React.RefAttributes<HTMLButtonElement>, "ref"> & {
        hideChevron?: boolean;
    } & React.RefAttributes<HTMLButtonElement>, "ref">, "children"> & {
        scope?: string;
    } & React.RefAttributes<HTMLButtonElement>>;
};
