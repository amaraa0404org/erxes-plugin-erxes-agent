import React from 'react';
import { IBranch, ISelectBranchesProviderProps } from '../types/Branch';
import { BranchBadge } from './BranchBadge';
export declare const SelectBranchesProvider: ({ children, value, onValueChange, mode, }: ISelectBranchesProviderProps) => import("react/jsx-runtime").JSX.Element;
export declare const SelectBranchesCommand: ({ disableCreateOption, }: {
    disableCreateOption?: boolean;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectBranchesCreate: ({ search, show, }: {
    search: string;
    show: boolean;
}) => import("react/jsx-runtime").JSX.Element | null;
export declare const SelectBranchesItem: ({ branch, }: {
    branch: IBranch & {
        hasChildren: boolean;
    };
}) => import("react/jsx-runtime").JSX.Element;
export declare const BranchesList: ({ placeholder, renderAsPlainText, className, ...props }: Omit<React.ComponentProps<typeof BranchBadge>, "onClose"> & {
    placeholder?: string;
    renderAsPlainText?: boolean;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectBranchesValue: ({ placeholder, }: {
    placeholder?: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectBranchesContent: () => import("react/jsx-runtime").JSX.Element;
export declare const SelectBranchesRoot: React.ForwardRefExoticComponent<Omit<ISelectBranchesProviderProps, "children"> & Omit<Omit<Omit<import("erxes-ui").ButtonProps & React.RefAttributes<HTMLButtonElement>, "ref"> & {
    hideChevron?: boolean;
} & React.RefAttributes<HTMLButtonElement>, "ref">, "children"> & {
    placeholder?: string;
    scope?: string;
} & React.RefAttributes<HTMLButtonElement>>;
export declare const SelectBranchesInlineCell: ({ onValueChange, scope, ...props }: Omit<React.ComponentProps<typeof SelectBranchesProvider>, "children"> & {
    scope?: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectBranchesDetail: React.ForwardRefExoticComponent<Omit<ISelectBranchesProviderProps, "children"> & Omit<Omit<Omit<import("erxes-ui").ButtonProps & React.RefAttributes<HTMLButtonElement>, "ref"> & {
    hideChevron?: boolean;
} & React.RefAttributes<HTMLButtonElement>, "ref">, "children"> & {
    scope?: string;
} & React.RefAttributes<HTMLButtonElement>>;
export declare const SelectBranchesCommandbarItem: ({ onValueChange, ...props }: Omit<React.ComponentProps<typeof SelectBranchesProvider>, "children">) => import("react/jsx-runtime").JSX.Element;
export declare const SelectBranchesComboboxItem: ({ onValueChange, className, ...props }: Omit<React.ComponentProps<typeof SelectBranchesProvider>, "children"> & {
    className?: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectBranchesFormItem: ({ onValueChange, className, ...props }: Omit<React.ComponentProps<typeof SelectBranchesProvider>, "children"> & {
    className?: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectBranchesFilterItem: ({ value, label, }: {
    value: string;
    label: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectBranchesFilterView: ({ mode, filterKey, }: {
    mode: "single" | "multiple";
    filterKey: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectBranchesFilterBar: ({ mode, filterKey, label, }: {
    mode: "single" | "multiple";
    filterKey: string;
    label: string;
}) => import("react/jsx-runtime").JSX.Element | null;
export declare const SelectBranches: (({ children, value, onValueChange, mode, }: ISelectBranchesProviderProps) => import("react/jsx-runtime").JSX.Element) & {
    Root: React.ForwardRefExoticComponent<Omit<ISelectBranchesProviderProps, "children"> & Omit<Omit<Omit<import("erxes-ui").ButtonProps & React.RefAttributes<HTMLButtonElement>, "ref"> & {
        hideChevron?: boolean;
    } & React.RefAttributes<HTMLButtonElement>, "ref">, "children"> & {
        placeholder?: string;
        scope?: string;
    } & React.RefAttributes<HTMLButtonElement>>;
    CommandBarItem: ({ onValueChange, ...props }: Omit<React.ComponentProps<typeof SelectBranchesProvider>, "children">) => import("react/jsx-runtime").JSX.Element;
    Content: () => import("react/jsx-runtime").JSX.Element;
    Command: ({ disableCreateOption, }: {
        disableCreateOption?: boolean;
    }) => import("react/jsx-runtime").JSX.Element;
    Item: ({ branch, }: {
        branch: IBranch & {
            hasChildren: boolean;
        };
    }) => import("react/jsx-runtime").JSX.Element;
    Value: ({ placeholder, }: {
        placeholder?: string;
    }) => import("react/jsx-runtime").JSX.Element;
    List: ({ placeholder, renderAsPlainText, className, ...props }: Omit<React.ComponentProps<typeof BranchBadge>, "onClose"> & {
        placeholder?: string;
        renderAsPlainText?: boolean;
    }) => import("react/jsx-runtime").JSX.Element;
    InlineCell: ({ onValueChange, scope, ...props }: Omit<React.ComponentProps<typeof SelectBranchesProvider>, "children"> & {
        scope?: string;
    }) => import("react/jsx-runtime").JSX.Element;
    ComboboxItem: ({ onValueChange, className, ...props }: Omit<React.ComponentProps<typeof SelectBranchesProvider>, "children"> & {
        className?: string;
    }) => import("react/jsx-runtime").JSX.Element;
    FormItem: ({ onValueChange, className, ...props }: Omit<React.ComponentProps<typeof SelectBranchesProvider>, "children"> & {
        className?: string;
    }) => import("react/jsx-runtime").JSX.Element;
    FilterItem: ({ value, label, }: {
        value: string;
        label: string;
    }) => import("react/jsx-runtime").JSX.Element;
    FilterView: ({ mode, filterKey, }: {
        mode: "single" | "multiple";
        filterKey: string;
    }) => import("react/jsx-runtime").JSX.Element;
    FilterBar: ({ mode, filterKey, label, }: {
        mode: "single" | "multiple";
        filterKey: string;
        label: string;
    }) => import("react/jsx-runtime").JSX.Element | null;
    Detail: React.ForwardRefExoticComponent<Omit<ISelectBranchesProviderProps, "children"> & Omit<Omit<Omit<import("erxes-ui").ButtonProps & React.RefAttributes<HTMLButtonElement>, "ref"> & {
        hideChevron?: boolean;
    } & React.RefAttributes<HTMLButtonElement>, "ref">, "children"> & {
        scope?: string;
    } & React.RefAttributes<HTMLButtonElement>>;
};
