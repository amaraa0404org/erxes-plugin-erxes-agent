import React from 'react';
import { IPosition } from '../types/Position';
export declare const PositionBadge: React.ForwardRefExoticComponent<Omit<import("erxes-ui").BadgeProps & React.RefAttributes<HTMLDivElement>, "ref"> & {
    position?: IPosition;
    positionId?: string;
    renderClose?: (position: IPosition) => React.ReactNode;
    onCompleted?: (positions: IPosition) => void;
    renderAsPlainText?: boolean;
} & React.RefAttributes<HTMLDivElement>>;
