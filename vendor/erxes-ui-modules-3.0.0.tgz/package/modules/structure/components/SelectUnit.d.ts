import React from 'react';
import { ISelectUnitProviderProps, IUnit } from '../types/Unit';
export declare const SelectUnitProvider: ({ children, value, onValueChange, }: ISelectUnitProviderProps) => import("react/jsx-runtime").JSX.Element;
export declare const SelectUnitCommand: ({ disableCreateOption, }: {
    disableCreateOption?: boolean;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectUnitCreate: ({ search, show, }: {
    search: string;
    show: boolean;
}) => import("react/jsx-runtime").JSX.Element | null;
export declare const SelectUnitItem: ({ unit }: {
    unit: IUnit;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectUnitValue: ({ placeholder }: {
    placeholder?: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectUnitContent: ({ disableCreateOption, }: {
    disableCreateOption?: boolean;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectUnitInlineCell: ({ onValueChange, scope, ...props }: Omit<React.ComponentProps<typeof SelectUnitProvider>, "children"> & {
    scope?: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectUnitDetail: React.ForwardRefExoticComponent<Omit<ISelectUnitProviderProps, "children"> & Omit<Omit<Omit<import("erxes-ui").ButtonProps & React.RefAttributes<HTMLButtonElement>, "ref"> & {
    hideChevron?: boolean;
} & React.RefAttributes<HTMLButtonElement>, "ref">, "children"> & {
    scope?: string;
} & React.RefAttributes<HTMLButtonElement>>;
export declare const SelectUnitCommandbarItem: ({ onValueChange, ...props }: Omit<React.ComponentProps<typeof SelectUnitProvider>, "children">) => import("react/jsx-runtime").JSX.Element;
export declare const SelectUnitFormItem: ({ onValueChange, className, ...props }: Omit<React.ComponentProps<typeof SelectUnitProvider>, "children"> & {
    className?: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectUnitFilterItem: () => import("react/jsx-runtime").JSX.Element;
export declare const SelectUnitFilterView: () => import("react/jsx-runtime").JSX.Element;
export declare const SelectUnitFilterBar: () => import("react/jsx-runtime").JSX.Element | null;
export declare const SelectUnit: (({ children, value, onValueChange, }: ISelectUnitProviderProps) => import("react/jsx-runtime").JSX.Element) & {
    Provider: ({ children, value, onValueChange, }: ISelectUnitProviderProps) => import("react/jsx-runtime").JSX.Element;
    CommandBarItem: ({ onValueChange, ...props }: Omit<React.ComponentProps<typeof SelectUnitProvider>, "children">) => import("react/jsx-runtime").JSX.Element;
    Content: ({ disableCreateOption, }: {
        disableCreateOption?: boolean;
    }) => import("react/jsx-runtime").JSX.Element;
    Command: ({ disableCreateOption, }: {
        disableCreateOption?: boolean;
    }) => import("react/jsx-runtime").JSX.Element;
    Item: ({ unit }: {
        unit: IUnit;
    }) => import("react/jsx-runtime").JSX.Element;
    Value: ({ placeholder }: {
        placeholder?: string;
    }) => import("react/jsx-runtime").JSX.Element;
    InlineCell: ({ onValueChange, scope, ...props }: Omit<React.ComponentProps<typeof SelectUnitProvider>, "children"> & {
        scope?: string;
    }) => import("react/jsx-runtime").JSX.Element;
    FormItem: ({ onValueChange, className, ...props }: Omit<React.ComponentProps<typeof SelectUnitProvider>, "children"> & {
        className?: string;
    }) => import("react/jsx-runtime").JSX.Element;
    FilterItem: () => import("react/jsx-runtime").JSX.Element;
    FilterView: () => import("react/jsx-runtime").JSX.Element;
    FilterBar: () => import("react/jsx-runtime").JSX.Element | null;
    Detail: React.ForwardRefExoticComponent<Omit<ISelectUnitProviderProps, "children"> & Omit<Omit<Omit<import("erxes-ui").ButtonProps & React.RefAttributes<HTMLButtonElement>, "ref"> & {
        hideChevron?: boolean;
    } & React.RefAttributes<HTMLButtonElement>, "ref">, "children"> & {
        scope?: string;
    } & React.RefAttributes<HTMLButtonElement>>;
};
