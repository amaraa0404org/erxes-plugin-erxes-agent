import { IBranch } from '../types/Branch';
import React from 'react';
export declare const BranchBadge: React.ForwardRefExoticComponent<Omit<import("erxes-ui").BadgeProps & React.RefAttributes<HTMLDivElement>, "ref"> & {
    branch?: IBranch;
    branchId?: string;
    renderClose?: (branch: IBranch) => React.ReactNode;
    onCompleted?: (branches: IBranch) => void;
    renderAsPlainText?: boolean;
    showMissingId?: boolean;
} & React.RefAttributes<HTMLDivElement>>;
