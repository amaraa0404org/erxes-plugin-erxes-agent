import React from 'react';
import { IDepartment } from '../types/Department';
export declare const DepartmentBadge: React.ForwardRefExoticComponent<Omit<import("erxes-ui").BadgeProps & React.RefAttributes<HTMLDivElement>, "ref"> & {
    department?: IDepartment;
    departmentId?: string;
    renderClose?: (department: IDepartment) => React.ReactNode;
    onCompleted?: (department: IDepartment) => void;
    renderAsPlainText?: boolean;
    showMissingId?: boolean;
} & React.RefAttributes<HTMLDivElement>>;
