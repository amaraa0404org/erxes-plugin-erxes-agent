export declare const CreateDepartmentForm: () => import("react/jsx-runtime").JSX.Element;
export declare function SelectDepartmentsCreateContainer({ children, }: Readonly<{
    children: React.ReactNode;
}>): import("react/jsx-runtime").JSX.Element;
