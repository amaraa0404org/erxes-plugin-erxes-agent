import React from 'react';
import { IDepartment, ISelectDepartmentsProviderProps } from '../types/Department';
import { DepartmentBadge } from './DepartmentBadge';
export declare const SelectDepartmentsProvider: ({ children, value, onValueChange, mode, }: ISelectDepartmentsProviderProps) => import("react/jsx-runtime").JSX.Element;
export declare const SelectDepartmentsCommand: ({ disableCreateOption, }: {
    disableCreateOption?: boolean;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectDepartmentsCreate: ({ search, show, }: {
    search: string;
    show: boolean;
}) => import("react/jsx-runtime").JSX.Element | null;
export declare const SelectDepartmentsItem: ({ department, }: {
    department: IDepartment & {
        hasChildren: boolean;
    };
}) => import("react/jsx-runtime").JSX.Element;
export declare const DepartmentsList: ({ placeholder, renderAsPlainText, className, ...props }: Omit<React.ComponentProps<typeof DepartmentBadge>, "onClose"> & {
    placeholder?: string;
    renderAsPlainText?: boolean;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectDepartmentsValue: ({ placeholder, }: {
    placeholder?: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectDepartmentsContent: () => import("react/jsx-runtime").JSX.Element;
export declare const SelectDepartmentsRoot: React.ForwardRefExoticComponent<Omit<ISelectDepartmentsProviderProps, "children"> & Omit<Omit<Omit<import("erxes-ui").ButtonProps & React.RefAttributes<HTMLButtonElement>, "ref"> & {
    hideChevron?: boolean;
} & React.RefAttributes<HTMLButtonElement>, "ref">, "children"> & {
    placeholder?: string;
    scope?: string;
} & React.RefAttributes<HTMLButtonElement>>;
export declare const SelectDepartmentsInlineCell: ({ onValueChange, scope, ...props }: Omit<React.ComponentProps<typeof SelectDepartmentsProvider>, "children"> & {
    scope?: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectDepartmentsDetail: React.ForwardRefExoticComponent<Omit<ISelectDepartmentsProviderProps, "children"> & Omit<Omit<Omit<import("erxes-ui").ButtonProps & React.RefAttributes<HTMLButtonElement>, "ref"> & {
    hideChevron?: boolean;
} & React.RefAttributes<HTMLButtonElement>, "ref">, "children"> & {
    scope?: string;
} & React.RefAttributes<HTMLButtonElement>>;
export declare const SelectDepartmentsCommandbarItem: ({ onValueChange, ...props }: Omit<React.ComponentProps<typeof SelectDepartmentsProvider>, "children">) => import("react/jsx-runtime").JSX.Element;
export declare const SelectDepartmentsComboboxItem: ({ onValueChange, className, ...props }: Omit<React.ComponentProps<typeof SelectDepartmentsProvider>, "children"> & {
    className?: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectDepartmentsFormItem: ({ onValueChange, className, ...props }: Omit<React.ComponentProps<typeof SelectDepartmentsProvider>, "children"> & {
    className?: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectDepartmentsFilterItem: ({ value, label, }: {
    value: string;
    label: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectDepartmentsFilterView: ({ mode, filterKey, }: {
    mode: "single" | "multiple";
    filterKey: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectDepartmentsFilterBar: ({ mode, filterKey, label, }: {
    mode: "single" | "multiple";
    filterKey: string;
    label: string;
}) => import("react/jsx-runtime").JSX.Element | null;
export declare const SelectDepartments: (({ children, value, onValueChange, mode, }: ISelectDepartmentsProviderProps) => import("react/jsx-runtime").JSX.Element) & {
    Root: React.ForwardRefExoticComponent<Omit<ISelectDepartmentsProviderProps, "children"> & Omit<Omit<Omit<import("erxes-ui").ButtonProps & React.RefAttributes<HTMLButtonElement>, "ref"> & {
        hideChevron?: boolean;
    } & React.RefAttributes<HTMLButtonElement>, "ref">, "children"> & {
        placeholder?: string;
        scope?: string;
    } & React.RefAttributes<HTMLButtonElement>>;
    CommandBarItem: ({ onValueChange, ...props }: Omit<React.ComponentProps<typeof SelectDepartmentsProvider>, "children">) => import("react/jsx-runtime").JSX.Element;
    Content: () => import("react/jsx-runtime").JSX.Element;
    Command: ({ disableCreateOption, }: {
        disableCreateOption?: boolean;
    }) => import("react/jsx-runtime").JSX.Element;
    Item: ({ department, }: {
        department: IDepartment & {
            hasChildren: boolean;
        };
    }) => import("react/jsx-runtime").JSX.Element;
    Value: ({ placeholder, }: {
        placeholder?: string;
    }) => import("react/jsx-runtime").JSX.Element;
    List: ({ placeholder, renderAsPlainText, className, ...props }: Omit<React.ComponentProps<typeof DepartmentBadge>, "onClose"> & {
        placeholder?: string;
        renderAsPlainText?: boolean;
    }) => import("react/jsx-runtime").JSX.Element;
    InlineCell: ({ onValueChange, scope, ...props }: Omit<React.ComponentProps<typeof SelectDepartmentsProvider>, "children"> & {
        scope?: string;
    }) => import("react/jsx-runtime").JSX.Element;
    ComboboxItem: ({ onValueChange, className, ...props }: Omit<React.ComponentProps<typeof SelectDepartmentsProvider>, "children"> & {
        className?: string;
    }) => import("react/jsx-runtime").JSX.Element;
    FormItem: ({ onValueChange, className, ...props }: Omit<React.ComponentProps<typeof SelectDepartmentsProvider>, "children"> & {
        className?: string;
    }) => import("react/jsx-runtime").JSX.Element;
    FilterItem: ({ value, label, }: {
        value: string;
        label: string;
    }) => import("react/jsx-runtime").JSX.Element;
    FilterView: ({ mode, filterKey, }: {
        mode: "single" | "multiple";
        filterKey: string;
    }) => import("react/jsx-runtime").JSX.Element;
    FilterBar: ({ mode, filterKey, label, }: {
        mode: "single" | "multiple";
        filterKey: string;
        label: string;
    }) => import("react/jsx-runtime").JSX.Element | null;
    Detail: React.ForwardRefExoticComponent<Omit<ISelectDepartmentsProviderProps, "children"> & Omit<Omit<Omit<import("erxes-ui").ButtonProps & React.RefAttributes<HTMLButtonElement>, "ref"> & {
        hideChevron?: boolean;
    } & React.RefAttributes<HTMLButtonElement>, "ref">, "children"> & {
        scope?: string;
    } & React.RefAttributes<HTMLButtonElement>>;
};
