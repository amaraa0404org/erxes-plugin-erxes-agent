import React from 'react';
import { IUnit } from '../types/Unit';
export declare const UnitBadge: React.ForwardRefExoticComponent<Omit<import("erxes-ui").BadgeProps & React.RefAttributes<HTMLDivElement>, "ref"> & {
    unit?: IUnit;
    unitId?: string;
    renderClose?: (unit: IUnit) => React.ReactNode;
    onCompleted?: (units: IUnit) => void;
    renderAsPlainText?: boolean;
} & React.RefAttributes<HTMLDivElement>>;
