export declare const CreateBranchForm: () => import("react/jsx-runtime").JSX.Element;
export declare function SelectBranchCreateContainer({ children, }: Readonly<{
    children: React.ReactNode;
}>): import("react/jsx-runtime").JSX.Element;
