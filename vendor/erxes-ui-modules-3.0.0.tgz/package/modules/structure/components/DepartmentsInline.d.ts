import { IDepartment } from '../types/Department';
export declare const DepartmentsInline: ({ departmentIds, departments, placeholder, }: {
    departmentIds?: string[];
    departments?: IDepartment[];
    placeholder?: string;
}) => import("react/jsx-runtime").JSX.Element;
