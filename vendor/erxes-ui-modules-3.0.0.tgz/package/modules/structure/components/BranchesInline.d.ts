import { IBranch } from '../types/Branch';
export declare const BranchesInline: ({ branchIds, branches, placeholder, }: {
    branchIds?: string[];
    branches?: IBranch[];
    placeholder?: string;
}) => import("react/jsx-runtime").JSX.Element;
