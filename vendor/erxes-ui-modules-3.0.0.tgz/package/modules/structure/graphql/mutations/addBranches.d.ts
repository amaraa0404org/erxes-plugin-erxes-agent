export declare const BRANCHES_ADD: import("@apollo/client").DocumentNode;
