export declare const POSITIONS_ADD: import("@apollo/client").DocumentNode;
