export declare const UNITS_ADD: import("@apollo/client").DocumentNode;
