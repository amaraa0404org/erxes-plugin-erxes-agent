export declare const DEPARTMENTS_ADD: import("@apollo/client").DocumentNode;
