export declare const GET_POSITIONS_QUERY: import("@apollo/client").DocumentNode;
export declare const GET_POSITION_BY_ID: import("@apollo/client").DocumentNode;
