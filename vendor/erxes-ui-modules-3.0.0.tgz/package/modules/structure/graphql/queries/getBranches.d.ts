export declare const GET_BRANCHES: import("@apollo/client").DocumentNode;
export declare const GET_BRANCH_BY_ID: import("@apollo/client").DocumentNode;
export declare const GET_BRANCHES_MAIN: import("@apollo/client").DocumentNode;
