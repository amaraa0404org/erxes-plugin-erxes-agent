export declare const GET_UNITS_MAIN: import("@apollo/client").DocumentNode;
export declare const GET_UNIT_BT_ID: import("@apollo/client").DocumentNode;
