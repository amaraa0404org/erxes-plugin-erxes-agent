export declare const GET_DEPARTMENTS: import("@apollo/client").DocumentNode;
export declare const GET_DEPARTMENT_BY_ID: import("@apollo/client").DocumentNode;
