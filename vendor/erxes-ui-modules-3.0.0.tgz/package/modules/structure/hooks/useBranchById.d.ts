import { OperationVariables } from '@apollo/client';
export declare const useBranchById: (options: OperationVariables) => {
    branchDetail: any;
    loading: boolean;
};
