import { OperationVariables } from '@apollo/client';
import { IBranch } from '../types/Branch';
export declare const useBranchesMain: (options?: OperationVariables) => {
    branches: IBranch[] | undefined;
    sortedBranches: {
        hasChildren: boolean;
        _id: string;
        title: string;
        code: string;
        parentId?: string;
        order: string;
        userCount?: number;
    }[];
    loading: boolean;
    error: import("@apollo/client").ApolloError | undefined;
    handleFetchMore: () => void;
    totalCount: number | undefined;
};
