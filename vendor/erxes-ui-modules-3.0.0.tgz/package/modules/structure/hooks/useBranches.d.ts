import { QueryHookOptions } from '@apollo/client';
import { ICursorListResponse } from 'erxes-ui';
import { IBranch } from '../types/Branch';
export declare const useBranches: (options?: QueryHookOptions<ICursorListResponse<IBranch>>) => {
    branches: {
        hasChildren: boolean;
        _id: string;
        title: string;
        code: string;
        parentId?: string;
        order: string;
        userCount?: number;
    }[] | undefined;
    sortedBranches: {
        hasChildren: boolean;
        _id: string;
        title: string;
        code: string;
        parentId?: string;
        order: string;
        userCount?: number;
    }[];
    totalCount: number;
    pageInfo: {
        hasNextPage: boolean;
        hasPreviousPage: boolean;
        startCursor: string;
        endCursor: string;
    } | undefined;
    loading: boolean;
    error: import("@apollo/client").ApolloError | undefined;
    handleFetchMore: () => void;
};
