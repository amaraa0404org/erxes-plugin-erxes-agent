import { MutationHookOptions } from '@apollo/client';
export declare const useDepartmentsAdd: () => {
    departmentsAdd: ({ variables, ...options }: MutationHookOptions) => void;
    loading: boolean;
};
