import { MutationHookOptions } from '@apollo/client';
export declare const useBranchesAdd: () => {
    branchesAdd: ({ variables, ...options }: MutationHookOptions) => void;
    loading: boolean;
};
