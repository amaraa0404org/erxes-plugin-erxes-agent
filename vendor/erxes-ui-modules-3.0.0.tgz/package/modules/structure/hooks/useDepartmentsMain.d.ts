import { OperationVariables } from '@apollo/client';
import { IDepartment } from '../types/Department';
export declare const useDepartmentsMain: (options?: OperationVariables) => {
    departments: IDepartment[] | undefined;
    loading: boolean;
    error: import("@apollo/client").ApolloError | undefined;
    handleFetchMore: () => void;
    totalCount: number | undefined;
    totalUsersCount: number | undefined;
};
