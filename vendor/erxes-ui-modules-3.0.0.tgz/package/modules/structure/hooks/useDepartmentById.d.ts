import { OperationVariables } from '@apollo/client';
import { IDepartment } from '../types/Department';
export declare const useDepartmentById: (options?: OperationVariables) => {
    departmentDetail: IDepartment | undefined;
    loading: boolean;
};
