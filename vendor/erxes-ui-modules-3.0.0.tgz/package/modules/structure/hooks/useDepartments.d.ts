import { QueryHookOptions } from '@apollo/client';
import { ICursorListResponse } from 'erxes-ui';
import { IDepartment } from '../types/Department';
export declare const useDepartments: (options?: QueryHookOptions<ICursorListResponse<IDepartment>>) => {
    departments: {
        hasChildren: boolean;
        _id: string;
        code: string;
        title: string;
        parentId?: string;
        order?: string;
        userCount?: number;
        status?: string;
    }[] | undefined;
    sortedDepartments: {
        hasChildren: boolean;
        _id: string;
        code: string;
        title: string;
        parentId?: string;
        order?: string;
        userCount?: number;
        status?: string;
    }[];
    totalCount: number;
    pageInfo: {
        hasNextPage: boolean;
        hasPreviousPage: boolean;
        startCursor: string;
        endCursor: string;
    } | undefined;
    loading: boolean;
    error: import("@apollo/client").ApolloError | undefined;
    handleFetchMore: () => void;
};
