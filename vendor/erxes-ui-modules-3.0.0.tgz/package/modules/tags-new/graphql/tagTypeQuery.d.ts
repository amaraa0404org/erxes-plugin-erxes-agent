export declare const TAGS_TYPES: import("@apollo/client").DocumentNode;
