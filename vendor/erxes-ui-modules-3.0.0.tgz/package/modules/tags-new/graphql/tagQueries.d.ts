export declare const TAGS_QUERY: import("@apollo/client").DocumentNode;
export declare const TAG_QUERY: import("@apollo/client").DocumentNode;
