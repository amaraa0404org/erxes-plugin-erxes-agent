import { ITag } from 'ui-modules/modules/tags-new/types/Tag';
export declare const TagInline: ({ tag }: {
    tag: ITag;
}) => import("react/jsx-runtime").JSX.Element;
