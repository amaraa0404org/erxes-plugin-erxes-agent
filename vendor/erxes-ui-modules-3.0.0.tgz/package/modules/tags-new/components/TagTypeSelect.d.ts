import { Button } from 'erxes-ui';
export declare const TagTypeSelect: ({ scope, ...props }: {
    scope?: string;
} & React.ComponentProps<typeof Button>) => import("react/jsx-runtime").JSX.Element;
