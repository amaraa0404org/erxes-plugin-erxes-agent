import { buttonVariants } from 'erxes-ui';
import type { VariantProps } from 'class-variance-authority';
import React from 'react';
import { TagBadge } from 'ui-modules/modules/tags-new/components/TagBadge';
import { TagsSelectProps } from 'ui-modules/modules/tags-new/types/TagsSelectTypes';
type ButtonProps = VariantProps<typeof buttonVariants>;
export declare const TagsSelect: React.ForwardRefExoticComponent<(TagsSelectProps & Omit<Omit<Omit<import("erxes-ui").ButtonProps & React.RefAttributes<HTMLButtonElement>, "ref"> & {
    hideChevron?: boolean;
} & React.RefAttributes<HTMLButtonElement>, "ref">, "children" | "type"> & {
    scope?: string;
    targetIds?: string[];
    variant?: ButtonProps["variant"];
    size?: ButtonProps["size"];
    className?: string;
}) & React.RefAttributes<HTMLButtonElement>> & {
    Provider: {
        ({ type, mode, value, onValueChange, children, scope, targetIds, options, }: TagsSelectProps): import("react/jsx-runtime").JSX.Element;
        displayName: string;
    };
    Content: {
        (): import("react/jsx-runtime").JSX.Element;
        displayName: string;
    };
    Value: {
        ({ showValue, placeholder, }: {
            showValue?: boolean;
            placeholder?: string;
        }): import("react/jsx-runtime").JSX.Element;
        displayName: string;
    };
    Trigger: React.ForwardRefExoticComponent<Omit<Omit<import("erxes-ui").ButtonProps & React.RefAttributes<HTMLButtonElement>, "variant"> & {
        showValue?: boolean;
        placeholder?: string;
        variant?: ButtonProps["variant"] | "ICON";
        size?: ButtonProps["size"];
    }, "ref"> & React.RefAttributes<HTMLButtonElement>>;
    SelectedList: {
        ({ placeholder, renderAsPlainText, ...props }: Omit<React.ComponentProps<typeof TagBadge>, "onClose"> & {
            placeholder?: string;
            renderAsPlainText?: boolean;
        }): import("react/jsx-runtime").JSX.Element | null;
        displayName: string;
    };
    InlineCell: React.ForwardRefExoticComponent<(TagsSelectProps & Omit<Omit<Omit<import("erxes-ui").ButtonProps & React.RefAttributes<HTMLButtonElement>, "ref"> & {
        hideChevron?: boolean;
    } & React.RefAttributes<HTMLButtonElement>, "ref">, "children" | "type"> & {
        scope?: string;
        targetIds?: string[];
    }) & React.RefAttributes<HTMLButtonElement>>;
    FormItem: React.ForwardRefExoticComponent<(TagsSelectProps & Omit<Omit<Omit<import("erxes-ui").ButtonProps & React.RefAttributes<HTMLButtonElement>, "ref"> & {
        hideChevron?: boolean;
    } & React.RefAttributes<HTMLButtonElement>, "ref">, "children" | "type"> & {
        scope?: string;
        targetIds?: string[];
        variant?: ButtonProps["variant"];
        size?: ButtonProps["size"];
        className?: string;
    }) & React.RefAttributes<HTMLButtonElement>>;
};
export {};
