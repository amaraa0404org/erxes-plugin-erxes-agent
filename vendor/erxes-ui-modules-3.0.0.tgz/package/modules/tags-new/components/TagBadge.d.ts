import { ITag } from 'ui-modules/modules/tags-new/types/Tag';
import React from 'react';
export declare const TagBadge: React.ForwardRefExoticComponent<Omit<import("erxes-ui").BadgeProps & React.RefAttributes<HTMLDivElement>, "ref"> & {
    tag?: ITag;
    tagId?: string;
    onCompleted?: (tags: ITag) => void;
    renderAsPlainText?: boolean;
} & React.RefAttributes<HTMLDivElement>>;
