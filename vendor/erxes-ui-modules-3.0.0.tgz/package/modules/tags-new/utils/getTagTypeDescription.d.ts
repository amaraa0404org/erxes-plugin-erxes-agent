export declare const getTagTypeDescription: ({ type, tagTypes }: {
    type: string | null;
    tagTypes: Record<string, {
        description: string;
        contentType: string;
    }[]>;
}) => string;
