import { SuggestionConfig } from '../types/placeholderInputTypes';
export declare function buildSuggestionMaps(extra?: SuggestionConfig[]): {
    suggestionConfigs: SuggestionConfig[];
    suggestionTypeMap: Map<string, SuggestionConfig>;
    suggestionTypeByTriggerMap: Map<string, SuggestionConfig>;
};
