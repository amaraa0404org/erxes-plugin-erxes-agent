export type TAutomationSeedParams = {
    triggerType: string;
    triggerId?: string;
    triggerConfig: Record<string, unknown>;
    actionType?: string;
    actionId?: string;
    name?: string;
};
/**
 * Builds a link to the automation builder that opens with a trigger already in
 * place and its configuration sidebar open, so a module can hand its own
 * context (a bot, a page, a form) straight into a new automation.
 */
export declare const buildAutomationSeedLink: ({ triggerType, triggerConfig, actionType, name, }: {
    triggerType: string;
    triggerConfig?: Record<string, unknown>;
    actionType?: string;
    name?: string;
}) => string;
/**
 * Reads back what `buildAutomationSeedLink` wrote. Returns nothing when the
 * link carries no seed; the caller still has to check the trigger type against
 * the registered constants before trusting it.
 */
export declare const parseAutomationSeedParams: (searchParams: URLSearchParams) => TAutomationSeedParams | undefined;
