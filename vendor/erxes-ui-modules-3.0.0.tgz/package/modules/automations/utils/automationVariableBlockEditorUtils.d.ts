import { IBlockEditor } from 'erxes-ui';
import { TAutomationVariableDragPayload } from './automationVariableDragUtils';
export declare const insertAutomationVariableInBlockEditor: ({ editor, payload, }: {
    editor: IBlockEditor;
    payload: TAutomationVariableDragPayload;
}) => void;
