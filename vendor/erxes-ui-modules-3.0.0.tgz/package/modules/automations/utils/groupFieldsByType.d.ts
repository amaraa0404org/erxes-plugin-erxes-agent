type TField = {
    value?: string;
    group?: string;
};
/** Buckets attributes by their group, or by the prefix before the first dot. */
export declare const groupFieldsByType: <T extends TField>(fields: T[]) => {
    [x: string]: T[];
};
export {};
