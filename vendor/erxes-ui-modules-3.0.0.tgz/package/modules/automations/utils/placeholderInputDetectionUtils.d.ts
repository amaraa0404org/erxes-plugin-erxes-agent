import { SuggestionConfig, TPlaceholderInputSuggestionType } from '../types/placeholderInputTypes';
export declare function isInsideLockedExpression(value: string, cursorPos: number): {
    inCurly: boolean;
    inBracket: boolean;
};
export type LockedExpressionRange = {
    start: number;
    end: number;
    token: string;
};
export declare function getLockedExpressionRanges(value: string): LockedExpressionRange[];
export declare function getLockedExpressionRangeAtCursor(value: string, cursorPos: number): LockedExpressionRange | null;
export declare function getAdjacentLockedExpressionRange(value: string, cursorPos: number, direction: 'backward' | 'forward'): LockedExpressionRange | null;
export declare function findActualTriggerPosition(value: string, cursorPos: number, suggestionTypeByTriggerMap: Map<string, SuggestionConfig>, fallbackPos: number): number;
export declare function getDateNowContext(value: string, cursorPos: number): {
    inside: boolean;
    afterNow: boolean;
    start: number;
    end: number;
};
export declare function isAllowedDateNowEditKey(key: string): boolean;
export declare function shouldEnableDateSuggestions(value: string, cursorPos: number, enabledTypes?: Record<TPlaceholderInputSuggestionType, boolean>): boolean;
export declare function getEnclosingExpressionRangeOnBackspace(value: string, cursorPos: number): {
    start: number;
    end: number;
} | null;
