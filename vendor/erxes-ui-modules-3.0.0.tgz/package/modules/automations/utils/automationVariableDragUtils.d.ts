export declare const AUTOMATION_VARIABLE_DRAG_MIME = "application/x-erxes-automation-variable";
export type TAutomationVariableDragPayload = {
    token: string;
    path: string;
    label: string;
    key: string;
    sourceNodeId: string;
    sourceNodeType: string;
    sourceNodeLabel: string;
};
export declare const setAutomationVariableDragData: (dataTransfer: DataTransfer, payload: TAutomationVariableDragPayload) => void;
export declare const getAutomationVariableDragData: (dataTransfer: DataTransfer) => TAutomationVariableDragPayload | null;
export declare const insertAutomationVariableToken: ({ value, token, selectionStart, selectionEnd, }: {
    value: string;
    token: string;
    selectionStart?: number | null;
    selectionEnd?: number | null;
}) => {
    nextValue: string;
    nextCursorPosition: number;
};
