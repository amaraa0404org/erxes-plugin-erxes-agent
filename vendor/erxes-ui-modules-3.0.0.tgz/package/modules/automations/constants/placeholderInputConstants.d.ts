import { SuggestionConfig, SuggestionItem, TPlaceholderInputSuggestionType } from '../types/placeholderInputTypes';
export declare const SUGGESTION_GROUPS: Record<string, TPlaceholderInputSuggestionType[]>;
export declare const DEFAULT_ENABLED_SUGGESTIONS: {
    attribute: boolean;
    emoji: boolean;
    date: boolean;
    option: boolean;
    call_user: boolean;
    call_tag: boolean;
    call_product: boolean;
    call_company: boolean;
    call_customer: boolean;
};
export declare const DATE_OPTIONS: SuggestionItem[];
export declare const DEFAULT_SUGGESTION_CONFIGS: SuggestionConfig[];
