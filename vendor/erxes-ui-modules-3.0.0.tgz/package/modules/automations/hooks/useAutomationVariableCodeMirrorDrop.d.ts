export declare const useAutomationVariableCodeMirrorDrop: ({ onChange, }: {
    onChange?: (value: string) => void;
}) => {
    isDragActive: boolean;
    editorExtensions: import("@codemirror/state").Extension[];
};
