import { RefObject } from 'react';
export declare const useAutomationVariableDrop: ({ value, onChange, inputRef, }: {
    value: string;
    onChange?: (value: string) => void;
    inputRef: RefObject<HTMLInputElement | HTMLTextAreaElement> | null;
}) => {
    isDragActive: boolean;
    handleDragOver: (event: React.DragEvent<HTMLInputElement | HTMLTextAreaElement>) => void;
    handleDragLeave: () => void;
    handleDrop: (event: React.DragEvent<HTMLInputElement | HTMLTextAreaElement>) => void;
};
