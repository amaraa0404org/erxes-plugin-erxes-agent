export declare const useAutomationOptionalConnect: ({ id, isAvailableOptionalConnect, flowDirection, }: {
    id: string;
    isAvailableOptionalConnect?: boolean;
    flowDirection?: "horizontal" | "vertical";
}) => ({ optionalId }: {
    optionalId: string;
}) => import("react/jsx-runtime").JSX.Element;
