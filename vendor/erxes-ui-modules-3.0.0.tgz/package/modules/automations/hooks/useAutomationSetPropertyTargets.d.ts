export type TAutomationPropertyTypeOption = {
    value: string;
    label?: string;
    description?: string;
    type?: string;
    source?: 'target' | 'relation' | 'resolver' | 'targetField';
    cardinality?: 'one' | 'many';
    sourceType?: string;
    relation?: {
        contentType: string;
        relatedContentType: string;
    };
    resolverKey?: string;
    targetPath?: string;
    pluginName?: string;
};
export declare const useAutomationSetPropertyTargets: (sourceType?: string) => {
    propertyTypes: TAutomationPropertyTypeOption[];
    loading: boolean;
};
