interface UseAutomationRemoteFormSubmitProps {
    formRef: React.RefObject<{
        submit: () => void;
    }>;
    callback: () => void;
}
export declare const useAutomationRemoteFormSubmit: ({ formRef, callback, }: UseAutomationRemoteFormSubmitProps) => void;
export {};
