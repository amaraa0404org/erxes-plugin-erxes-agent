import { IBlockEditor } from 'erxes-ui';
export declare const useAutomationVariableBlockEditorDrop: ({ editor, }: {
    editor: IBlockEditor;
}) => {
    isDragActive: boolean;
    handleDragOver: (event: React.DragEvent<HTMLElement>) => void;
    handleDragLeave: () => void;
    handleDrop: (event: React.DragEvent<HTMLElement>) => void;
};
