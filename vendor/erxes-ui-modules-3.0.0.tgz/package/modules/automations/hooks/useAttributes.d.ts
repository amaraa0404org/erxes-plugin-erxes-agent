export declare const useAttributes: ({ contentType, attributesConfig, additionalAttributes, attributeTypes, }: {
    contentType?: string;
    attributesConfig?: any;
    additionalAttributes?: any[];
    attributeTypes?: string[];
}) => {
    loading: boolean;
    groupAttributes: {
        [x: string]: any[];
    };
    attributes: any[];
};
