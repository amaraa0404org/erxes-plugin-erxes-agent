export declare enum TPlaceholderInputSuggestion {
    Attribute = "attribute",
    Emoji = "emoji",
    Date = "date",
    Option = "option",
    CallUser = "call_user",
    CallTag = "call_tag",
    CallProduct = "call_product",
    CallCompany = "call_company",
    CallCustomer = "call_customer"
}
export type TPlaceholderInputSuggestions = `${TPlaceholderInputSuggestion}`;
export type TPlaceholderInputSuggestionType = TPlaceholderInputSuggestion.Attribute | TPlaceholderInputSuggestion.Option | TPlaceholderInputSuggestion.Date | TPlaceholderInputSuggestion.Emoji | TPlaceholderInputSuggestion.CallUser | TPlaceholderInputSuggestion.CallTag | TPlaceholderInputSuggestion.CallProduct | TPlaceholderInputSuggestion.CallCustomer | TPlaceholderInputSuggestion.CallCompany;
export interface SuggestionItem {
    id: string;
    label: string;
    value: string;
    icon?: string;
}
export interface SuggestionConfig {
    type: string;
    trigger: string;
    title: string;
    mode?: 'command' | 'custom';
    render?: (props: CustomRendererProps) => React.ReactNode;
    options?: TPlaceholderInputSuggestionsOption;
}
export type EnabledSuggestions = readonly TPlaceholderInputSuggestionType[];
export type DisabledSuggestions = readonly TPlaceholderInputSuggestionType[];
type CustomRendererProps = {
    searchValue: string;
    onSelect: (value: string) => void;
    selectField: string;
};
export type TPlaceholderInputSuggestionsOption = {
    selectFieldName?: string;
    formatSelection?: (value: string) => string;
    options?: {
        label: string;
        value: string;
    }[];
    attributeTypes?: string[];
    additionalAttributes?: any[];
    attributesConfig?: any;
};
type InputMode = 'expression' | 'fixed';
type PlaceholderBehaviorConfig = {
    selectMode?: 'one' | 'many';
    delimiter?: string;
    wrap?: (text: string) => string;
    allowOnlyTriggers?: boolean;
};
type PlaceholderSuggestionProps = {
    enabled?: EnabledSuggestions;
    disabled?: DisabledSuggestions;
    suggestionGroups?: string[];
    suggestionsOptions?: Partial<Record<TPlaceholderInputSuggestions, TPlaceholderInputSuggestionsOption>>;
    enableAll?: boolean;
    selectionType?: TPlaceholderInputSuggestionType;
    extraSuggestionConfigs?: SuggestionConfig[];
};
type PlaceholderModeProps = {
    variant?: InputMode;
    isExpression?: boolean;
    onChangeInputMode?: (mode: InputMode) => void;
};
type CommonPlaceholderInputProps = PlaceholderSuggestionProps & PlaceholderModeProps & {
    value?: string;
    onChange?: (value: string) => void;
    placeholderConfig?: PlaceholderBehaviorConfig;
};
export type PlaceholderInputProps = Omit<CommonPlaceholderInputProps, 'onChange'> & {
    propertyType?: string;
    onChange: (value: string) => void;
    isDisabled?: boolean;
    popoverPosition?: 'left' | 'right' | 'top' | 'bottom';
    children?: React.ReactNode;
};
export type UsePlaceHolderInputProps = CommonPlaceholderInputProps & {
    ref: React.ForwardedRef<HTMLInputElement | HTMLTextAreaElement>;
    placeholderConfig?: PlaceholderBehaviorConfig & {
        wrapPrefix?: string;
        wrapSuffix?: string;
    };
};
export {};
