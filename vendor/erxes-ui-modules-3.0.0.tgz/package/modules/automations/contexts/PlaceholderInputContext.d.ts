import { type ReactNode } from 'react';
import type { SuggestionConfig } from '../types/placeholderInputTypes';
interface PlaceholderInputContextValue {
    enabledTypes: Record<string, boolean>;
    suggestions: SuggestionConfig[];
    inputVariant: 'expression' | 'fixed';
    suggestionTypeMap: Map<string, SuggestionConfig>;
    suggestionTypeByTriggerMap: Map<string, SuggestionConfig>;
    onInputModeChange?: (mode: 'expression' | 'fixed') => void;
    selectionType?: string;
    suggestionType?: string | null;
    value: string;
    onChange: (value: string) => void;
    showSuggestions: boolean;
    isSelectionPopoverOpen: boolean;
    insertSuggestion: (suggestion: string) => void;
    setIsSelectionPopoverOpen: (open: boolean) => void;
    inputRef: React.RefObject<HTMLInputElement | HTMLTextAreaElement>;
}
interface PlaceholderInputProviderProps {
    children: ReactNode;
    value: PlaceholderInputContextValue;
}
export declare function PlaceholderInputProvider({ children, value, }: PlaceholderInputProviderProps): import("react/jsx-runtime").JSX.Element;
export declare function usePlaceholderInputContext(): PlaceholderInputContextValue;
export {};
