import { TAutomationVariableDragPayload } from '../utils/automationVariableDragUtils';
export type TAutomationVariableInsertionTarget = (payload: TAutomationVariableDragPayload) => void;
type TAutomationVariableInsertionContext = {
    clearInsertionTarget: (target: TAutomationVariableInsertionTarget) => void;
    insertVariable: TAutomationVariableInsertionTarget;
    registerInsertionTarget: (target: TAutomationVariableInsertionTarget) => void;
};
export declare const AutomationVariableInsertionProvider: ({ children, }: {
    children: React.ReactNode;
}) => import("react/jsx-runtime").JSX.Element;
export declare const useAutomationVariableInsertion: () => TAutomationVariableInsertionContext;
export declare const useOptionalAutomationVariableInsertion: () => TAutomationVariableInsertionContext | null;
export {};
