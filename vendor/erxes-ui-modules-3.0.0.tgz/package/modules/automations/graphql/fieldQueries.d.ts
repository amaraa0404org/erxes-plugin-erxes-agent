/**
 * The form-field catalog automations builds its attribute list from. Segments
 * moved to their own declaration, so this query lives with the feature that
 * still uses it.
 */
export declare const FIELDS_COMBINED_BY_CONTENT_TYPE: import("graphql").DocumentNode;
/** Targets an automation can write a property onto, for a given source. */
export declare const AUTOMATION_SET_PROPERTY_TARGETS: import("graphql").DocumentNode;
/** Both halves the property rule editor needs in one round trip. */
export declare const AUTOMATION_PROPERTIES_WITH_FIELDS: import("graphql").DocumentNode;
