type Props = {
    contentType: string;
    onSelect: (value: string) => void;
    customAttributions?: any[];
    attrConfig?: any;
    trigger?: React.ReactNode;
    ref?: any;
    buttonText?: string;
};
export declare const Attributes: ({ trigger, contentType, attrConfig, customAttributions, onSelect, ref, buttonText, }: Props) => import("react/jsx-runtime").JSX.Element;
export declare const RenderAttributes: ({ contentType, attrConfig, customAttributions, onSelect, }: {
    contentType: string;
    attrConfig: any;
    customAttributions?: any[];
    onSelect: (value: string) => void;
}) => import("react/jsx-runtime").JSX.Element[];
export {};
