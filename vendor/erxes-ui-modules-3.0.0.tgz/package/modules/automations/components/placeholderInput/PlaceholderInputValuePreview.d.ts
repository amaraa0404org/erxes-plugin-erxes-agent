type PlaceholderInputValuePreviewProps = {
    value: string;
    variant: 'expression' | 'fixed';
};
export declare const PlaceholderInputValuePreview: ({ value, variant, }: PlaceholderInputValuePreviewProps) => import("react/jsx-runtime").JSX.Element | null;
export {};
