export declare const TagsCommandList: ({ searchValue, onSelect, selectField, }: {
    searchValue: string;
    onSelect: (value: string) => void;
    selectField?: string;
}) => import("react/jsx-runtime").JSX.Element;
