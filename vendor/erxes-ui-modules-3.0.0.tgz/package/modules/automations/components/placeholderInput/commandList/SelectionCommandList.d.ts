type SelectionProps = {
    selectionConfig: any;
    onSelect: (value: string) => void;
};
export declare const SelectionCommandList: ({ selectionConfig, onSelect, }: SelectionProps) => import("react/jsx-runtime").JSX.Element | null;
export {};
