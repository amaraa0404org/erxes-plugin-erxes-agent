export declare const AttributesCommandList: ({ contentType, attributesConfig, additionalAttributes, attributeTypes, onSelect, }: {
    contentType?: string;
    attributesConfig?: any;
    additionalAttributes?: any[];
    attributeTypes?: string[];
    onSelect: (value: string) => void;
}) => import("react/jsx-runtime").JSX.Element;
