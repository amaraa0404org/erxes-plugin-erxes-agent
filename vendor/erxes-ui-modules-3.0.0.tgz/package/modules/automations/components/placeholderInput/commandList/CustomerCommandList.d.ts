export declare const CustomerCommandList: ({ searchValue, onSelect, selectField, }: {
    searchValue: string;
    onSelect: (value: string) => void;
    selectField?: string;
}) => import("react/jsx-runtime").JSX.Element;
