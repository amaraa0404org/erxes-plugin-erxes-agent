export declare const ProducsCommandList: ({ searchValue, onSelect, selectField, }: {
    searchValue: string;
    onSelect: (value: string) => void;
    selectField?: string;
}) => import("react/jsx-runtime").JSX.Element;
