import type { ReactNode } from 'react';
interface GenericCommandListProps<TItem extends Record<string, any>> {
    heading: string;
    items: TItem[];
    totalCount: number;
    handleFetchMore: () => void;
    onSelect: (value: string) => void;
    getKey: (item: TItem) => string;
    renderItem: (item: TItem) => ReactNode;
    selectField?: string;
    getSelectValue?: (item: TItem) => string;
    loading?: boolean;
}
export declare function GenericCommandList<TItem extends Record<string, any>>({ heading, items, totalCount, handleFetchMore, onSelect, getKey, renderItem, selectField, getSelectValue, loading, }: GenericCommandListProps<TItem>): import("react/jsx-runtime").JSX.Element;
export {};
