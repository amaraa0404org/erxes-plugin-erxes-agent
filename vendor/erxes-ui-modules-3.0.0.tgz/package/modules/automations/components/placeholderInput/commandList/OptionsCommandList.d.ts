export declare const OptionsCommandList: ({ selectOptions, onSelect, }: {
    selectOptions: {
        label: string;
        value: string;
    }[];
    onSelect: (value: string) => void;
}) => import("react/jsx-runtime").JSX.Element;
