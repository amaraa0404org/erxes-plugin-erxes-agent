export declare const PlaceholderInput: import("react").ForwardRefExoticComponent<Omit<{
    enabled?: import("../../types/placeholderInputTypes").EnabledSuggestions;
    disabled?: import("../../types/placeholderInputTypes").DisabledSuggestions;
    suggestionGroups?: string[];
    suggestionsOptions?: Partial<Record<import("../../types/placeholderInputTypes").TPlaceholderInputSuggestions, import("../../types/placeholderInputTypes").TPlaceholderInputSuggestionsOption>>;
    enableAll?: boolean;
    selectionType?: import("../../types/placeholderInputTypes").TPlaceholderInputSuggestionType;
    extraSuggestionConfigs?: import("../../types/placeholderInputTypes").SuggestionConfig[];
} & {
    variant?: "fixed" | "expression";
    isExpression?: boolean;
    onChangeInputMode?: (mode: "fixed" | "expression") => void;
} & {
    value?: string;
    onChange?: (value: string) => void;
    placeholderConfig?: {
        selectMode?: "one" | "many";
        delimiter?: string;
        wrap?: (text: string) => string;
        allowOnlyTriggers?: boolean;
    };
}, "onChange"> & {
    propertyType?: string;
    onChange: (value: string) => void;
    isDisabled?: boolean;
    popoverPosition?: "left" | "right" | "top" | "bottom";
    children?: React.ReactNode;
} & import("react").RefAttributes<HTMLInputElement | HTMLTextAreaElement>> & {
    Header: typeof import("./PlaceholderInputHeader").PlaceholderInputHeaderComponent;
};
