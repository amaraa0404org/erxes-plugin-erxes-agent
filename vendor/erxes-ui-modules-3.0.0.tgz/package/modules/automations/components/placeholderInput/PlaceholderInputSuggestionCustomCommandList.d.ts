export declare const PlaceholderInputSuggestionCustomCommandList: ({ searchValue, onSelect, selectField, suggestionType, }: {
    suggestionType: string;
    searchValue: string;
    onSelect: (value: string) => void;
    selectField: string;
}) => import("react/jsx-runtime").JSX.Element | null;
