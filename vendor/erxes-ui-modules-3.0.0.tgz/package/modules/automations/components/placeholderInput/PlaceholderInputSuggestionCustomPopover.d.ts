export declare const PlaceholderInputSuggestionCustomPopover: ({ suggestionType, title, trigger, searchValue, onSelect, onClose, selectFieldName, internalRef, positionStyle, }: {
    suggestionType: string;
    title: string;
    trigger?: string;
    searchValue: string;
    onSelect: (suggestion: string) => void;
    onClose: () => void;
    selectFieldName: string;
    internalRef: React.RefObject<HTMLDivElement>;
    positionStyle?: React.CSSProperties;
}) => import("react/jsx-runtime").JSX.Element | null;
