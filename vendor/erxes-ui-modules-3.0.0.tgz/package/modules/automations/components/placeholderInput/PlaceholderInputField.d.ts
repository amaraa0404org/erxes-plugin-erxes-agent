type PlaceholderInputFieldProps = {
    value: string;
    onChange: (value: string) => void;
    onKeyDown: (e: React.KeyboardEvent<HTMLInputElement | HTMLTextAreaElement>) => void;
    onBlur?: (e: React.FocusEvent<HTMLInputElement | HTMLTextAreaElement>) => void;
    onFocus?: (e: React.FocusEvent<HTMLInputElement | HTMLTextAreaElement>) => void;
    isDisabled?: boolean;
    readOnly?: boolean;
    isDragActive?: boolean;
    onDragOver?: (e: React.DragEvent<HTMLInputElement | HTMLTextAreaElement>) => void;
    onDragLeave?: (e: React.DragEvent<HTMLInputElement | HTMLTextAreaElement>) => void;
    onDrop?: (e: React.DragEvent<HTMLInputElement | HTMLTextAreaElement>) => void;
};
export declare const PlaceholderInputField: import("react").ForwardRefExoticComponent<PlaceholderInputFieldProps & import("react").RefAttributes<HTMLInputElement | HTMLTextAreaElement>>;
export {};
