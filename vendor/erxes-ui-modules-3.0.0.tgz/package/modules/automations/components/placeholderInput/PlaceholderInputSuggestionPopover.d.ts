interface SuggestionPopoverProps {
    searchQuery: string;
    onClose: () => void;
    cursorPosition: number;
    contentType?: string;
    popoverPosition?: 'left' | 'right' | 'top' | 'bottom';
}
export declare const PlaceholderInputSuggestionPopover: import("react").ForwardRefExoticComponent<SuggestionPopoverProps & import("react").RefAttributes<HTMLDivElement>>;
export {};
