export declare function PlaceholderInputHeaderComponent(): import("react/jsx-runtime").JSX.Element;
export declare namespace PlaceholderInputHeaderComponent {
    var displayName: string;
}
export declare const PlaceholderInputHeader: typeof PlaceholderInputHeaderComponent;
