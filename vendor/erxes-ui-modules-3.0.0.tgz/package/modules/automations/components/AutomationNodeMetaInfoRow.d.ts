export declare const AutomationNodeMetaInfoRow: ({ fieldName, content, className, }: {
    fieldName: string;
    content: React.ReactNode;
    className?: string;
}) => import("react/jsx-runtime").JSX.Element;
