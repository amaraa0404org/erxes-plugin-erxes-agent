/**
 * The shared vocabulary every automation action result is built from — core
 * actions and plugin actions alike. An action declares what it has (status,
 * fields, a long body, raw json) and these render it the same way everywhere,
 * so no result has to invent its own layout or open its own dialog.
 */
export declare const ActionResult: (({ children }: {
    children: import("react").ReactNode;
}) => import("react/jsx-runtime").JSX.Element) & {
    Status: ({ status, children, }: {
        status?: import("./ActionResultParts").TActionResultStatus;
        children: import("react").ReactNode;
    }) => import("react/jsx-runtime").JSX.Element;
    Fields: ({ children }: {
        children: import("react").ReactNode;
    }) => import("react/jsx-runtime").JSX.Element;
    Field: ({ label, value, badge, }: {
        label: string;
        value?: import("react").ReactNode;
        badge?: "success" | "destructive" | "secondary";
    }) => import("react/jsx-runtime").JSX.Element | null;
    Body: ({ title, html, children, }: {
        title: string;
        html?: string;
        children?: import("react").ReactNode;
    }) => import("react/jsx-runtime").JSX.Element | null;
    Json: ({ value }: {
        value: unknown;
    }) => import("react/jsx-runtime").JSX.Element;
};
