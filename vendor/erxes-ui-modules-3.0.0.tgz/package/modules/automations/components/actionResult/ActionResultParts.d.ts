import { ReactNode } from 'react';
import { IAutomationHistoryAction } from '../../types/automationTypes';
export type TActionResultStatus = NonNullable<IAutomationHistoryAction['status']>;
export declare const ActionResultLayout: ({ children }: {
    children: ReactNode;
}) => import("react/jsx-runtime").JSX.Element;
export declare const ActionResultStatus: ({ status, children, }: {
    status?: TActionResultStatus;
    children: ReactNode;
}) => import("react/jsx-runtime").JSX.Element;
export declare const ActionResultFields: ({ children }: {
    children: ReactNode;
}) => import("react/jsx-runtime").JSX.Element;
export declare const ActionResultField: ({ label, value, badge, }: {
    label: string;
    value?: ReactNode;
    badge?: "success" | "destructive" | "secondary";
}) => import("react/jsx-runtime").JSX.Element | null;
/**
 * Long content (email bodies, payloads, raw responses). It opens as a short
 * teaser so a large body cannot bury the rest of the result, and expands in
 * place — the result panel scrolls, so nothing has to move into a dialog.
 */
export declare const ActionResultBody: ({ title, html, children, }: {
    title: string;
    html?: string;
    children?: ReactNode;
}) => import("react/jsx-runtime").JSX.Element | null;
export declare const ActionResultJson: ({ value }: {
    value: unknown;
}) => import("react/jsx-runtime").JSX.Element;
