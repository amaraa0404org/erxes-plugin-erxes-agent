import React from 'react';
import { AutomationRemoteEntryComponentType, AutomationRemoteEntryTypes } from '../types/automationTypes';
export declare const AutomationRemoteEntryWrapper: <T extends AutomationRemoteEntryComponentType>({ props, remoteEntries, }: {
    props: AutomationRemoteEntryTypes[T] & {
        componentType: T;
    };
    remoteEntries: { [K in AutomationRemoteEntryComponentType]?: React.LazyExoticComponent<React.ComponentType<AutomationRemoteEntryTypes[K]>> | React.ComponentType<AutomationRemoteEntryTypes[K]>; };
}) => import("react/jsx-runtime").JSX.Element | null;
