import { Dispatch, SetStateAction } from 'react';
import { IUser } from '../types/TeamMembers';
export type ISelectMemberContext = {
    memberIds: string[];
    onSelect: (member: IUser | null) => void;
    members: IUser[];
    setMembers: Dispatch<SetStateAction<IUser[]>>;
    loading: boolean;
    allowUnassigned: boolean;
};
export declare const SelectMemberContext: import("react").Context<ISelectMemberContext | null>;
export declare const useSelectMemberContext: () => ISelectMemberContext;
