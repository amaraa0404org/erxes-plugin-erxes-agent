import { Dispatch, SetStateAction } from 'react';
import { AvatarProps } from 'erxes-ui';
import { IUser } from '../types/TeamMembers';
export interface IUsersInlineContext {
    members: IUser[];
    loading: boolean;
    memberIds?: string[];
    placeholder: string;
    size?: AvatarProps['size'];
    updateMembers?: Dispatch<SetStateAction<IUser[]>>;
    allowUnassigned?: boolean;
}
export declare const MembersInlineContext: import("react").Context<IUsersInlineContext | null>;
export declare const useMembersInlineContext: () => IUsersInlineContext;
