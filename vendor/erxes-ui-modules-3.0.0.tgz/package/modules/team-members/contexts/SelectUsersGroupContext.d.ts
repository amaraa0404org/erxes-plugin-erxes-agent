import { IUserGroupContext } from '../types/TeamMembers';
export declare const SelectUsersGroupContext: import("react").Context<IUserGroupContext>;
