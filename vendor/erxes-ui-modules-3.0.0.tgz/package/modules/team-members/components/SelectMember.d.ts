import { AvatarProps } from 'erxes-ui';
import React from 'react';
import { IUser } from '../types/TeamMembers';
declare const SelectMemberProvider: ({ children, mode, value, onValueChange, members, setOpen, allowUnassigned, }: {
    children: React.ReactNode;
    mode?: "single" | "multiple";
    value?: string[] | string;
    onValueChange?: (value: string[] | string | null) => void;
    members?: IUser[];
    setOpen?: (open: boolean) => void;
    allowUnassigned?: boolean;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectMemberFilterItem: ({ value, label, }: {
    value?: string;
    label?: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectMemberFilterView: ({ onValueChange, queryKey, mode, }: {
    onValueChange?: (value: string[] | string | null) => void;
    queryKey?: string;
    mode?: "single" | "multiple";
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectMemberFilterBar: ({ iconOnly, onValueChange, queryKey, mode, label, }: {
    iconOnly?: boolean;
    onValueChange?: (value: string[] | string | null) => void;
    queryKey?: string;
    mode?: "single" | "multiple";
    label?: string;
}) => import("react/jsx-runtime").JSX.Element | null;
export declare const SelectMemberInlineCell: React.ForwardRefExoticComponent<Omit<Omit<{
    children: React.ReactNode;
    mode?: "single" | "multiple";
    value?: string[] | string;
    onValueChange?: (value: string[] | string | null) => void;
    members?: IUser[];
    setOpen?: (open: boolean) => void;
    allowUnassigned?: boolean;
}, "children"> & Omit<import("erxes-ui").ButtonProps & React.RefAttributes<HTMLButtonElement>, "ref"> & React.RefAttributes<HTMLButtonElement> & {
    scope?: string;
    placeholder?: string;
    size?: AvatarProps["size"];
}, "ref"> & React.RefAttributes<HTMLButtonElement>>;
export declare const SelectMemberFormItem: ({ onValueChange, className, placeholder, ...props }: Omit<React.ComponentProps<typeof SelectMemberProvider>, "children"> & {
    className?: string;
    placeholder?: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectMemberDetail: ({ onValueChange, className, size, placeholder, value, ...props }: Omit<React.ComponentProps<typeof SelectMemberProvider>, "children"> & {
    className?: string;
    size?: "lg" | "sm" | "xl" | "default" | "xs";
    placeholder?: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectMemberRoot: ({ onValueChange, className, size, placeholder, scope, ...props }: Omit<React.ComponentProps<typeof SelectMemberProvider>, "children"> & {
    className?: string;
    size?: "lg" | "sm" | "xl" | "default" | "xs";
    placeholder?: string;
    scope?: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectMemberCustomDetail: ({ onValueChange, className, size, value, ...props }: Omit<React.ComponentProps<typeof SelectMemberProvider>, "children"> & {
    className?: string;
    size?: "lg" | "sm" | "xl" | "default" | "xs";
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectMember: (({ onValueChange, className, size, placeholder, scope, ...props }: Omit<React.ComponentProps<typeof SelectMemberProvider>, "children"> & {
    className?: string;
    size?: "lg" | "sm" | "xl" | "default" | "xs";
    placeholder?: string;
    scope?: string;
}) => import("react/jsx-runtime").JSX.Element) & {
    Provider: ({ children, mode, value, onValueChange, members, setOpen, allowUnassigned, }: {
        children: React.ReactNode;
        mode?: "single" | "multiple";
        value?: string[] | string;
        onValueChange?: (value: string[] | string | null) => void;
        members?: IUser[];
        setOpen?: (open: boolean) => void;
        allowUnassigned?: boolean;
    }) => import("react/jsx-runtime").JSX.Element;
    Value: ({ placeholder, size, }: {
        placeholder?: string;
        size?: AvatarProps["size"];
    }) => import("react/jsx-runtime").JSX.Element;
    Content: () => import("react/jsx-runtime").JSX.Element;
    CommandItem: ({ user }: {
        user: IUser;
    }) => import("react/jsx-runtime").JSX.Element;
    NoAssigneeItem: () => import("react/jsx-runtime").JSX.Element;
    FilterItem: ({ value, label, }: {
        value?: string;
        label?: string;
    }) => import("react/jsx-runtime").JSX.Element;
    FilterView: ({ onValueChange, queryKey, mode, }: {
        onValueChange?: (value: string[] | string | null) => void;
        queryKey?: string;
        mode?: "single" | "multiple";
    }) => import("react/jsx-runtime").JSX.Element;
    FilterBar: ({ iconOnly, onValueChange, queryKey, mode, label, }: {
        iconOnly?: boolean;
        onValueChange?: (value: string[] | string | null) => void;
        queryKey?: string;
        mode?: "single" | "multiple";
        label?: string;
    }) => import("react/jsx-runtime").JSX.Element | null;
    InlineCell: React.ForwardRefExoticComponent<Omit<Omit<{
        children: React.ReactNode;
        mode?: "single" | "multiple";
        value?: string[] | string;
        onValueChange?: (value: string[] | string | null) => void;
        members?: IUser[];
        setOpen?: (open: boolean) => void;
        allowUnassigned?: boolean;
    }, "children"> & Omit<import("erxes-ui").ButtonProps & React.RefAttributes<HTMLButtonElement>, "ref"> & React.RefAttributes<HTMLButtonElement> & {
        scope?: string;
        placeholder?: string;
        size?: AvatarProps["size"];
    }, "ref"> & React.RefAttributes<HTMLButtonElement>>;
    FormItem: ({ onValueChange, className, placeholder, ...props }: Omit<React.ComponentProps<typeof SelectMemberProvider>, "children"> & {
        className?: string;
        placeholder?: string;
    }) => import("react/jsx-runtime").JSX.Element;
    Detail: ({ onValueChange, className, size, placeholder, value, ...props }: Omit<React.ComponentProps<typeof SelectMemberProvider>, "children"> & {
        className?: string;
        size?: "lg" | "sm" | "xl" | "default" | "xs";
        placeholder?: string;
    }) => import("react/jsx-runtime").JSX.Element;
    CustomDetail: ({ onValueChange, className, size, value, ...props }: Omit<React.ComponentProps<typeof SelectMemberProvider>, "children"> & {
        className?: string;
        size?: "lg" | "sm" | "xl" | "default" | "xs";
    }) => import("react/jsx-runtime").JSX.Element;
};
export {};
