import React from 'react';
declare const SelectUsersGroupProvider: ({ children, mode, value, onValueChange, }: {
    children: React.ReactNode;
    mode?: "single" | "multiple";
    value?: string[] | string;
    onValueChange?: (value: string[] | string) => void;
}) => import("react/jsx-runtime").JSX.Element;
export declare const UsersGroupContent: () => import("react/jsx-runtime").JSX.Element;
export declare const SelectUsersGroupFormItem: ({ className, ...props }: Omit<React.ComponentProps<typeof SelectUsersGroupProvider>, "children"> & {
    className?: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectUsersGroupBar: () => import("react/jsx-runtime").JSX.Element;
export declare const SelectUsersGroup: {
    Value: ({ placeholder }: {
        placeholder?: string;
    }) => import("react/jsx-runtime").JSX.Element;
    Content: () => import("react/jsx-runtime").JSX.Element;
    Provider: ({ children, mode, value, onValueChange, }: {
        children: React.ReactNode;
        mode?: "single" | "multiple";
        value?: string[] | string;
        onValueChange?: (value: string[] | string) => void;
    }) => import("react/jsx-runtime").JSX.Element;
    FormItem: ({ className, ...props }: Omit<React.ComponentProps<typeof SelectUsersGroupProvider>, "children"> & {
        className?: string;
    }) => import("react/jsx-runtime").JSX.Element;
    FilterItem: () => import("react/jsx-runtime").JSX.Element;
    FilterView: () => import("react/jsx-runtime").JSX.Element;
    FilterBar: () => import("react/jsx-runtime").JSX.Element;
};
export {};
