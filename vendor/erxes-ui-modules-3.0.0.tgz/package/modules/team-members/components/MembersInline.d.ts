import { AvatarProps } from 'erxes-ui';
import type { Dispatch, ReactNode, SetStateAction } from 'react';
import { IUser } from 'ui-modules/modules/team-members/types/TeamMembers';
export declare const MembersInlineRoot: ({ members, memberIds, placeholder, updateMembers, className, size, allowUnassigned, }: {
    members?: IUser[];
    memberIds?: string[];
    placeholder?: string;
    updateMembers?: Dispatch<SetStateAction<IUser[]>>;
    className?: string;
    size?: AvatarProps["size"];
    allowUnassigned?: boolean;
}) => import("react/jsx-runtime").JSX.Element;
export declare const MembersInlineProvider: ({ children, memberIds, members, placeholder, updateMembers, size, allowUnassigned, }: {
    children?: ReactNode;
    memberIds?: string[];
    members?: IUser[];
    placeholder?: string;
    updateMembers?: Dispatch<SetStateAction<IUser[]>>;
    size?: AvatarProps["size"];
    allowUnassigned?: boolean;
}) => import("react/jsx-runtime").JSX.Element;
export declare const MembersInlineAvatar: ({ className, containerClassName, ...props }: AvatarProps & {
    containerClassName?: string;
}) => import("react/jsx-runtime").JSX.Element | null;
export declare const MembersInlineTitle: ({ className }: {
    className?: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const MembersInline: (({ members, memberIds, placeholder, updateMembers, className, size, allowUnassigned, }: {
    members?: IUser[];
    memberIds?: string[];
    placeholder?: string;
    updateMembers?: Dispatch<SetStateAction<IUser[]>>;
    className?: string;
    size?: AvatarProps["size"];
    allowUnassigned?: boolean;
}) => import("react/jsx-runtime").JSX.Element) & {
    Provider: ({ children, memberIds, members, placeholder, updateMembers, size, allowUnassigned, }: {
        children?: ReactNode;
        memberIds?: string[];
        members?: IUser[];
        placeholder?: string;
        updateMembers?: Dispatch<SetStateAction<IUser[]>>;
        size?: AvatarProps["size"];
        allowUnassigned?: boolean;
    }) => import("react/jsx-runtime").JSX.Element;
    Avatar: ({ className, containerClassName, ...props }: AvatarProps & {
        containerClassName?: string;
    }) => import("react/jsx-runtime").JSX.Element | null;
    Title: ({ className }: {
        className?: string;
    }) => import("react/jsx-runtime").JSX.Element;
};
