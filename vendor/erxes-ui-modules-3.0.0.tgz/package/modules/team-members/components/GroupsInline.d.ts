import { IUserGroup } from 'ui-modules/modules/team-members/types/TeamMembers';
export interface IGroupsInlineContext {
    groups: IUserGroup[];
    loading: boolean;
    groupsIds?: string[];
    placeholder?: string;
    updateGroups?: (groups: IUserGroup[]) => void;
}
export declare const GroupsInlineContext: import("react").Context<IGroupsInlineContext | null>;
export declare const useGroupsInlineContext: () => IGroupsInlineContext;
export declare const GroupsInline: ({ groups, groupsIds, placeholder, updateGroups, }: {
    groups: IUserGroup[];
    groupsIds?: string[];
    placeholder?: string;
    updateGroups?: (groups: IUserGroup[]) => void;
}) => import("react/jsx-runtime").JSX.Element;
export declare const GroupsInlineProvider: ({ children, groups, groupsIds, placeholder, updateGroups, }: {
    children?: React.ReactNode;
    groups?: IUserGroup[];
    groupsIds?: string[];
    placeholder?: string;
    updateGroups?: (groups: IUserGroup[]) => void;
}) => import("react/jsx-runtime").JSX.Element;
export declare const GroupInlineEffectComponent: ({ groupId, }: {
    groupId: string;
}) => null;
export declare const GroupsInlineTitle: () => import("react/jsx-runtime").JSX.Element;
