import { SuggestionMenuProps } from '@blocknote/react';
import { IBlockEditor } from 'erxes-ui';
export declare const AssignMemberInEditor: ({ editor }: {
    editor: IBlockEditor;
}) => import("react/jsx-runtime").JSX.Element;
export declare function MentionMenu(props: SuggestionMenuProps<any>): import("react/jsx-runtime").JSX.Element;
