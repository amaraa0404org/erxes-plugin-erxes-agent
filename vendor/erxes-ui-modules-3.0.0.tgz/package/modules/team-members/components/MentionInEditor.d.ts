import { IBlockEditor } from 'erxes-ui';
export type EditorMentionItem = {
    id: string;
    fullName: string;
    avatar?: string;
};
export declare const MentionInEditor: ({ editor, participants, emptyText, searchItems, statusNote, }: {
    editor: IBlockEditor;
    participants: EditorMentionItem[];
    emptyText?: string;
    searchItems?: (query: string) => Promise<EditorMentionItem[]>;
    statusNote?: string;
}) => import("react/jsx-runtime").JSX.Element;
