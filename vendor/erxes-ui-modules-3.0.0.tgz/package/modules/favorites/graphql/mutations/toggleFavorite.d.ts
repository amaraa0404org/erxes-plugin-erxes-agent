export declare const TOGGLE_FAVORITE: import("@apollo/client").DocumentNode;
