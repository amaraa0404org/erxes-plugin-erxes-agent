export declare const IS_FAVORITE: import("@apollo/client").DocumentNode;
