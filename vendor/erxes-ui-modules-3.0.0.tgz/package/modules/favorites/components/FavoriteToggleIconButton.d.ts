import { FavoriteToggleParams } from '../types';
export declare function FavoriteToggleIconButton(params: Readonly<FavoriteToggleParams>): import("react/jsx-runtime").JSX.Element;
