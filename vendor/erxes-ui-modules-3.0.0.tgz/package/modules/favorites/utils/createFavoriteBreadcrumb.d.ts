import { FavoriteBreadcrumbSegment } from '../types';
export declare const createFavoriteBreadcrumb: (...segments: FavoriteBreadcrumbSegment[]) => string[];
