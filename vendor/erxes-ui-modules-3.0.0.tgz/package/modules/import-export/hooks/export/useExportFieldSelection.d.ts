import { TExportHeader } from '../../types/export/exportTypes';
export declare const useExportFieldSelection: ({ entityType, filters, open, onConfirm, onOpenChange, }: {
    entityType: string;
    filters?: Record<string, any>;
    open: boolean;
    onConfirm: (selectedFields: string[]) => void;
    onOpenChange: (open: boolean) => void;
}) => {
    selectedFields: string[];
    headers: TExportHeader[];
    loading: boolean;
    handleConfirm: () => void;
    handleDeselectAll: () => void;
    handleSelectAll: () => void;
    handleSelectDefaults: () => void;
    handleToggleField: (key: string) => void;
};
