import { TExportProgressInfo, TExportProgress } from '../../types/export/exportTypes';
export declare function useExportProgress(exportItem: TExportProgress | undefined): TExportProgressInfo | null;
export declare function formatTime(minutes: number): string;
