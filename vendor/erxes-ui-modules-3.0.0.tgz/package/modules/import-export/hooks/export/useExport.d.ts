export declare const useExport: ({ entityType, ids, getFilters, confirmMessage, }: {
    entityType: string;
    ids?: string[];
    getFilters?: () => Record<string, any>;
    confirmMessage: string;
}) => {
    startExport: (entityType: string, options?: {
        filters?: Record<string, any>;
        ids?: string[];
        selectedFields?: string[];
    }) => Promise<any>;
    loading: boolean;
    onFieldSelectionConfirm: (selectedFields: string[]) => void;
};
