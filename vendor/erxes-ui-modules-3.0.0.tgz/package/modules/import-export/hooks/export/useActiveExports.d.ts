import { TExportProgress } from '../../types/export/exportTypes';
export declare const useActiveExports: ({ entityType }: {
    entityType: string;
}) => {
    activeExports: TExportProgress[];
    hasActiveExports: boolean;
    refetch: (variables?: Partial<import("@apollo/client").OperationVariables> | undefined) => Promise<import("@apollo/client").ApolloQueryResult<any>>;
    startPolling: (pollInterval: number) => void;
    stopPolling: () => void;
    handleRetry: (exportId: string) => void;
    cancelExport: (exportId: string) => Promise<any>;
    loading: boolean;
};
