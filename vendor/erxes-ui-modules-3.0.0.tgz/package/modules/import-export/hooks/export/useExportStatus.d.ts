import { TExportProgress, TUseExportStatusReturn } from '../../types/export/exportTypes';
export declare function useExportStatus(exportItem: TExportProgress | undefined): TUseExportStatusReturn;
