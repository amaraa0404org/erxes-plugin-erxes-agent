/**
 * The name of the records being imported or exported, in the user's language.
 *
 * Collection names are English identifiers, so a translation is used whenever
 * one exists and the derived English label is the fallback for the entity
 * types plugins bring along.
 */
export declare const useEntityLabel: (collectionName: string, options?: {
    plural?: boolean;
    capitalize?: boolean;
}) => string;
