export declare const START_EXPORT: import("@apollo/client").DocumentNode;
export declare const CANCEL_EXPORT: import("@apollo/client").DocumentNode;
export declare const RETRY_EXPORT: import("@apollo/client").DocumentNode;
