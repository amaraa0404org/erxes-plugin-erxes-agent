export declare const GET_ACTIVE_EXPORTS: import("@apollo/client").DocumentNode;
export declare const GET_EXPORT_HEADERS: import("@apollo/client").DocumentNode;
