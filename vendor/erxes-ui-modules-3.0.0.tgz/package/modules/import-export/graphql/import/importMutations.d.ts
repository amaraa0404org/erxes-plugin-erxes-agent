export declare const START_IMPORT: import("@apollo/client").DocumentNode;
export declare const CANCEL_IMPORT: import("@apollo/client").DocumentNode;
export declare const RETRY_IMPORT: import("@apollo/client").DocumentNode;
export declare const RESUME_IMPORT: import("@apollo/client").DocumentNode;
