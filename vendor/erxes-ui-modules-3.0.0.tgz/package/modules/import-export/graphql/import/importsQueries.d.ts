export declare const GET_ACTIVE_IMPORTS: import("@apollo/client").DocumentNode;
export declare const GET_IMPORT_HISTORIES: import("@apollo/client").DocumentNode;
export declare const IMPORT_COLUMN_PREVIEW: import("@apollo/client").DocumentNode;
export declare const IMPORT_FIELDS: import("@apollo/client").DocumentNode;
