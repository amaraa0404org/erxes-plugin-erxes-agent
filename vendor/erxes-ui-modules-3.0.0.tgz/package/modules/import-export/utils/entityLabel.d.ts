export declare const formatEntityLabel: (value: string, options?: {
    plural?: boolean;
    capitalize?: boolean;
}) => string;
export declare const getEntityLabelFromType: (entityType: string, options?: {
    plural?: boolean;
    capitalize?: boolean;
}) => string;
