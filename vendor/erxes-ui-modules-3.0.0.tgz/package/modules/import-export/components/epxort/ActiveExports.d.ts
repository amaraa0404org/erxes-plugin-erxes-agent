import { buttonVariants } from 'erxes-ui';
import { VariantProps } from 'class-variance-authority';
export declare const ActiveExports: ({ entityType, entityDisplayName, selectionCount, onStartExport, }: {
    entityType: string;
    entityDisplayName: string;
    selectionCount?: number;
    onStartExport: () => void;
}) => import("react/jsx-runtime").JSX.Element;
export declare const ActiveExportsPopover: ({ buttonVariant, entityType, entityDisplayName, selectionCount, onStartExport, }: {
    buttonVariant: VariantProps<typeof buttonVariants>["variant"];
    entityType: string;
    entityDisplayName: string;
    selectionCount?: number;
    onStartExport: () => void;
}) => import("react/jsx-runtime").JSX.Element;
