import { TExportProgress } from '../../types/export/exportTypes';
export declare function ExportProgress({ exportItem, onRetry, }: {
    exportItem: TExportProgress;
    onRetry?: (exportId: string) => void;
}): import("react/jsx-runtime").JSX.Element | null;
