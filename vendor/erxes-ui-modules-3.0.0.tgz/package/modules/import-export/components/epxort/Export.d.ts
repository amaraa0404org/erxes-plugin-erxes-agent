import { VariantProps } from 'class-variance-authority';
import { buttonVariants } from 'erxes-ui';
export declare const Export: ({ pluginName, moduleName, collectionName, buttonVariant, ids, getFilters, confirmMessage, }: {
    pluginName: string;
    moduleName: string;
    collectionName: string;
    buttonVariant?: VariantProps<typeof buttonVariants>["variant"];
    ids?: string[];
    getFilters?: () => Record<string, any>;
    confirmMessage?: string;
}) => import("react/jsx-runtime").JSX.Element;
