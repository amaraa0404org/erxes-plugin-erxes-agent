import { TExportFieldSelectionProps, TSearchAndActionsProps } from '../../types/export/exportTypes';
export declare function SearchAndActions({ onSelectAll, onDeselectAll, onSelectDefaults, selectedCount, totalCount, }: TSearchAndActionsProps): import("react/jsx-runtime").JSX.Element;
export declare function ExportFieldSelection({ entityType, open, onOpenChange, onConfirm, recordCount, entityDisplayName, filters, }: TExportFieldSelectionProps): import("react/jsx-runtime").JSX.Element;
