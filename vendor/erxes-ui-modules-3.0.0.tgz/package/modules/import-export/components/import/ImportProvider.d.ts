import type { ChangeEvent, DragEvent, ReactNode } from 'react';
import type { TImportProgress, TPendingImportUpload } from '../../types/import/importTypes';
interface ImportContextType {
    activeImports: TImportProgress[];
    pendingUpload: TPendingImportUpload | null;
    clearPendingUpload: () => void;
    isDragOver: boolean;
    handleDragOver: (e: DragEvent) => void;
    handleDragLeave: (e: DragEvent) => void;
    handleDrop: (e: DragEvent) => void;
    handleFileSelect: (e: ChangeEvent<HTMLInputElement>) => void;
    handleClickUpload: (inputId?: string) => void;
    handleDownloadTemplate: () => void;
    isLoading: boolean;
    inputId: string;
    entityLabel: string;
    entityPluralLabel: string;
    resolvedTitle: string;
    contentType: string;
}
export declare const ImportProvider: ({ children, pluginName, moduleName, collectionName, title, onFileUploaded, }: {
    children: ReactNode;
    pluginName: string;
    moduleName: string;
    collectionName: string;
    title: string;
    onFileUploaded?: (file: File) => void;
}) => import("react/jsx-runtime").JSX.Element;
export declare const useImport: () => ImportContextType;
export {};
