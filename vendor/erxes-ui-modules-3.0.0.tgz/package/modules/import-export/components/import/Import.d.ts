import { type ReactNode } from 'react';
export declare const Import: ({ title, pluginName, moduleName, collectionName, onFileUploaded, children, }: {
    title?: string;
    pluginName: string;
    moduleName: string;
    collectionName: string;
    onFileUploaded?: (file: File) => void;
    children?: ReactNode;
}) => import("react/jsx-runtime").JSX.Element;
