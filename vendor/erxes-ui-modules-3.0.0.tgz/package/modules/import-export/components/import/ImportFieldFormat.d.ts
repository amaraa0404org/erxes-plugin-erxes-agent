import { TImportPreviewField } from '../../types/import/importTypes';
/**
 * Describe the shape a field accepts, e.g. `date · e.g. YYYY-MM-DD`.
 *
 * A choice field lists only its first few options inline — the rest sit behind
 * a tooltip so a long option list does not push the layout around.
 */
export declare const ImportFieldFormat: ({ field, emptyLabel, }: {
    field?: TImportPreviewField;
    emptyLabel?: string;
}) => import("react/jsx-runtime").JSX.Element;
