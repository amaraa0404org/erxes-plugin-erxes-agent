/**
 * The column names and value formats this entity accepts, readable before a
 * file exists — the mapping step shows the same thing, but only once a file
 * has been uploaded, which is after the spreadsheet is already filled in.
 *
 * Sits at the bottom of the sheet and claims whatever height is left, so the
 * list scrolls on its own instead of pushing the drop zone out of view.
 */
export declare const ImportFieldReference: () => import("react/jsx-runtime").JSX.Element;
