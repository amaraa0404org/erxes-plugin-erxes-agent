import { TImportProgress } from '../../types/import/importTypes';
export declare function ImportProgress({ importProgress, }: {
    importProgress: TImportProgress;
}): import("react/jsx-runtime").JSX.Element;
