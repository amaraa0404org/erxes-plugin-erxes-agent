import { ActivityLogCustomActivity } from '../../activity-logs';
export declare const internalNoteCustomActivity: ActivityLogCustomActivity;
