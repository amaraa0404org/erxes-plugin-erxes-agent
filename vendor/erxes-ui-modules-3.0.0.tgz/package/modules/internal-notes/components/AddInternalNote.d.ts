export declare function AddInternalNote({ contentTypeId, contentType, }: {
    contentTypeId: string;
    contentType: string;
}): import("react/jsx-runtime").JSX.Element;
