export declare const InternalNoteDisplay: ({ content }: {
    content: string;
}) => import("react/jsx-runtime").JSX.Element;
