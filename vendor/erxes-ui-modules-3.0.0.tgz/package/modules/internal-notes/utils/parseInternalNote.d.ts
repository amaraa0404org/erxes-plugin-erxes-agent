import { Block } from '@blocknote/core';
export declare const parseInternalNote: (content: string) => false | Block[];
