import React from 'react';
export declare const paymentIconOptions: {
    value: string;
    label: string;
}[];
interface PaymentIconProps {
    iconType: string;
    size?: number;
    className?: string;
}
declare const PaymentIcon: React.FC<PaymentIconProps>;
export default PaymentIcon;
