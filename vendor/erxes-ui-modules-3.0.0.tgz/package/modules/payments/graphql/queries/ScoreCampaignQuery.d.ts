export declare const SCORE_CAMPAIGNS_SIMPLE_QUERY: import("@apollo/client").DocumentNode;
