export declare const SettingsHeader: ({ children, breadcrumbs, }: {
    children?: React.ReactNode;
    breadcrumbs?: React.ReactNode;
}) => import("react/jsx-runtime").JSX.Element;
