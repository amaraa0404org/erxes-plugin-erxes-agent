import React from 'react';
import { FavoriteToggleIconButton } from '../../favorites/components/FavoriteToggleIconButton';
export declare const PageHeaderRoot: React.ForwardRefExoticComponent<React.HTMLAttributes<HTMLDivElement> & {
    children: React.ReactNode;
    className?: string;
    separatorClassName?: string;
} & React.RefAttributes<HTMLDivElement>>;
export declare const PageHeaderStart: React.ForwardRefExoticComponent<React.HTMLAttributes<HTMLDivElement> & React.RefAttributes<HTMLDivElement>>;
export declare const PageHeaderEnd: React.ForwardRefExoticComponent<React.HTMLAttributes<HTMLDivElement> & {
    children: React.ReactNode;
} & React.RefAttributes<HTMLDivElement>>;
export declare const PageHeader: React.ForwardRefExoticComponent<React.HTMLAttributes<HTMLDivElement> & {
    children: React.ReactNode;
    className?: string;
    separatorClassName?: string;
} & React.RefAttributes<HTMLDivElement>> & {
    Start: React.ForwardRefExoticComponent<React.HTMLAttributes<HTMLDivElement> & React.RefAttributes<HTMLDivElement>>;
    End: React.ForwardRefExoticComponent<React.HTMLAttributes<HTMLDivElement> & {
        children: React.ReactNode;
    } & React.RefAttributes<HTMLDivElement>>;
    FavoriteToggleButton: typeof FavoriteToggleIconButton;
};
