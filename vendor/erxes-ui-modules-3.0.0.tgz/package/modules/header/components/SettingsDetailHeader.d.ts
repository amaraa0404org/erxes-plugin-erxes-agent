import type { ReactNode } from 'react';
/** The header a settings record is edited under: where it came from, what it
 *  is, and what can be done with it. */
export declare const SettingsDetailHeader: ({ title, description, backTo, actions, }: {
    title: string;
    description: string;
    backTo: string;
    actions?: ReactNode;
}) => import("react/jsx-runtime").JSX.Element;
