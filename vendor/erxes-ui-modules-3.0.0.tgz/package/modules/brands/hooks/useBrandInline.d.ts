import { QueryHookOptions } from '@apollo/client';
export interface IBrandInline {
    _id: string;
    name: string;
    code: string;
}
export interface IBrandInlineQuery {
    brandDetail: IBrandInline;
}
export declare const useBrandInline: (options?: QueryHookOptions<IBrandInlineQuery>) => {
    brand: IBrandInline | undefined;
    loading: boolean;
    error: import("@apollo/client").ApolloError | undefined;
};
