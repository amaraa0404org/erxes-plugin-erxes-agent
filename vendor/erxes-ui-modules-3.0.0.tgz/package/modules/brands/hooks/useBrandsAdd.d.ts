import { MutationHookOptions } from '@apollo/client';
export declare const useBrandsAdd: () => {
    addBrand: ({ variables, ...options }: MutationHookOptions) => void;
    loading: boolean;
};
