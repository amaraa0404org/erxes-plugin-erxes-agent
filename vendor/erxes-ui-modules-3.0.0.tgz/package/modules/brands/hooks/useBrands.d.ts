import { QueryHookOptions, OperationVariables } from '@apollo/client';
import { IBrand } from '../types/brand';
import { ICursorListResponse } from 'erxes-ui';
export declare const useBrands: (options?: QueryHookOptions<ICursorListResponse<IBrand>>) => {
    brands: IBrand[] | undefined;
    loading: boolean;
    error: import("@apollo/client").ApolloError | undefined;
    handleFetchMore: () => void;
    totalCount: number | undefined;
};
export declare const useBrandsByIds: (options: OperationVariables) => {
    brandDetail: IBrand | undefined;
    loading: boolean;
    error: import("@apollo/client").ApolloError | undefined;
};
