import React from 'react';
import { IBrand, ISelectBrandsProviderProps } from '../types/brand';
import { BrandBadge } from './BrandBadge';
export declare const SelectBrandsProvider: ({ children, value, onValueChange, mode, disableCreateOption, }: ISelectBrandsProviderProps) => import("react/jsx-runtime").JSX.Element;
export declare const SelectBrandsCommand: () => import("react/jsx-runtime").JSX.Element;
export declare const SelectBrandsCreate: ({ search, show, }: {
    search: string;
    show: boolean;
}) => import("react/jsx-runtime").JSX.Element | null;
export declare const SelectBrandsItem: ({ brand }: {
    brand: IBrand;
}) => import("react/jsx-runtime").JSX.Element;
export declare const BrandsList: ({ placeholder, renderAsPlainText, ...props }: Omit<React.ComponentProps<typeof BrandBadge>, "onClose"> & {
    placeholder?: string;
    renderAsPlainText?: boolean;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectBrandsValue: () => import("react/jsx-runtime").JSX.Element;
export declare const SelectBrandsContent: () => import("react/jsx-runtime").JSX.Element;
export declare const SelectBrandsInlineCell: ({ onValueChange, scope, ...props }: Omit<React.ComponentProps<typeof SelectBrandsProvider>, "children"> & {
    scope?: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectBrandsDetail: React.ForwardRefExoticComponent<Omit<ISelectBrandsProviderProps, "children"> & Omit<Omit<Omit<import("erxes-ui").ButtonProps & React.RefAttributes<HTMLButtonElement>, "ref"> & {
    hideChevron?: boolean;
} & React.RefAttributes<HTMLButtonElement>, "ref">, "children"> & {
    scope?: string;
} & React.RefAttributes<HTMLButtonElement>>;
export declare const SelectBrandsCommandbarItem: ({ onValueChange, ...props }: Omit<React.ComponentProps<typeof SelectBrandsProvider>, "children">) => import("react/jsx-runtime").JSX.Element;
export declare const SelectBrandsFormItem: ({ onValueChange, className, ...props }: Omit<React.ComponentProps<typeof SelectBrandsProvider>, "children"> & {
    className?: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectBrandsFilterItem: ({ value, label, }: {
    value: string;
    label: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectBrandsFilterView: ({ mode, filterKey, }: {
    mode: "single" | "multiple";
    filterKey: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectBrandsFilterBar: ({ mode, filterKey, label, }: {
    mode: "single" | "multiple";
    filterKey: string;
    label: string;
}) => import("react/jsx-runtime").JSX.Element | null;
export declare const SelectBrands: (({ children, value, onValueChange, mode, disableCreateOption, }: ISelectBrandsProviderProps) => import("react/jsx-runtime").JSX.Element) & {
    CommandBarItem: ({ onValueChange, ...props }: Omit<React.ComponentProps<typeof SelectBrandsProvider>, "children">) => import("react/jsx-runtime").JSX.Element;
    Content: () => import("react/jsx-runtime").JSX.Element;
    Command: () => import("react/jsx-runtime").JSX.Element;
    Item: ({ brand }: {
        brand: IBrand;
    }) => import("react/jsx-runtime").JSX.Element;
    Value: () => import("react/jsx-runtime").JSX.Element;
    List: ({ placeholder, renderAsPlainText, ...props }: Omit<React.ComponentProps<typeof BrandBadge>, "onClose"> & {
        placeholder?: string;
        renderAsPlainText?: boolean;
    }) => import("react/jsx-runtime").JSX.Element;
    InlineCell: ({ onValueChange, scope, ...props }: Omit<React.ComponentProps<typeof SelectBrandsProvider>, "children"> & {
        scope?: string;
    }) => import("react/jsx-runtime").JSX.Element;
    FormItem: ({ onValueChange, className, ...props }: Omit<React.ComponentProps<typeof SelectBrandsProvider>, "children"> & {
        className?: string;
    }) => import("react/jsx-runtime").JSX.Element;
    FilterItem: ({ value, label, }: {
        value: string;
        label: string;
    }) => import("react/jsx-runtime").JSX.Element;
    FilterView: ({ mode, filterKey, }: {
        mode: "single" | "multiple";
        filterKey: string;
    }) => import("react/jsx-runtime").JSX.Element;
    FilterBar: ({ mode, filterKey, label, }: {
        mode: "single" | "multiple";
        filterKey: string;
        label: string;
    }) => import("react/jsx-runtime").JSX.Element | null;
    Detail: React.ForwardRefExoticComponent<Omit<ISelectBrandsProviderProps, "children"> & Omit<Omit<Omit<import("erxes-ui").ButtonProps & React.RefAttributes<HTMLButtonElement>, "ref"> & {
        hideChevron?: boolean;
    } & React.RefAttributes<HTMLButtonElement>, "ref">, "children"> & {
        scope?: string;
    } & React.RefAttributes<HTMLButtonElement>>;
};
