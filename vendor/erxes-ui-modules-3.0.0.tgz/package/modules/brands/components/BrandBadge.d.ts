import React from 'react';
import { IBrand } from '../types/brand';
export declare const BrandBadge: React.ForwardRefExoticComponent<Omit<import("erxes-ui").BadgeProps & React.RefAttributes<HTMLDivElement>, "ref"> & {
    brand?: IBrand;
    brandId?: string;
    renderClose?: (brand: IBrand) => React.ReactNode;
    onCompleted?: (brands: IBrand) => void;
    renderAsPlainText?: boolean;
} & React.RefAttributes<HTMLDivElement>>;
