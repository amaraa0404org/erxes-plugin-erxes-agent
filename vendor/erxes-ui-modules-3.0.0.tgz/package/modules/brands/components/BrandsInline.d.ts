import { BrandsInlineProps } from '../types/brand';
export declare const BrandsInline: ((props: BrandsInlineProps) => import("react/jsx-runtime").JSX.Element) & {
    Provider: ({ children, brandIds, brands, placeholder, updateBrands, }: BrandsInlineProps & {
        children?: React.ReactNode;
    }) => import("react/jsx-runtime").JSX.Element;
    Title: () => import("react/jsx-runtime").JSX.Element;
};
