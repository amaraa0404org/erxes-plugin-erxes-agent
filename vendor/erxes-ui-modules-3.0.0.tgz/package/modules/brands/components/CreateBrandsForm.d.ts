export declare const CreateBrandForm: () => import("react/jsx-runtime").JSX.Element;
export declare function SelectBrandCreateContainer({ children, }: {
    children: React.ReactNode;
}): import("react/jsx-runtime").JSX.Element;
