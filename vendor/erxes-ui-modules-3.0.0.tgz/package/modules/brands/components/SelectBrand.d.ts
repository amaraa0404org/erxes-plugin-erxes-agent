import { IBrand } from '../types/brand';
import React from 'react';
export declare const SelectBrandProvider: ({ children, mode, value, onValueChange, brands, }: {
    children: React.ReactNode;
    mode?: "single" | "multiple";
    value?: string[] | string;
    onValueChange: (value: string[] | string) => void;
    brands?: IBrand[];
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectBrandFilterItem: () => import("react/jsx-runtime").JSX.Element;
export declare const SelectBrandFilterView: ({ onValueChange, queryKey, mode, }: {
    onValueChange?: (value: string[] | string) => void;
    queryKey?: string;
    mode?: "single" | "multiple";
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectBrandFilterBar: ({ iconOnly, onValueChange, queryKey, mode, }: {
    iconOnly?: boolean;
    onValueChange?: (value: string[] | string) => void;
    queryKey?: string;
    mode?: "single" | "multiple";
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectBrandInlineCell: ({ onValueChange, scope, ...props }: Omit<React.ComponentProps<typeof SelectBrandProvider>, "children"> & {
    scope?: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectBrandFormItem: {
    ({ onValueChange, className, placeholder, ...props }: Omit<React.ComponentProps<typeof SelectBrandProvider>, "children"> & {
        className?: string;
        placeholder?: string;
    }): import("react/jsx-runtime").JSX.Element;
    displayName: string;
};
export declare const SelectBrand: React.ForwardRefExoticComponent<Omit<Omit<{
    children: React.ReactNode;
    mode?: "single" | "multiple";
    value?: string[] | string;
    onValueChange: (value: string[] | string) => void;
    brands?: IBrand[];
}, "children"> & Omit<import("erxes-ui").ButtonProps & React.RefAttributes<HTMLButtonElement>, "ref"> & {
    hideChevron?: boolean;
} & React.RefAttributes<HTMLButtonElement> & {
    placeholder?: string;
}, "ref"> & React.RefAttributes<HTMLButtonElement>> & {
    Provider: ({ children, mode, value, onValueChange, brands, }: {
        children: React.ReactNode;
        mode?: "single" | "multiple";
        value?: string[] | string;
        onValueChange: (value: string[] | string) => void;
        brands?: IBrand[];
    }) => import("react/jsx-runtime").JSX.Element;
    Value: ({ placeholder }: {
        placeholder?: string;
    }) => import("react/jsx-runtime").JSX.Element;
    Content: () => import("react/jsx-runtime").JSX.Element;
    FilterItem: () => import("react/jsx-runtime").JSX.Element;
    FilterView: ({ onValueChange, queryKey, mode, }: {
        onValueChange?: (value: string[] | string) => void;
        queryKey?: string;
        mode?: "single" | "multiple";
    }) => import("react/jsx-runtime").JSX.Element;
    FilterBar: ({ iconOnly, onValueChange, queryKey, mode, }: {
        iconOnly?: boolean;
        onValueChange?: (value: string[] | string) => void;
        queryKey?: string;
        mode?: "single" | "multiple";
    }) => import("react/jsx-runtime").JSX.Element;
    InlineCell: ({ onValueChange, scope, ...props }: Omit<React.ComponentProps<typeof SelectBrandProvider>, "children"> & {
        scope?: string;
    }) => import("react/jsx-runtime").JSX.Element;
    FormItem: {
        ({ onValueChange, className, placeholder, ...props }: Omit<React.ComponentProps<typeof SelectBrandProvider>, "children"> & {
            className?: string;
            placeholder?: string;
        }): import("react/jsx-runtime").JSX.Element;
        displayName: string;
    };
};
