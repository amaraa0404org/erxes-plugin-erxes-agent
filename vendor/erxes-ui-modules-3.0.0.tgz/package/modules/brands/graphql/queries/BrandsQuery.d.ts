export declare const BRAND_INLINE_QUERY: import("@apollo/client").DocumentNode;
export declare const BRANDS_QUERY: import("@apollo/client").DocumentNode;
export declare const GET_BRAND_BY_ID: import("@apollo/client").DocumentNode;
