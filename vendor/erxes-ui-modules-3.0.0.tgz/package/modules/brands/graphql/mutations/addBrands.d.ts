export declare const ADD_BRANDS: import("@apollo/client").DocumentNode;
