import { ISelectBrandsContext } from '../types/brand';
export declare const SelectBrandsContext: import("react").Context<ISelectBrandsContext | null>;
