import type { Dispatch, SetStateAction } from 'react';
import { IBrand } from '../types/brand';
export type ISelectBrandContext = {
    brandIds: string[];
    brands: IBrand[];
    setBrands: Dispatch<SetStateAction<IBrand[]>>;
    onSelect: (brand: IBrand) => void;
    loading: boolean;
    error: string | null;
};
export declare const SelectBrandContext: import("react").Context<ISelectBrandContext | null>;
export declare const useSelectBrandContext: () => ISelectBrandContext;
