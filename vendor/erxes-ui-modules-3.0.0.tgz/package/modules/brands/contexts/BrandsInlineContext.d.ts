import type { Dispatch, SetStateAction } from 'react';
import { IBrand } from '../types/brand';
export interface IBrandsInlineContext {
    brands: IBrand[];
    loading: boolean;
    brandIds?: string[];
    placeholder: string;
    updateBrands?: Dispatch<SetStateAction<IBrand[]>>;
}
export declare const BrandsInlineContext: import("react").Context<IBrandsInlineContext | null>;
export declare const useBrandsInlineContext: () => IBrandsInlineContext;
