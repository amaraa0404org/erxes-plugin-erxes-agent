import { Icon, IconProps } from '@tabler/icons-react';
import { IUser } from 'ui-modules/modules/team-members';
export declare const AssigneeNotificationContent: ({ name, loading, action, fromUser, createdAt, contentType, Icon, }: {
    name: string;
    contentType: string;
    createdAt: string;
    action: string;
    fromUser: IUser;
    Icon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<Icon>>;
    loading?: boolean;
}) => import("react/jsx-runtime").JSX.Element;
