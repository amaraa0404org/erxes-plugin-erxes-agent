import { IUser } from '../../team-members';
export * from './welcome';
export declare enum TNotificationKind {
    SYSTEM = "system",
    USER = "user"
}
export type TNotificationStatus = 'read' | 'unread' | 'all';
export type TNotificationType = 'info' | 'success' | 'warning' | 'error';
export type TNotificationPriority = 'low' | 'medium' | 'high' | 'urgent';
export type TNotificationOrderBy = 'new' | 'old' | 'priority' | 'readAt';
export type TNotification = {
    _id: string;
    title: string;
    message: string;
    type: TNotificationType;
    fromUserId?: string;
    fromUser?: IUser;
    contentType?: string;
    contentTypeId?: string;
    isRead: boolean;
    readAt?: string;
    priority: TNotificationPriority;
    metadata?: unknown;
    action?: string;
    kind: TNotificationKind;
    emailDelivery?: {
        _id: string;
        status: string;
        error?: string;
        sentAt: string;
    };
    createdAt: string;
    updatedAt?: string;
};
