export declare const FIELD_GROUPS_QUERY: import("@apollo/client").DocumentNode;
export declare const FIELDS_QUERY: import("@apollo/client").DocumentNode;
export declare const FIELD_DETAILS_QUERY: import("@apollo/client").DocumentNode;
