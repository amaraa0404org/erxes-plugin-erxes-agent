import { IField } from './types/fieldsTypes';
export declare const PROPERTY_GROUP_KEY_PREFIX = "g:";
export declare const toPropertyGroupKey: (groupId: string) => string;
export declare const isPropertyGroupKey: (key: string) => boolean;
export declare const propertyGroupIdFromKey: (key: string) => string;
export declare const PROPERTY_ROW_KEY_SEP = "/";
export declare const PROPERTY_ANY_ROW_KEY_SEP = "~";
export declare const toPropertyRowKey: (groupId: string, fieldId: string, anyRow?: boolean) => string;
export type ParsedPropertyDataKey = {
    kind: 'field';
    fieldId: string;
} | {
    kind: 'row';
    groupId: string;
    fieldId: string;
    anyRow: boolean;
};
export declare const parsePropertyDataKey: (key: string) => ParsedPropertyDataKey;
declare const FORMAT_VALIDATIONS: readonly ["number", "email", "date"];
type FormatValidation = (typeof FORMAT_VALIDATIONS)[number];
export declare const activeFormatValidation: (field: IField) => FormatValidation | null;
export declare const formatValidationLabel: (field: IField) => string | null;
export declare const validatePropertyValue: (field: IField, value: unknown) => string | null;
export declare const getStringArray: (value: unknown) => string[];
export declare const hasFieldValue: (value: unknown) => boolean;
export declare const formatFieldValue: (field: IField, value: unknown) => string;
export declare const isFieldVisibleByLogic: (field: Pick<IField, "logics">, valuesByFieldId: Record<string, unknown>) => boolean;
export {};
