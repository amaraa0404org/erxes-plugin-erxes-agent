import { Icon } from '@tabler/icons-react';
export declare const FIELD_ICON_BY_TYPE: Record<string, Icon>;
