export declare const CORE_RELATION_TYPES: {
    label: string;
    value: string;
}[];
