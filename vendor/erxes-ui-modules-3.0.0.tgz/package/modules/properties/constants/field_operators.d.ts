import { OperatorOption } from '../types/fieldsTypes';
export declare const OPERATOR_BY_TYPE: Record<string, OperatorOption[]>;
