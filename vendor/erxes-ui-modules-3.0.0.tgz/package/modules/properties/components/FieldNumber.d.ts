import { SpecificFieldProps } from './Field';
export declare const FieldNumber: (props: SpecificFieldProps) => import("react/jsx-runtime").JSX.Element;
export declare const FieldNumberInCell: (props: SpecificFieldProps) => import("react/jsx-runtime").JSX.Element;
export declare const FieldNumberDetail: (props: SpecificFieldProps) => import("react/jsx-runtime").JSX.Element;
