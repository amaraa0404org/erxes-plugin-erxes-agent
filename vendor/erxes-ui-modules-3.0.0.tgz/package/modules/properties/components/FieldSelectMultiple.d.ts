import { IField } from '../types/fieldsTypes';
import { SpecificFieldProps } from './Field';
export declare const FieldSelectMultiple: (props: SpecificFieldProps) => import("react/jsx-runtime").JSX.Element;
export declare const FieldSelectMultipleContent: ({ field, value, onChange, }: {
    field: IField;
    value: string[];
    onChange: (value: string[]) => void;
}) => import("react/jsx-runtime").JSX.Element;
