import { SpecificFieldProps } from './Field';
export declare const FieldObjectList: (props: SpecificFieldProps) => import("react/jsx-runtime").JSX.Element;
