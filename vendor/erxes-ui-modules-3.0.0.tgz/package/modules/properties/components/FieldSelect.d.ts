import { IField } from '../types/fieldsTypes';
import { SpecificFieldProps } from './Field';
export declare const FieldSelect: (props: SpecificFieldProps) => import("react/jsx-runtime").JSX.Element;
export declare const FieldSelectContent: ({ field, value, onChange, }: {
    field: IField;
    value: string;
    onChange: (value: string) => void;
}) => import("react/jsx-runtime").JSX.Element;
