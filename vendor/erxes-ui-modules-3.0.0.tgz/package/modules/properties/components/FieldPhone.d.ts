import { SpecificFieldProps } from './Field';
export declare const FieldPhone: (props: SpecificFieldProps) => import("react/jsx-runtime").JSX.Element;
export declare const FieldPhoneInCell: (props: SpecificFieldProps) => import("react/jsx-runtime").JSX.Element;
export declare const FieldPhoneDetail: (props: SpecificFieldProps) => import("react/jsx-runtime").JSX.Element;
