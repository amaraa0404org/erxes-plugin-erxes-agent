import { SpecificFieldProps } from './Field';
export declare const FieldRadio: (props: SpecificFieldProps) => import("react/jsx-runtime").JSX.Element;
