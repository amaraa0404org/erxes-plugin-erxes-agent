import { SpecificFieldProps } from './Field';
export declare const FieldBoolean: (props: SpecificFieldProps) => import("react/jsx-runtime").JSX.Element;
