import { SpecificFieldProps } from './Field';
export declare const FieldRelation: ({ field, value, handleChange, inCell, id, }: SpecificFieldProps) => import("react/jsx-runtime").JSX.Element | null;
