import { SpecificFieldProps } from './Field';
export declare const FieldFile: ({ value, inCell, handleChange, }: SpecificFieldProps) => import("react/jsx-runtime").JSX.Element;
