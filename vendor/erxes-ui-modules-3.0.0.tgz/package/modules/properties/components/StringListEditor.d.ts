export declare const StringListEditor: ({ value, onChange, emptyMessage, addButtonLabel, }: {
    value: string[];
    onChange: (value: string[]) => void;
    emptyMessage?: string;
    addButtonLabel?: string;
}) => import("react/jsx-runtime").JSX.Element;
