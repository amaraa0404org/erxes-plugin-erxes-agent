import { SpecificFieldProps } from './Field';
export declare const FieldCheck: (props: SpecificFieldProps) => import("react/jsx-runtime").JSX.Element;
