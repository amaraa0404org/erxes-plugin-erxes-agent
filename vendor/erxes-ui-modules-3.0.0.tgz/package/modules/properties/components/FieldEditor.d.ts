import { SpecificFieldProps } from './Field';
export declare const FieldEditor: (props: SpecificFieldProps) => import("react/jsx-runtime").JSX.Element;
