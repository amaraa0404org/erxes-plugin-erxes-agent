import { SpecificFieldProps } from './Field';
export declare const FieldTextarea: (props: SpecificFieldProps) => import("react/jsx-runtime").JSX.Element;
export declare const FieldTextareaInCell: (props: SpecificFieldProps) => import("react/jsx-runtime").JSX.Element;
export declare const FieldTextareaDetail: (props: SpecificFieldProps) => import("react/jsx-runtime").JSX.Element;
