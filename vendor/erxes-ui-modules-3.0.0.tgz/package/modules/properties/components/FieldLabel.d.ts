import { IField } from '../types/fieldsTypes';
export declare const FieldLabel: ({ field, children, id, inCell, value, error, }: {
    field: IField;
    children: React.ReactNode;
    id: string;
    inCell?: boolean;
    value?: unknown;
    error?: string | null;
}) => string | number | boolean | Iterable<import("react").ReactNode> | import("react/jsx-runtime").JSX.Element | null | undefined;
