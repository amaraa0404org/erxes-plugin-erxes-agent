import { IField, IFieldGroup, mutateFunction } from '../types/fieldsTypes';
export declare const PropertyGroupShell: ({ group, action, children, }: {
    group: IFieldGroup;
    action?: React.ReactNode;
    children: React.ReactNode;
}) => import("react/jsx-runtime").JSX.Element;
export declare const PropertyGroupCard: ({ children, }: {
    children: React.ReactNode;
}) => import("react/jsx-runtime").JSX.Element;
export declare const FieldsInDetail: ({ fieldContentType, propertiesData, mutateHook, id, className, }: {
    fieldContentType: string;
    propertiesData: Record<string, any>;
    mutateHook: () => {
        mutate: mutateFunction;
        loading: boolean;
    };
    id: string;
    className?: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const FieldsInGroup: ({ propertiesData, mutateHook, id, fields, }: {
    group: IFieldGroup;
    id: string;
    inCell?: boolean;
    contentType: string;
    propertiesData: Record<string, any>;
    mutateHook: () => {
        mutate: mutateFunction;
        loading: boolean;
    };
    fields: IField[];
}) => import("react/jsx-runtime").JSX.Element;
export declare const MultipleFieldsInGroup: ({ group, propertiesData, mutateHook, id, fields, }: {
    group: IFieldGroup;
    id: string;
    inCell?: boolean;
    contentType: string;
    propertiesData: Record<string, any>;
    mutateHook: () => {
        mutate: mutateFunction;
        loading: boolean;
    };
    fields: IField[];
}) => import("react/jsx-runtime").JSX.Element;
