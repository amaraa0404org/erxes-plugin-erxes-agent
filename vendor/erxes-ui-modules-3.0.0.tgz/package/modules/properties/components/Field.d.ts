import { ComponentType } from 'react';
import { IField, IFieldGroup, mutateFunction } from '../types/fieldsTypes';
export interface FieldProps {
    field: IField;
    inCell?: boolean;
    value: any;
    mutateHook?: () => {
        mutate: mutateFunction;
        loading: boolean;
    };
    propertiesData?: Record<string, unknown>;
    id: string;
    onFieldChange?: (value: unknown) => void;
}
export interface SpecificFieldProps extends FieldProps {
    handleChange: (value: unknown) => void;
    onInputChange?: (value: unknown) => void;
    loading: boolean;
}
export declare const FIELD_COMPONENT_BY_TYPE: Record<string, ComponentType<SpecificFieldProps>>;
export declare const Field: (props: FieldProps) => import("react/jsx-runtime").JSX.Element;
export interface FieldMultipleProps {
    group: IFieldGroup;
    field: IField;
    inCell?: boolean;
    rowId: string;
    value: any;
    mutateHook?: () => {
        mutate: mutateFunction;
        loading: boolean;
    };
    propertiesData?: Record<string, any>;
    id: string;
}
export declare const FieldMultiple: (props: FieldMultipleProps) => import("react/jsx-runtime").JSX.Element;
