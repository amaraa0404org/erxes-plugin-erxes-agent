import { SpecificFieldProps } from './Field';
export declare const FieldDate: (props: SpecificFieldProps) => import("react/jsx-runtime").JSX.Element;
