import { SpecificFieldProps } from './Field';
export declare const FieldString: (props: SpecificFieldProps) => import("react/jsx-runtime").JSX.Element;
export declare const FieldStringInCell: (props: SpecificFieldProps) => import("react/jsx-runtime").JSX.Element;
export declare const FieldStringDetail: (props: SpecificFieldProps) => import("react/jsx-runtime").JSX.Element;
