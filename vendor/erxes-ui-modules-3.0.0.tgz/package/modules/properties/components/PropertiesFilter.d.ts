import { IPropertyFilterCondition } from '../types/fieldsTypes';
export declare const encodePropertiesData: (conditions: IPropertyFilterCondition[]) => string;
export declare const decodePropertiesData: (param?: string | null) => IPropertyFilterCondition[];
export declare const PropertiesFilter: (() => import("react/jsx-runtime").JSX.Element) & {
    View: ({ contentType }: {
        contentType: string;
    }) => import("react/jsx-runtime").JSX.Element;
    Bar: ({ contentType }: {
        contentType: string;
    }) => import("react/jsx-runtime").JSX.Element | null;
};
