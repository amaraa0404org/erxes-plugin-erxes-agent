import { SpecificFieldProps } from './Field';
export declare const FieldStringMultiple: (props: SpecificFieldProps) => import("react/jsx-runtime").JSX.Element;
export declare const FieldStringMultipleInCell: (props: SpecificFieldProps) => import("react/jsx-runtime").JSX.Element;
export declare const FieldStringMultipleDetail: (props: SpecificFieldProps) => import("react/jsx-runtime").JSX.Element;
