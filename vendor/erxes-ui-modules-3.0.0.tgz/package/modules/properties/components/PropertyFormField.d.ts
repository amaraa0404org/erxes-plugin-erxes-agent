import { IField } from '../types/fieldsTypes';
export declare function PropertyFormField({ field, value, idPrefix, onFieldChange, }: Readonly<{
    field: IField;
    value: unknown;
    idPrefix: string;
    onFieldChange: (fieldId: string, value: unknown) => void;
}>): import("react/jsx-runtime").JSX.Element | null;
