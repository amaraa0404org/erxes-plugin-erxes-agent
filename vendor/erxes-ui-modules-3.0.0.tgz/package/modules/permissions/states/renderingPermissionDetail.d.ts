export declare const renderingPermissionDetailAtom: import("jotai").PrimitiveAtom<boolean> & {
    init: boolean;
};
