import { Tooltip } from 'erxes-ui';
import type { ComponentProps, ReactNode } from 'react';
export type BeforeResolverBlockedResult = {
    message?: string;
    code?: string;
    pluginName?: string;
    details?: Record<string, unknown>;
};
export type BeforeResolverAvailabilityRenderProps = {
    disabled: boolean;
    checking: boolean;
    blocked: boolean;
    blockedReason?: ReactNode;
    blockedResults: BeforeResolverBlockedResult[];
};
export type BeforeResolverAvailabilityProps = {
    resolver: string;
    args?: Record<string, unknown>;
    skip?: boolean;
    blockedFallback?: ReactNode;
    loadingFallback?: ReactNode;
    tooltip?: boolean;
    tooltipSide?: ComponentProps<typeof Tooltip.Content>['side'];
    tooltipTriggerClassName?: string;
    children: ReactNode;
};
export declare const BeforeResolverAvailability: ({ resolver, args, skip, blockedFallback, loadingFallback, tooltip, tooltipSide, tooltipTriggerClassName, children, }: BeforeResolverAvailabilityProps) => string | number | boolean | Iterable<ReactNode> | import("react/jsx-runtime").JSX.Element | null | undefined;
