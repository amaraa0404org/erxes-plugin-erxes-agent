import React from 'react';
export declare const PermissionsSidebarItem: ({ to, children, asChild, }: {
    to: string;
    children?: React.ReactNode;
    asChild?: boolean;
}) => import("react/jsx-runtime").JSX.Element;
export declare const PermissionsSidebarSubItem: ({ path, label, }: {
    path: string;
    label: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const PermissionsSidebarGroup: ({ children, }: {
    children: React.ReactNode;
}) => import("react/jsx-runtime").JSX.Element;
export declare const PermissionsRecordTable: ({ module }: {
    module?: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const PermissionsView: ({ module, shouldHide, }: {
    module?: string;
    shouldHide?: boolean;
}) => import("react/jsx-runtime").JSX.Element;
export declare const PermissionsFilter: ({ module, shouldHide, }: {
    module?: string;
    shouldHide?: boolean;
}) => import("react/jsx-runtime").JSX.Element;
export declare const PermissionsTotalCount: ({ module, }: {
    module?: string | null;
}) => import("react/jsx-runtime").JSX.Element;
export declare const PermissionsCreate: ({ module }: {
    module?: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const PermissionForm: () => import("react/jsx-runtime").JSX.Element;
export declare const PermissionsFix: () => import("react/jsx-runtime").JSX.Element;
export declare const PermissionsTopbar: () => import("react/jsx-runtime").JSX.Element;
export declare const Permissions: any;
