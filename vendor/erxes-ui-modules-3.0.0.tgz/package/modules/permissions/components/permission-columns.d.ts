import { Cell, ColumnDef } from '@tanstack/react-table';
import { IPermission } from 'ui-modules/modules/permissions/types/permission';
export declare const PermissionsColumnsMoreCell: ({ cell, }: {
    cell: Cell<IPermission, unknown>;
}) => import("react/jsx-runtime").JSX.Element;
export declare const permissionColumns: ColumnDef<IPermission>[];
