import React from 'react';
import { IPermissionModule } from 'ui-modules/modules/permissions/types/permission';
export interface ISelectModulesContext {
    onSelect: (module: IPermissionModule) => void;
    selectedModule?: IPermissionModule;
    setSelectedModule?: (module: IPermissionModule) => void;
    selectedModuleName?: string;
    setSelectedModuleName?: (name: string) => void;
}
export declare const SelectModulesContext: React.Context<ISelectModulesContext | null>;
export declare const useSelectModulesContext: () => ISelectModulesContext;
export declare const SelectModulesProvider: ({ children, value, onValueChange, }: {
    children: React.ReactNode;
    value?: string;
    onValueChange?: (value: string) => void;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectModuleFormItem: ({ className, ...props }: Omit<React.ComponentProps<typeof SelectModulesProvider>, "children"> & {
    className?: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectModule: {
    Provider: ({ children, value, onValueChange, }: {
        children: React.ReactNode;
        value?: string;
        onValueChange?: (value: string) => void;
    }) => import("react/jsx-runtime").JSX.Element;
    Value: () => import("react/jsx-runtime").JSX.Element;
    Command: () => import("react/jsx-runtime").JSX.Element;
    FormItem: ({ className, ...props }: Omit<React.ComponentProps<typeof SelectModulesProvider>, "children"> & {
        className?: string;
    }) => import("react/jsx-runtime").JSX.Element;
    FilterItem: () => import("react/jsx-runtime").JSX.Element;
    FilterView: () => import("react/jsx-runtime").JSX.Element;
    BarItem: () => import("react/jsx-runtime").JSX.Element;
};
