import { IPermissionAction } from 'ui-modules/modules/permissions/types/permission';
export interface IActionsInlineContext {
    actions: IPermissionAction[];
    loading: boolean;
    actionsNames?: string[];
    placeholder?: string;
    updateActions?: (actions: IPermissionAction[]) => void;
    module?: string;
}
export declare const ActionsInlineContext: import("react").Context<IActionsInlineContext | null>;
export declare const useActionsInlineContext: () => IActionsInlineContext;
export declare const ActionsInline: ({ actions, actionsNames, placeholder, updateActions, module, }: {
    actions: IPermissionAction[];
    actionsNames?: string[];
    placeholder?: string;
    updateActions?: (actions: IPermissionAction[]) => void;
    module?: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const ActionsInlineProvider: ({ children, actions, actionsNames, placeholder, updateActions, module, }: {
    children?: React.ReactNode;
    actions?: IPermissionAction[];
    actionsNames?: string[];
    placeholder?: string;
    updateActions?: (actions: IPermissionAction[]) => void;
    module?: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const ActionInlineEffectComponent: ({ actionName, }: {
    actionName: string;
}) => null;
export declare const ActionsInlineTitle: () => import("react/jsx-runtime").JSX.Element;
