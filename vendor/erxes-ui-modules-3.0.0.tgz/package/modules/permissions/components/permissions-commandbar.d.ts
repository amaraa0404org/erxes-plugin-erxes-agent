export declare const PermissionsCommandBar: () => import("react/jsx-runtime").JSX.Element;
