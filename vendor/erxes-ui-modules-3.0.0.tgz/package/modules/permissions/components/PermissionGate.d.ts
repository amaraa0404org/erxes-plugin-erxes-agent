interface PermissionGateProps {
    action?: string;
    actions?: string[];
    module?: string;
    plugin?: string;
    fallback?: React.ReactNode;
    children: React.ReactNode;
}
export declare const Can: ({ action, actions, module, plugin, fallback, children, }: PermissionGateProps) => import("react").ReactNode;
export {};
