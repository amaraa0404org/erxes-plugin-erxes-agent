import React from 'react';
import { IPermissionAction } from 'ui-modules/modules/permissions/types/permission';
export interface ISelectActionsContext {
    onSelect: (action: IPermissionAction) => void;
    actions?: IPermissionAction[];
    actionsNames?: string[];
    setActions?: (actions: IPermissionAction[]) => void;
    loading: boolean;
    error: string | null;
}
export declare const SelectActionsContext: React.Context<ISelectActionsContext | null>;
export declare const useSelectActionsContext: () => ISelectActionsContext;
export declare const SelectActionsProvider: ({ children, mode, value, onValueChange, }: {
    children: React.ReactNode;
    mode?: "single" | "multiple";
    value?: string[] | string;
    onValueChange?: (value: string[] | string) => void;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectActionsContent: ({ selectedModule, }: {
    selectedModule?: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectActionsFormItem: ({ className, selectedModule, ...props }: Omit<React.ComponentProps<typeof SelectActionsProvider>, "children"> & {
    className?: string;
    selectedModule?: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectActions: {
    Provider: ({ children, mode, value, onValueChange, }: {
        children: React.ReactNode;
        mode?: "single" | "multiple";
        value?: string[] | string;
        onValueChange?: (value: string[] | string) => void;
    }) => import("react/jsx-runtime").JSX.Element;
    Value: ({ module }: {
        module?: string;
    }) => import("react/jsx-runtime").JSX.Element;
    Content: ({ selectedModule, }: {
        selectedModule?: string;
    }) => import("react/jsx-runtime").JSX.Element;
    FormItem: ({ className, selectedModule, ...props }: Omit<React.ComponentProps<typeof SelectActionsProvider>, "children"> & {
        className?: string;
        selectedModule?: string;
    }) => import("react/jsx-runtime").JSX.Element;
    BarItem: () => import("react/jsx-runtime").JSX.Element | null;
};
