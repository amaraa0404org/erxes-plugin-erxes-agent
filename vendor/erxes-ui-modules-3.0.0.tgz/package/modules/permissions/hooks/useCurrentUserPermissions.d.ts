export interface ICurrentUserPermission {
    plugin: string;
    module: string;
    actions: string[];
    scope: string;
}
export interface ICurrentUserPermissionsResult {
    permissions: ICurrentUserPermission[];
    pluginsWithPermissions: string[];
}
export declare const useCurrentUserPermissions: () => {
    currentUserPermissions: ICurrentUserPermission[];
    pluginsWithPermissions: string[];
    error: import("@apollo/client").ApolloError | undefined;
    loading: boolean;
};
