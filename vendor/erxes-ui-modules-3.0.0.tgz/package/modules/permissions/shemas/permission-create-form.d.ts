import { z } from 'zod';
export declare const PERMISSION_FORM_SCHEMA: z.ZodObject<{
    module: z.ZodString;
    actions: z.ZodArray<z.ZodString, "many">;
    userIds: z.ZodOptional<z.ZodArray<z.ZodString, "many">>;
    groupIds: z.ZodOptional<z.ZodArray<z.ZodString, "many">>;
    allowed: z.ZodDefault<z.ZodBoolean>;
}, "strip", z.ZodTypeAny, {
    module: string;
    actions: string[];
    allowed: boolean;
    userIds?: string[] | undefined;
    groupIds?: string[] | undefined;
}, {
    module: string;
    actions: string[];
    userIds?: string[] | undefined;
    groupIds?: string[] | undefined;
    allowed?: boolean | undefined;
}>;
