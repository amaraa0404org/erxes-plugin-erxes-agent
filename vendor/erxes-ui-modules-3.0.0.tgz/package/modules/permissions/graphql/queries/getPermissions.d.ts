export declare const GET_PERMISSIONS: import("@apollo/client").DocumentNode;
export declare const GET_PERMISSION_MODULES: import("@apollo/client").DocumentNode;
export declare const GET_PERMISSION_ACTIONS: import("@apollo/client").DocumentNode;
export declare const CURRENT_USER_PERMISSIONS: import("@apollo/client").DocumentNode;
