export declare const REMOVE_PERMISSIONS: import("@apollo/client").DocumentNode;
