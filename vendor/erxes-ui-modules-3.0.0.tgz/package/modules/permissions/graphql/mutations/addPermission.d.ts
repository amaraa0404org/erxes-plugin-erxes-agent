export declare const ADD_PERMISSIONS: import("@apollo/client").DocumentNode;
