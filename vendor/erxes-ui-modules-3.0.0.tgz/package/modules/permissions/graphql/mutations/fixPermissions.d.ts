export declare const FIX_PERMISSIONS: import("@apollo/client").DocumentNode;
