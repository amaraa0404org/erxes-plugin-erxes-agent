import { TSegmentGroupNode } from '../types/segmentNode';
import { TNodePath } from '../types';
/** Where a node sits: which group holds it, and at which position. */
export type TNodeSlot = {
    parent: TNodePath;
    index: number;
};
export declare const slotOf: (path: TNodePath) => TNodeSlot | null;
/**
 * The tree with one node moved. `null` when the move is not one to make -
 * a node onto itself, or a group into its own descendant, where the subtree
 * being moved is also the one being moved into.
 */
export declare const moveSegmentNode: (root: TSegmentGroupNode, from: TNodePath, to: TNodeSlot) => TSegmentGroupNode | null;
