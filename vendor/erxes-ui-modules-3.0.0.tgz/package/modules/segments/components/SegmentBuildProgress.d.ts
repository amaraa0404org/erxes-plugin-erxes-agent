import { ISegment } from '../types';
export declare const SegmentBuildProgress: ({ segment }: {
    segment?: ISegment;
}) => import("react/jsx-runtime").JSX.Element | null;
