import { ISegment } from '../types';
export declare const SegmentOverview: ({ segment, days, onRefresh, }: {
    segment?: ISegment;
    days?: number;
    onRefresh?: () => Promise<unknown> | void;
}) => import("react/jsx-runtime").JSX.Element;
