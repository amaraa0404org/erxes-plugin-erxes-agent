export declare const SegmentMetadataForm: () => import("react/jsx-runtime").JSX.Element;
