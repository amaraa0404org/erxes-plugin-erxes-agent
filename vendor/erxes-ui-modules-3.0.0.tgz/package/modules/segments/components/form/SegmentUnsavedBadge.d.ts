export declare const SegmentUnsavedBadge: () => import("react/jsx-runtime").JSX.Element | null;
