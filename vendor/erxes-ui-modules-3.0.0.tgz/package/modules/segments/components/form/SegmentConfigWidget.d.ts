export declare const SegmentConfigWidget: ({ contentType, }: {
    contentType: string;
}) => import("react/jsx-runtime").JSX.Element | null;
