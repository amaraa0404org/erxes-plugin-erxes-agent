import { TNodePath } from '../../types';
export declare const SegmentRelationFilters: ({ path, relatedType, label, }: {
    path: TNodePath;
    relatedType: string;
    label: string;
}) => import("react/jsx-runtime").JSX.Element;
