import { TNodePath } from '../../types';
type SegmentGroupBodyProps = {
    path: TNodePath;
    onRemove?: () => void;
    depth?: number;
};
type SegmentGroupProps = SegmentGroupBodyProps & {
    contentType?: string;
    nested?: boolean;
    sortable?: boolean;
    onEnterGroup?: (path: TNodePath) => void;
};
export declare const SegmentGroup: ({ contentType, nested, onEnterGroup, ...body }: SegmentGroupProps) => import("react/jsx-runtime").JSX.Element;
export {};
