export declare const SegmentTreeDnd: ({ children }: {
    children: React.ReactNode;
}) => import("react/jsx-runtime").JSX.Element;
