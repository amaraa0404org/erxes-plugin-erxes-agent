import { TNodePath } from '../../types';
export declare const SegmentSortableNode: ({ path, children, }: {
    path: TNodePath;
    children: React.ReactNode;
}) => import("react/jsx-runtime").JSX.Element;
