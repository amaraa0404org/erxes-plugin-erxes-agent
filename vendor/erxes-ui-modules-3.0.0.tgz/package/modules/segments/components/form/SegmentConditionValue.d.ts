import { TNodePath, TSegmentField, TSegmentOperator } from '../../types';
export declare const SegmentConditionValue: ({ path, field: declared, fieldType, operator, }: {
    path: TNodePath;
    field?: TSegmentField;
    fieldType?: string;
    operator?: TSegmentOperator;
}) => import("react/jsx-runtime").JSX.Element | null;
