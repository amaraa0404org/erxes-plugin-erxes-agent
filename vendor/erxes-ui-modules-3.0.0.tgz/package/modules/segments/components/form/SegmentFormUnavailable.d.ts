export declare const SegmentFormUnavailable: () => import("react/jsx-runtime").JSX.Element;
