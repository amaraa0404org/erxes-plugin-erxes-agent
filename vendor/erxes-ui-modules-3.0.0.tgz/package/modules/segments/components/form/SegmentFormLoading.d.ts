export declare function SegmentFormLoading(): import("react/jsx-runtime").JSX.Element;
