import { TNodePath } from '../../types';
export declare const SegmentGroupSummary: ({ path, onEnter, onRemove, }: {
    path: TNodePath;
    onEnter: () => void;
    onRemove: () => void;
}) => import("react/jsx-runtime").JSX.Element;
