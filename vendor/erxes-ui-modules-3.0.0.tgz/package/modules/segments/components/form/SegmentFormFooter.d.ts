export declare const SegmentFormFooter: ({ callback, onCreateSuccess, onOpenExisting, }: {
    callback?: (id: string) => void;
    onCreateSuccess?: (id: string) => void;
    onOpenExisting?: (segmentId: string) => void;
}) => import("react/jsx-runtime").JSX.Element;
