export declare const SegmentConjunctionRail: ({ conjunction, onToggle, }: {
    conjunction: "and" | "or";
    onToggle: () => void;
}) => import("react/jsx-runtime").JSX.Element;
