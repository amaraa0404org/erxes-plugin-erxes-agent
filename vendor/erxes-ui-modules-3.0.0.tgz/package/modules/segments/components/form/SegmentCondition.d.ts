import { TNodePath, TSegmentNode } from '../../types';
export declare const SegmentCondition: ({ path, onRemove, onReplace, }: {
    path: TNodePath;
    onRemove: () => void;
    onReplace: (next: TSegmentNode) => void;
}) => import("react/jsx-runtime").JSX.Element;
