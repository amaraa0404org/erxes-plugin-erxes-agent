import { TNodePath } from '../../types';
export declare const SegmentReferenceValue: ({ path }: {
    path: TNodePath;
}) => import("react/jsx-runtime").JSX.Element;
