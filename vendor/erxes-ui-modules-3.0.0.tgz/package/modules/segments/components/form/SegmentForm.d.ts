type RootProps = {
    contentType: string;
    segmentId?: string;
    ownedBy?: string;
    children: React.ReactNode;
};
type SegmentFormProps = {
    contentType: string;
    segmentId?: string;
    callback?: (id: string) => void;
    onCreateSuccess?: (id: string) => void;
    onOpenExisting?: (segmentId: string) => void;
};
export declare const SegmentForm: (({ contentType, segmentId, callback, onCreateSuccess, onOpenExisting, }: SegmentFormProps) => import("react/jsx-runtime").JSX.Element) & {
    Root: ({ contentType, segmentId, ownedBy, children, }: RootProps) => import("react/jsx-runtime").JSX.Element;
    Wrapper: ({ children }: {
        children: React.ReactNode;
    }) => import("react/jsx-runtime").JSX.Element;
    Header: {
        (): import("react/jsx-runtime").JSX.Element;
        displayName: string;
    };
    Content: ({ children }: {
        children?: React.ReactNode;
    }) => import("react/jsx-runtime").JSX.Element;
    Group: ({ contentType, nested, onEnterGroup, ...body }: {
        path: import("../..").TNodePath;
        onRemove?: () => void;
        depth?: number;
    } & {
        contentType?: string;
        nested?: boolean;
        sortable?: boolean;
        onEnterGroup?: (path: import("../..").TNodePath) => void;
    }) => import("react/jsx-runtime").JSX.Element;
    Footer: ({ callback, onCreateSuccess, onOpenExisting, }: {
        callback?: (id: string) => void;
        onCreateSuccess?: (id: string) => void;
        onOpenExisting?: (segmentId: string) => void;
    }) => import("react/jsx-runtime").JSX.Element;
};
export {};
