export declare const SegmentConditionHeader: () => import("react/jsx-runtime").JSX.Element;
