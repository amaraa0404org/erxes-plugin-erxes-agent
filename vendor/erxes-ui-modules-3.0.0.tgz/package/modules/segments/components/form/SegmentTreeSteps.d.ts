import { TNodePath } from '../../types';
export declare const SegmentTreeSteps: ({ root }: {
    root?: TNodePath;
}) => import("react/jsx-runtime").JSX.Element;
