import { FieldError } from 'react-hook-form';
type Props = {
    error?: FieldError;
    children: React.ReactNode;
};
export declare const FieldWithError: ({ error, children }: Props) => string | number | boolean | Iterable<import("react").ReactNode> | import("react/jsx-runtime").JSX.Element | null | undefined;
export {};
