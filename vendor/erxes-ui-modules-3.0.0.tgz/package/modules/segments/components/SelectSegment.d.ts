export declare const SelectSegment: ({ selected, onSelect, mode, focusOnMount, nullable, exclude, disabled, contentType, unnamedLabel, }: {
    selected?: string | string[];
    onSelect: (categoryId: string | string[] | null) => void;
    mode?: "single" | "multiple";
    focusOnMount?: boolean;
    nullable?: boolean;
    exclude?: string[];
    disabled?: boolean;
    contentType?: string;
    unnamedLabel?: string;
}) => import("react/jsx-runtime").JSX.Element;
