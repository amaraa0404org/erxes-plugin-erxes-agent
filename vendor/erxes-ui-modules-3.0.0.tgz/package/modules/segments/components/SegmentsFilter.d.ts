export declare const SegmentsFilterView: ({ contentType, }: {
    contentType: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SegmentsFilter: (() => import("react/jsx-runtime").JSX.Element) & {
    Bar: ({ contentType }: {
        contentType: string;
    }) => import("react/jsx-runtime").JSX.Element | null;
    View: ({ contentType, }: {
        contentType: string;
    }) => import("react/jsx-runtime").JSX.Element;
};
