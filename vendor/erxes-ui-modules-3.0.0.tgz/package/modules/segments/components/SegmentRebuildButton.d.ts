import { ISegment } from '../types';
export declare const SegmentRebuildButton: ({ segment, size, }: {
    segment?: ISegment;
    size?: "sm";
}) => import("react/jsx-runtime").JSX.Element | null;
