import { DocumentNode } from '@apollo/client';
type TQuerySelectValue = string | string[];
type Props = {
    query: DocumentNode;
    queryName: string;
    labelField: string;
    valueField: string;
    focusOnMount?: boolean;
    nullable: boolean;
    onSelect: (optionId: TQuerySelectValue) => void;
    value?: TQuerySelectValue;
    multi?: boolean;
};
export declare const QuerySelectInput: ({ query, queryName, labelField, valueField, focusOnMount, onSelect, value, multi, }: Props) => import("react/jsx-runtime").JSX.Element;
export {};
