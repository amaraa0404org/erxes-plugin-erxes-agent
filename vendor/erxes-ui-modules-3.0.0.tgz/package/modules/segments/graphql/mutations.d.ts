export declare const SEGMENT_REBUILD: import("graphql").DocumentNode;
export declare const SEGMENT_STOP_REBUILD: import("graphql").DocumentNode;
export declare const SEGMENT_ADD: import("graphql").DocumentNode;
export declare const SEGMENT_EDIT: import("graphql").DocumentNode;
export declare const SEGMENT_REMOVE: import("graphql").DocumentNode;
