export declare const SEGMENT_BUILD_CHANGED: import("graphql").DocumentNode;
