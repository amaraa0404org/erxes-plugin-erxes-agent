import { UseFormReturn } from 'react-hook-form';
import { useSegmentStats } from '../hooks/useSegmentStats';
import { ISegment, TSegmentForm } from '../types';
type SegmentFormContextType = {
    contentType: string;
    ownedBy?: string;
    form: UseFormReturn<TSegmentForm>;
    segment?: ISegment;
    stats: ReturnType<typeof useSegmentStats>;
};
export declare const SegmentProvider: ({ children, contentType, segment, ownedBy, }: {
    children: React.ReactNode;
    contentType: string;
    segment?: ISegment;
    ownedBy?: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const useSegment: () => SegmentFormContextType;
export {};
