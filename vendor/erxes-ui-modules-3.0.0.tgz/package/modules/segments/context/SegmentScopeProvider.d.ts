import { TNodePath } from '../types';
export type TSegmentScope = {
    contentType: string;
    nested: boolean;
    sortable: boolean;
    onEnterGroup?: (path: TNodePath) => void;
};
export declare const SegmentScopeProvider: ({ children, contentType, nested, sortable, onEnterGroup, }: {
    children: React.ReactNode;
    contentType?: string;
    nested?: boolean;
    sortable?: boolean;
    onEnterGroup?: (path: TNodePath) => void;
}) => import("react/jsx-runtime").JSX.Element;
export declare const useSegmentScope: () => TSegmentScope;
