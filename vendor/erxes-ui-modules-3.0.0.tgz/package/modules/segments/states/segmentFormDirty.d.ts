export declare const segmentFormDirtyAtom: import("jotai").PrimitiveAtom<boolean> & {
    init: boolean;
};
