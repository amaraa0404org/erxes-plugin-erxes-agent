import { z } from 'zod';
export declare const segmentNodeSchema: z.ZodType<{
    kind: 'group' | 'field' | 'relation' | 'segment';
}>;
export declare const segmentFormSchema: z.ZodObject<{
    name: z.ZodOptional<z.ZodString>;
    description: z.ZodOptional<z.ZodString>;
    color: z.ZodOptional<z.ZodString>;
    visibility: z.ZodEnum<["private", "organization"]>;
    root: z.ZodType<{
        kind: "group" | "field" | "relation" | "segment";
    }, z.ZodTypeDef, {
        kind: "group" | "field" | "relation" | "segment";
    }>;
}, "strip", z.ZodTypeAny, {
    visibility: "organization" | "private";
    root: {
        kind: "group" | "field" | "relation" | "segment";
    };
    color?: string | undefined;
    name?: string | undefined;
    description?: string | undefined;
}, {
    visibility: "organization" | "private";
    root: {
        kind: "group" | "field" | "relation" | "segment";
    };
    color?: string | undefined;
    name?: string | undefined;
    description?: string | undefined;
}>;
export declare const segmentFormSchemaFor: (ownedBy?: string) => z.ZodObject<{
    name: z.ZodOptional<z.ZodString>;
    description: z.ZodOptional<z.ZodString>;
    color: z.ZodOptional<z.ZodString>;
    visibility: z.ZodEnum<["private", "organization"]>;
    root: z.ZodType<{
        kind: "group" | "field" | "relation" | "segment";
    }, z.ZodTypeDef, {
        kind: "group" | "field" | "relation" | "segment";
    }>;
}, "strip", z.ZodTypeAny, {
    visibility: "organization" | "private";
    root: {
        kind: "group" | "field" | "relation" | "segment";
    };
    color?: string | undefined;
    name?: string | undefined;
    description?: string | undefined;
}, {
    visibility: "organization" | "private";
    root: {
        kind: "group" | "field" | "relation" | "segment";
    };
    color?: string | undefined;
    name?: string | undefined;
    description?: string | undefined;
}> | z.ZodObject<z.objectUtil.extendShape<{
    name: z.ZodOptional<z.ZodString>;
    description: z.ZodOptional<z.ZodString>;
    color: z.ZodOptional<z.ZodString>;
    visibility: z.ZodEnum<["private", "organization"]>;
    root: z.ZodType<{
        kind: "group" | "field" | "relation" | "segment";
    }, z.ZodTypeDef, {
        kind: "group" | "field" | "relation" | "segment";
    }>;
}, {
    name: z.ZodString;
}>, "strip", z.ZodTypeAny, {
    name: string;
    visibility: "organization" | "private";
    root: {
        kind: "group" | "field" | "relation" | "segment";
    };
    color?: string | undefined;
    description?: string | undefined;
}, {
    name: string;
    visibility: "organization" | "private";
    root: {
        kind: "group" | "field" | "relation" | "segment";
    };
    color?: string | undefined;
    description?: string | undefined;
}>;
