import { TActivityLog } from '../types';
export declare const useActivityLogRow: (activity: TActivityLog) => string | number | boolean | Iterable<import("react").ReactNode> | import("react/jsx-runtime").JSX.Element | null | undefined;
