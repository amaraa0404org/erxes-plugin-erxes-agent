import { QueryHookOptions } from '@apollo/client';
import { TActivityLog } from '../types';
import { EnumCursorDirection } from 'erxes-ui';
interface UseActivityLogsParams {
    targetId: string;
    action?: string;
    limit?: number;
    variant?: 'forward' | 'backward';
    targetType?: string;
    contextType?: string;
    contextId?: string;
    activityType?: string;
    excludeActivityType?: string;
    dateFrom?: Date | string;
    dateTo?: Date | string;
}
export type ActivityLogsQueryData = {
    activityLogs: {
        list: TActivityLog[];
        totalCount: number;
        pageInfo: {
            hasNextPage: boolean;
            hasPreviousPage: boolean;
            startCursor: string;
            endCursor: string;
        };
    };
};
export declare const useActivityLogs: ({ targetId, action, limit, targetType, variant, activityType, excludeActivityType, dateFrom, dateTo, }: UseActivityLogsParams, options?: QueryHookOptions<ActivityLogsQueryData>) => {
    activityLogs: TActivityLog<any, any>[];
    totalCount: number;
    pageInfo: {
        hasNextPage: boolean;
        hasPreviousPage: boolean;
        startCursor: string;
        endCursor: string;
    };
    loading: boolean;
    error: import("@apollo/client").ApolloError | undefined;
    refetch: (variables?: Partial<import("@apollo/client").OperationVariables> | undefined) => Promise<import("@apollo/client").ApolloQueryResult<ActivityLogsQueryData>>;
    handleFetchMore: ({ direction, }: {
        direction: EnumCursorDirection;
    }) => void;
    hasNextPage: boolean;
    hasPreviousPage: boolean;
    variant: "forward" | "backward";
};
export {};
