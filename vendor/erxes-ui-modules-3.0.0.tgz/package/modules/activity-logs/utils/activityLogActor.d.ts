import { TActivityLog } from '../types';
export declare function getActivityLogActorName(activity: TActivityLog): string;
export declare function getActivityLogActorInitial(name: string): string;
export declare const getActivityLogActor: (activity: TActivityLog) => {
    name: string;
};
