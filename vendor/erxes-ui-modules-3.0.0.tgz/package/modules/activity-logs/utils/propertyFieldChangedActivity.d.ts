type PropertyOption = {
    label?: string;
    value?: string;
};
export declare const getBaseFieldType: (fieldType?: string) => string;
export declare const getFieldTypeLabel: (fieldType?: string) => "Date" | "Number" | "Textarea" | "True/False" | "Select" | "Multiple Select" | "String List" | "Checkbox" | "Radio Button" | "Relation" | "File" | "Object List" | "Text";
export declare const getOptionLabel: (value: string, options: PropertyOption[]) => string;
export declare const getDisplayText: (value: unknown) => string;
export declare const getNestedActivityValue: (container: unknown, candidates: Array<string | undefined>) => unknown;
export declare const normalizePropertyValue: (value: unknown, fieldType?: string, options?: PropertyOption[]) => {
    kind: "empty";
    items: string[];
    isLongText: boolean;
} | {
    kind: "badge-list";
    items: string[];
    isLongText: boolean;
} | {
    kind: "text" | "long-text";
    items: string[];
    isLongText: boolean;
};
export declare const formatPropertyFieldValue: ({ value, fieldType, options, }: {
    value: unknown;
    fieldType?: string;
    options: Array<{
        label?: string;
        value?: string;
    }>;
}) => string;
export type PropertyFieldOption = PropertyOption;
export {};
