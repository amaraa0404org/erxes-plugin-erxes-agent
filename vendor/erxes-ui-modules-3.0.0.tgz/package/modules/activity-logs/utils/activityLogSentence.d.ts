export declare function formatActivityValue(value: unknown): string;
export declare function getChangedValue(container: Record<string, unknown> | unknown, field?: string): unknown;
