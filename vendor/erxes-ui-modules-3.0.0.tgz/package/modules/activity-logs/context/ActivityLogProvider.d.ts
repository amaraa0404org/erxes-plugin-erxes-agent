import React from 'react';
import { TActivityLog, ActivityLogCustomActivity } from '../types';
import { EnumCursorDirection } from 'erxes-ui';
interface ActivityLogContextType {
    targetId: string;
    activityLogs: TActivityLog[];
    loading: boolean;
    variant?: 'forward' | 'backward';
    error?: Error;
    customActivities?: ActivityLogCustomActivity[];
    handleFetchMore?: (params: {
        direction: EnumCursorDirection;
    }) => void;
    hasNextPage?: boolean;
    hasPreviousPage?: boolean;
    totalCount?: number;
    limit?: number;
    showExactDate?: boolean;
}
type ActivityLogProviderProps = ActivityLogContextType & {
    children: React.ReactNode;
};
export declare const ActivityLogProvider: React.FC<ActivityLogProviderProps>;
export declare const useActivityLog: () => ActivityLogContextType;
export {};
