export declare const ACTIVITY_LOGS: import("@apollo/client").DocumentNode;
