export declare const ACTIVITY_LOG_INSERTED: import("@apollo/client").DocumentNode;
