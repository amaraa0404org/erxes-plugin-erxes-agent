import { TActivityLog } from '../types';
export interface ActivityLogActorProps {
    activity: TActivityLog;
}
export declare const ActivityLogActorName: ({ activity }: ActivityLogActorProps) => import("react/jsx-runtime").JSX.Element;
export declare const ActivityLogActorAvatar: ({ activity }: ActivityLogActorProps) => import("react/jsx-runtime").JSX.Element;
