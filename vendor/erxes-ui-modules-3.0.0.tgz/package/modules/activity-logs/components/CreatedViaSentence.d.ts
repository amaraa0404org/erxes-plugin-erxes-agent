import { TActivityLog } from '../types';
export declare const isCreatedViaActivity: (activity: TActivityLog) => boolean;
/**
 * The "from campaign X" half, for rows that already say what happened.
 *
 * Renders nothing for a record someone made by hand, so a module can add it
 * to its own sentence without asking whether there is anything to add.
 */
export declare function CreatedViaSuffix({ activity }: {
    activity: TActivityLog;
}): import("react/jsx-runtime").JSX.Element | null;
export declare function CreatedViaSentence({ activity }: {
    activity: TActivityLog;
}): import("react/jsx-runtime").JSX.Element;
