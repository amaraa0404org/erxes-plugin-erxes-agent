import React from 'react';
import { QueryHookOptions } from '@apollo/client';
import { ActivityLogsQueryData } from '../hooks/useActivityLogs';
import { ActivityLogCustomActivity } from '../types';
import { ActivityLogRow } from './ActivityLogRow';
import { CreatedViaSuffix } from './CreatedViaSentence';
type ActivityLogFormRootProps = {
    targetId: string;
    action?: string;
    limit?: number;
    variant?: 'forward' | 'backward';
    customActivities?: ActivityLogCustomActivity[];
    options?: QueryHookOptions<ActivityLogsQueryData>;
    showExactDate?: boolean;
    activityType?: string;
    excludeActivityType?: string;
    dateFrom?: Date | string;
    dateTo?: Date | string;
    onTotalCountChange?: (totalCount: number) => void;
    children: React.ReactNode;
};
type LegacyProps = Omit<ActivityLogFormRootProps, 'children'> & {
    showInternalNotes?: boolean;
    emptyMessage?: string;
};
export declare const ActivityLogs: (({ targetId, action, limit, variant, customActivities, showInternalNotes, emptyMessage, options, showExactDate, activityType, excludeActivityType, dateFrom, dateTo, onTotalCountChange, }: LegacyProps) => import("react/jsx-runtime").JSX.Element) & {
    Root: ({ targetId, action, limit, variant, customActivities, options, showExactDate, activityType, excludeActivityType, dateFrom, dateTo, onTotalCountChange, children, }: ActivityLogFormRootProps) => import("react/jsx-runtime").JSX.Element;
    Wrapper: ({ children }: {
        children: React.ReactNode;
    }) => import("react/jsx-runtime").JSX.Element;
    Content: ({ emptyMessage }: {
        emptyMessage?: string;
    }) => import("react/jsx-runtime").JSX.Element;
    List: ({ emptyMessage, }: {
        emptyMessage?: string;
    }) => import("react/jsx-runtime").JSX.Element;
    Row: typeof ActivityLogRow;
    ActorName: ({ activity }: import("./ActivityLogActor").ActivityLogActorProps) => import("react/jsx-runtime").JSX.Element;
    CreatedVia: typeof CreatedViaSuffix;
};
export {};
