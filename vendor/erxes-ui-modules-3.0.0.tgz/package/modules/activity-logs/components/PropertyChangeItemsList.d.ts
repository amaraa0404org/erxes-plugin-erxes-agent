interface PropertyChangeItemsListProps {
    label: string;
    items: unknown[];
    fieldType?: string;
    options: Array<{
        label?: string;
        value?: string;
    }>;
}
export declare const PropertyChangeItemsList: ({ label, items, fieldType, options, }: PropertyChangeItemsListProps) => import("react/jsx-runtime").JSX.Element;
export {};
