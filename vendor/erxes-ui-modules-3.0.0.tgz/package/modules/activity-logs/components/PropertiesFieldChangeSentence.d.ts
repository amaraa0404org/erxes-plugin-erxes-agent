import { TActivityLog } from '../types';
interface PropertiesFieldChangeSentenceProps {
    activity: TActivityLog;
}
export declare const PropertiesFieldChangeSentence: ({ activity, }: PropertiesFieldChangeSentenceProps) => import("react/jsx-runtime").JSX.Element;
export {};
