import { TActivityLog } from '../types';
export declare function DefaultActivitySentence({ activity, }: {
    activity: TActivityLog;
}): import("react/jsx-runtime").JSX.Element;
