import { TActivityLog } from '../types';
export declare const isPermissionGroupActivityType: (activityType?: string) => boolean;
export declare const PermissionGroupAssignmentSentence: ({ activity, }: {
    activity: TActivityLog;
}) => import("react/jsx-runtime").JSX.Element;
