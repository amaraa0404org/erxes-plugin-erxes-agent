import { TActivityLog } from '../types';
export declare const FieldChangeSentence: ({ activity, }: {
    activity: TActivityLog;
}) => import("react/jsx-runtime").JSX.Element;
