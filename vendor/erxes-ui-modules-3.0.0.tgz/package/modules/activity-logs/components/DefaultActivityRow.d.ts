import { TActivityLog } from '../types';
export declare function DefaultActivityRow({ activity }: {
    activity: TActivityLog;
}): import("react/jsx-runtime").JSX.Element;
