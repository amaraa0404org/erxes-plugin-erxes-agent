interface PropertiesFieldChangeSentencePartProps {
    name: string;
    props: {
        value: unknown;
        fieldType?: string;
        options: Array<{
            label?: string;
            value?: string;
        }>;
    };
}
export declare const PropertiesFieldChangeSentencePart: ({ name, props, }: PropertiesFieldChangeSentencePartProps) => import("react/jsx-runtime").JSX.Element;
export {};
