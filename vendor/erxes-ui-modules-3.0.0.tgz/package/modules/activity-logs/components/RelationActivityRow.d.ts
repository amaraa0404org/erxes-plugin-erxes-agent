import { ActivityLogCustomActivity } from '../types';
export declare const relationCustomActivities: ActivityLogCustomActivity[];
