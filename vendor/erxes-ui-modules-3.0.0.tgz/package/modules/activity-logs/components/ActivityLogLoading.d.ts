export declare function ActivityLogLoading(): import("react/jsx-runtime").JSX.Element;
