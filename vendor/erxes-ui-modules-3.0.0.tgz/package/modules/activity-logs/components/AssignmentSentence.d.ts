import { TActivityLog } from '../types';
export declare const isAssignmentActivityType: (activityType?: string) => boolean;
export declare const AssignmentSentence: ({ activity, }: {
    activity: TActivityLog;
}) => import("react/jsx-runtime").JSX.Element;
