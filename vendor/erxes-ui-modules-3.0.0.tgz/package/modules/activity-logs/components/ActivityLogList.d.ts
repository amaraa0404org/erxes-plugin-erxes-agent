export declare const ActivityLogList: ({ emptyMessage, }: {
    emptyMessage?: string;
}) => import("react/jsx-runtime").JSX.Element;
