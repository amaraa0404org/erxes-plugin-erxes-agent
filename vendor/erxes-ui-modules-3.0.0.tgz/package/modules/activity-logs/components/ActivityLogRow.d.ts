import { TActivityLog } from '../types';
interface ActivityLogRowProps {
    activity: TActivityLog;
    isLast?: boolean;
    showExactDate?: boolean;
}
export declare function ActivityLogRow({ activity, isLast, showExactDate, }: ActivityLogRowProps): import("react/jsx-runtime").JSX.Element;
export {};
