export declare const QUERY_TEMPLATE_CATEGORIES: import("@apollo/client").DocumentNode;
export declare const QUERY_TEMPLATE_CATEGORY: import("@apollo/client").DocumentNode;
