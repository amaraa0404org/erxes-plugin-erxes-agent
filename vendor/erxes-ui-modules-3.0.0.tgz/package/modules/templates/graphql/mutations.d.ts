export declare const TEMPLATE_ADD: import("@apollo/client").DocumentNode;
