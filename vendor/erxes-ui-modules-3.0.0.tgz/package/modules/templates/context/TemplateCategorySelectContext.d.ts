import { Dispatch, SetStateAction } from 'react';
import { TemplateCategory } from '../types';
export type ISelectCategoryContext = {
    categoryIds: string[];
    onSelect: (category: TemplateCategory | null) => void;
    categories: TemplateCategory[];
    setCategories: Dispatch<SetStateAction<TemplateCategory[]>>;
    loading: boolean;
};
export declare const SelectCategoryContext: import("react").Context<ISelectCategoryContext | null>;
export declare const useSelectCategoryContext: () => ISelectCategoryContext;
