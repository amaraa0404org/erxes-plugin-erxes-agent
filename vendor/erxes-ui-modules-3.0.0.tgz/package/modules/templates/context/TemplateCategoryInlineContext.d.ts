import { Dispatch, SetStateAction } from 'react';
import { TemplateCategory } from '../types';
export interface ITemplateCategoryInlineContext {
    categories: TemplateCategory[];
    loading: boolean;
    categoryIds?: string[];
    placeholder: string;
    updateCategories?: Dispatch<SetStateAction<TemplateCategory[]>>;
}
export declare const TemplateCategoryInlineContext: import("react").Context<ITemplateCategoryInlineContext | null>;
export declare const useTemplateCategoryInlineContext: () => ITemplateCategoryInlineContext;
