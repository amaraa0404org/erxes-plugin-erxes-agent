export declare const TemplateSheet: ({ children, contentType, contentId, onCompleted, }: {
    children?: React.ReactNode;
    contentType: string;
    contentId: string;
    onCompleted?: (data: any) => void;
}) => import("react/jsx-runtime").JSX.Element;
