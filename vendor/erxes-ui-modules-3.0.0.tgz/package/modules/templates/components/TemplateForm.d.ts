interface TemplateFormProps {
    contentType: string;
    contentId: string;
    onCompleted?: (data: any) => void;
    onClose?: () => void;
}
export declare const TemplateForm: ({ contentType, contentId, onCompleted, onClose, }: TemplateFormProps) => import("react/jsx-runtime").JSX.Element;
export {};
