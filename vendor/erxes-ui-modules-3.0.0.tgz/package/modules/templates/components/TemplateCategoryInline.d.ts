import { Dispatch, SetStateAction } from 'react';
import { TemplateCategory } from '../types';
export declare const TemplateCategoriesInlineRoot: ({ categories, categoryIds, placeholder, updateCategories, className, }: {
    categories?: TemplateCategory[];
    categoryIds?: string[];
    placeholder?: string;
    updateCategories?: Dispatch<SetStateAction<TemplateCategory[]>>;
    className?: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const TemplateCategoriesInlineProvider: ({ children, categoryIds, categories, placeholder, updateCategories, }: {
    children?: React.ReactNode;
    categoryIds?: string[];
    categories?: TemplateCategory[];
    placeholder?: string;
    updateCategories?: Dispatch<SetStateAction<TemplateCategory[]>>;
}) => import("react/jsx-runtime").JSX.Element;
export declare const TemplateCategoriesInlineTitle: ({ className, }: {
    className?: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const TemplateCategoriesInline: (({ categories, categoryIds, placeholder, updateCategories, className, }: {
    categories?: TemplateCategory[];
    categoryIds?: string[];
    placeholder?: string;
    updateCategories?: Dispatch<SetStateAction<TemplateCategory[]>>;
    className?: string;
}) => import("react/jsx-runtime").JSX.Element) & {
    Provider: ({ children, categoryIds, categories, placeholder, updateCategories, }: {
        children?: React.ReactNode;
        categoryIds?: string[];
        categories?: TemplateCategory[];
        placeholder?: string;
        updateCategories?: Dispatch<SetStateAction<TemplateCategory[]>>;
    }) => import("react/jsx-runtime").JSX.Element;
    Title: ({ className, }: {
        className?: string;
    }) => import("react/jsx-runtime").JSX.Element;
};
