import { AvatarProps } from 'erxes-ui';
import React from 'react';
import { TemplateCategory } from '../types';
declare const SelectCategoryProvider: ({ children, mode, value, onValueChange, categories, setOpen, }: {
    children: React.ReactNode;
    mode?: "single" | "multiple";
    value?: string[] | string;
    onValueChange?: (value: string[] | string | null) => void;
    categories?: TemplateCategory[];
    setOpen?: (open: boolean) => void;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectCategoryFilterItem: ({ value, label, }: {
    value?: string;
    label?: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectCategoryFilterView: ({ onValueChange, queryKey, mode, }: {
    onValueChange?: (value: string[] | string | null) => void;
    queryKey?: string;
    mode?: "single" | "multiple";
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectCategoryFilterBar: ({ iconOnly, onValueChange, queryKey, mode, label, }: {
    iconOnly?: boolean;
    onValueChange?: (value: string[] | string | null) => void;
    queryKey?: string;
    mode?: "single" | "multiple";
    label?: string;
}) => import("react/jsx-runtime").JSX.Element | null;
export declare const SelectCategoryInlineCell: React.ForwardRefExoticComponent<Omit<Omit<{
    children: React.ReactNode;
    mode?: "single" | "multiple";
    value?: string[] | string;
    onValueChange?: (value: string[] | string | null) => void;
    categories?: TemplateCategory[];
    setOpen?: (open: boolean) => void;
}, "children"> & Omit<import("erxes-ui").ButtonProps & React.RefAttributes<HTMLButtonElement>, "ref"> & React.RefAttributes<HTMLButtonElement> & {
    scope?: string;
    placeholder?: string;
    size?: AvatarProps["size"];
}, "ref"> & React.RefAttributes<HTMLButtonElement>>;
export declare const SelectCategoryFormItem: ({ onValueChange, className, placeholder, ...props }: Omit<React.ComponentProps<typeof SelectCategoryProvider>, "children"> & {
    className?: string;
    placeholder?: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectCategoryDetail: ({ onValueChange, className, placeholder, value, ...props }: Omit<React.ComponentProps<typeof SelectCategoryProvider>, "children"> & {
    className?: string;
    placeholder?: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectCategoryRoot: ({ onValueChange, className, placeholder, scope, ...props }: Omit<React.ComponentProps<typeof SelectCategoryProvider>, "children"> & {
    className?: string;
    placeholder?: string;
    scope?: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectCategoryCustomDetail: ({ onValueChange, className, value, ...props }: Omit<React.ComponentProps<typeof SelectCategoryProvider>, "children"> & {
    className?: string;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SelectTemplateCategory: (({ onValueChange, className, placeholder, scope, ...props }: Omit<React.ComponentProps<typeof SelectCategoryProvider>, "children"> & {
    className?: string;
    placeholder?: string;
    scope?: string;
}) => import("react/jsx-runtime").JSX.Element) & {
    Provider: ({ children, mode, value, onValueChange, categories, setOpen, }: {
        children: React.ReactNode;
        mode?: "single" | "multiple";
        value?: string[] | string;
        onValueChange?: (value: string[] | string | null) => void;
        categories?: TemplateCategory[];
        setOpen?: (open: boolean) => void;
    }) => import("react/jsx-runtime").JSX.Element;
    Value: ({ placeholder }: {
        placeholder?: string;
    }) => import("react/jsx-runtime").JSX.Element;
    Content: () => import("react/jsx-runtime").JSX.Element;
    CommandItem: ({ category, }: {
        category: TemplateCategory;
    }) => import("react/jsx-runtime").JSX.Element;
    NoAssigneeItem: () => import("react/jsx-runtime").JSX.Element;
    FilterItem: ({ value, label, }: {
        value?: string;
        label?: string;
    }) => import("react/jsx-runtime").JSX.Element;
    FilterView: ({ onValueChange, queryKey, mode, }: {
        onValueChange?: (value: string[] | string | null) => void;
        queryKey?: string;
        mode?: "single" | "multiple";
    }) => import("react/jsx-runtime").JSX.Element;
    FilterBar: ({ iconOnly, onValueChange, queryKey, mode, label, }: {
        iconOnly?: boolean;
        onValueChange?: (value: string[] | string | null) => void;
        queryKey?: string;
        mode?: "single" | "multiple";
        label?: string;
    }) => import("react/jsx-runtime").JSX.Element | null;
    InlineCell: React.ForwardRefExoticComponent<Omit<Omit<{
        children: React.ReactNode;
        mode?: "single" | "multiple";
        value?: string[] | string;
        onValueChange?: (value: string[] | string | null) => void;
        categories?: TemplateCategory[];
        setOpen?: (open: boolean) => void;
    }, "children"> & Omit<import("erxes-ui").ButtonProps & React.RefAttributes<HTMLButtonElement>, "ref"> & React.RefAttributes<HTMLButtonElement> & {
        scope?: string;
        placeholder?: string;
        size?: AvatarProps["size"];
    }, "ref"> & React.RefAttributes<HTMLButtonElement>>;
    FormItem: ({ onValueChange, className, placeholder, ...props }: Omit<React.ComponentProps<typeof SelectCategoryProvider>, "children"> & {
        className?: string;
        placeholder?: string;
    }) => import("react/jsx-runtime").JSX.Element;
    Detail: ({ onValueChange, className, placeholder, value, ...props }: Omit<React.ComponentProps<typeof SelectCategoryProvider>, "children"> & {
        className?: string;
        placeholder?: string;
    }) => import("react/jsx-runtime").JSX.Element;
    CustomDetail: ({ onValueChange, className, value, ...props }: Omit<React.ComponentProps<typeof SelectCategoryProvider>, "children"> & {
        className?: string;
    }) => import("react/jsx-runtime").JSX.Element;
};
export {};
