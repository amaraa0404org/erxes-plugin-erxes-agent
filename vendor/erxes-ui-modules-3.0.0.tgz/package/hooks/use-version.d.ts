export declare const useVersion: (version?: "os" | "saas") => boolean;
