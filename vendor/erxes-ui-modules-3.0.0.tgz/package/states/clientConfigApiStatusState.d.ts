type ApiStatus = {
    isLoaded: boolean;
    isErrored: boolean;
    error?: Error;
};
export declare const clientConfigApiStatusState: import("jotai").PrimitiveAtom<ApiStatus> & {
    init: ApiStatus;
};
export {};
