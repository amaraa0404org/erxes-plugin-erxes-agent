import { IUIConfig } from 'erxes-ui';
export type PluginsConfigState = {
    [key: string]: IUIConfig;
};
export declare const pluginsConfigState: import("jotai").PrimitiveAtom<PluginsConfigState | null> & {
    init: PluginsConfigState | null;
};
export declare const loadingPluginsConfigState: import("jotai").PrimitiveAtom<boolean> & {
    init: boolean;
};
