import { ICurrentUserPermission } from 'ui-modules/modules/permissions/hooks/useCurrentUserPermissions';
export declare const currentUserPermissionsState: import("jotai").PrimitiveAtom<ICurrentUserPermission[] | null> & {
    init: ICurrentUserPermission[] | null;
};
export declare const pluginsWithPermissionsState: import("jotai").PrimitiveAtom<string[]> & {
    init: string[];
};
export declare const isPermissionsLoadedState: import("jotai").PrimitiveAtom<boolean> & {
    init: boolean;
};
