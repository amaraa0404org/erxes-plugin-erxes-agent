export type CurrentOrganization = {
    name: string;
    hasOwner?: boolean;
    logo?: string;
    theme?: {
        logo?: string;
        favicon?: string;
    };
    plugins?: {
        name: string;
        url: string;
    }[];
    type?: string;
    orgLogo?: string;
    orgLoginText?: string;
    orgLoginDescription?: string;
    orgFavicon?: string;
    orgShortDescription?: string;
    orgShortName?: string;
    orgCustomOnboarding?: boolean;
    bundle?: {
        type?: string;
    };
};
export declare const currentOrganizationState: import("jotai").PrimitiveAtom<CurrentOrganization | null> & {
    init: CurrentOrganization | null;
};
