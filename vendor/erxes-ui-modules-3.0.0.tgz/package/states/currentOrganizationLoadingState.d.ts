export declare const isCurrentOrganizationLoadedState: import("jotai").PrimitiveAtom<boolean> & {
    init: boolean;
};
