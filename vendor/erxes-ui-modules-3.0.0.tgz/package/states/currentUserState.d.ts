import { IUser } from 'ui-modules/modules/team-members/types/TeamMembers';
export declare const currentUserState: import("jotai").PrimitiveAtom<IUser | null> & {
    init: IUser | null;
};
