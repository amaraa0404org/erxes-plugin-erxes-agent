export declare const isCurrentUserLoadedState: import("jotai").PrimitiveAtom<boolean> & {
    init: boolean;
};
